import hashlib
import json
import platform
from pathlib import Path
import subprocess

from production_contract import PREFIX, REQUIRED, validate_manifest, validate_release_binding


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(*args):
    return subprocess.check_output(args,text=True).strip()


def identity(candidate_path, binding_path):
    candidate=Path(candidate_path)
    binding=json.loads(Path(binding_path).read_text())
    validate_release_binding(binding)
    if digest(candidate)!=binding['candidate_sha256']:
        raise ValueError('candidate differs from the Root binding')
    manifest=json.loads(candidate.read_text())
    architecture=platform.machine()
    artifact=validate_manifest(manifest,architecture)
    commit=manifest['source'].get('commit',manifest['source'].get('git_commit'))
    if binding['source_commit']!=commit:
        raise ValueError('source commit differs from the Root binding')
    for filename,key in [('production_contract.py','contract_sha256'),('installed_identity.py','identity_sha256')]:
        if digest(Path(__file__).with_name(filename))!=binding[key]:
            raise ValueError('unfrozen fixture dependency: '+filename)
    if digest(artifact['rpm_path'])!=artifact['rpm_sha256']:
        raise ValueError('RPM archive mismatch')
    nevra=command('rpm','-q','--qf','%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}','cosh-ng')
    if nevra!=artifact['nevra']:
        raise ValueError('installed NEVRA mismatch')
    command('rpm','-V','cosh-ng')
    records=command('rpm','-qp','--qf','[%{FILENAMES}\t%{FILEDIGESTS}\n]',artifact['rpm_path'])
    payload=dict(line.split('\t',1) for line in records.splitlines())
    elf={}
    for path,expected in artifact['payload_sha256'].items():
        if digest(path)!=expected or payload.get(path)!=expected:
            raise ValueError('installed payload mismatch: '+path)
        if command('rpm','-qf','--qf','%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}',path)!=nevra:
            raise ValueError('payload package owner mismatch: '+path)
        if path in {PREFIX+n for n in ['cosh-shell','cosh-core','cosh-ui-worker']}:
            data=Path(path).read_bytes()
            if data[:4]!=b'\x7fELF' or int.from_bytes(data[18:20],'little')!={'aarch64':183,'x86_64':62}[architecture]:
                raise ValueError('native installed ELF required: '+path)
            elf[path]={'sha256':expected,'machine':int.from_bytes(data[18:20],'little')}
    return {'architecture':architecture,'source':manifest['source'],'rpm_sha256':artifact['rpm_sha256'],'rpm_nevra':nevra,'payload_sha256':artifact['payload_sha256'],'ELF':elf,'binary_origin':'installed-rpm','resolved_path':PREFIX+'cosh-shell','binary_sha256':artifact['payload_sha256'][PREFIX+'cosh-shell'],'adapter_version':command(PREFIX+'cosh-shell','--version'),'candidate_sha256':digest(candidate),'tool_binding':binding}


if __name__=='__main__':
    import sys
    print(json.dumps(identity(sys.argv[1],sys.argv[2]),sort_keys=True))
