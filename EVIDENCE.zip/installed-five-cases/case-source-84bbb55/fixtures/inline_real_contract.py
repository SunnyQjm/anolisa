import hashlib
import re

try:
    from .inline_contract import PREFIX, REQUIRED, require
except ImportError:
    from inline_contract import PREFIX, REQUIRED, require


def verify_real_join(cli, observer, case_sha256):
    require(cli.get('ok') is True,'successful strict CLI result required')
    data=cli.get('data',{})
    require(data.get('execution')=='real-provider' and data.get('exit_status')==0 and data.get('failures')==[],'real provider execution failed')
    require(data.get('case',{}).get('id')=='INL-PROD-REAL-001' and data['case'].get('sha256')==case_sha256,'new canonical case digest required')
    require({'provider-response','real-followup','shell-recovered'}<={p.get('id') for p in data.get('points',[])},'strict Agent response/followup/recovery points required')
    provider=data.get('provider_evidence',{})
    require(provider.get('binary_origin')=='installed-rpm' and provider.get('mock_enabled') is False,'installed real provider required')
    require(all(provider.get(k) is True for k in ['provider_started_observed','upstream_response_observed','semantic_checkpoint_observed','prompt_recovered']),'strict provider lifecycle incomplete')
    require(type(provider.get('request_count')) is int and provider['request_count']>=2,'second user request required')
    payload=provider.get('payload_sha256',{})
    require(set(payload)==REQUIRED,'five inline payloads required')
    require(observer.get('evidence_class')=='installed-inline-real-provider-observer' and observer.get('delivery_mode')=='inline-first','inline observer required')
    require(observer.get('completed') is True and observer.get('error') is None,'incomplete observer cannot produce a verdict')
    require(observer.get('rpm_sha256')==provider.get('rpm_sha256') and observer.get('candidate_sha256')==provider.get('installed_manifest_sha256'),'candidate or RPM mismatch')
    require(observer.get('hosts') and observer.get('cores') and observer.get('workers')==[],'Host/Core and no sampled worker required')
    hosts={row['pid'] for row in observer['hosts']}
    for group,name in [('hosts','cosh-shell'),('cores','cosh-core')]:
        for row in observer[group]:
            require(type(row.get('pid')) is int and row['pid']>0 and type(row.get('start')) is int and row['start']>0,'PID/start required')
            require(row.get('exe')==PREFIX+name and row.get('sha256')==payload[PREFIX+name],'installed process digest mismatch')
            if group=='cores':require(row.get('ppid') in hosts,'Core must belong to observed Host')
    effects=observer.get('effects',{})
    require(len(effects)==1,'one request-bound effect file required')
    name,lines=next(iter(effects.items()))
    match=re.fullmatch(r'.*/effect-([0-9a-f]{32})\.txt',name)
    require(match is not None and hashlib.sha256(match[1].encode()).hexdigest()==provider.get('request_nonce_sha256'),'effect nonce differs from real request')
    require(lines==['INL_EFFECT'],'missing or duplicate real effect')
    require(observer.get('fresh_effect')==['INL_REAL_FRESH'],'fresh ordinary command must execute once')
    expected=observer.get('ps1_expected_hex')
    require(isinstance(expected,str) and bool(expected) and observer.get('ps1_before_hex')==observer.get('ps1_after_hex')==expected,'raw native PS1 changed')
