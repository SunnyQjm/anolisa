from pathlib import Path
import hashlib
import json
import math
import os
import re
import subprocess
import sys

TOOL=Path('/Users/quejianming/vscode/cosh-shell-dev/outputs/codex-takeover-20261013/production-worker-20261016/acceptance/tool-inline-lifecycle-8028')
source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();expected=sys.argv[3]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,value:p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
raw=(source/'transcript.cast').read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
before={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}
result=json.loads((source/'result.json').read_text());assert result['ok'] is True
case_id=result['data']['case']['id'];canonical=TOOL/'specs/shell-e2e-validation/cases/inline-production-installed.yaml'
case=next(c for c in json.loads(canonical.read_text())['cases'] if c['id']==case_id)
point=next(p for p in json.loads((source/'acceptance-points.json').read_text()) if p['id']=='approval-card')
trigger=next(step for step in case['input'] if step.get('id')==point['trigger_event'])
assert trigger['type']=='wait_for' and trigger['text']=='> [ Allow once ]'
rows=[];file_offset=0;output=bytearray()
for index,line in enumerate(raw.splitlines(keepends=True)):
    if index:
        timestamp,kind,payload=json.loads(line);assert kind=='o'
        rows.append({'event_index':index,'timestamp_seconds':timestamp,'file_start':file_offset,'file_end':file_offset+len(line),'output_start':len(output),'output_end':len(output)+len(payload.encode()),'payload':payload})
        output.extend(payload.encode())
    file_offset+=len(line)
text=output.decode();focus=text.index(trigger['text']);card_start=max(text.rfind('╭',0,focus),text.rfind('┌',0,focus));assert card_start>=0
assert 'Approval' in text[card_start:focus] and 'INL_EFFECT' in text[card_start:focus]
footer=re.search(r'[╰└]─+[╯┘]',text[focus:]);assert footer
footer_start=focus+footer.start();footer_end=focus+footer.end()
footer_end_byte=len(text[:footer_end].encode());footer_start_byte=len(text[:footer_start].encode())
last=next(row for row in rows if row['output_start']<footer_end_byte<=row['output_end'])
suffix=bytes(output[footer_end_byte:last['output_end']]).decode();assert re.fullmatch(r'(?:\x1b\[[0-9;]*m|[\r\n])*',suffix),repr(suffix)
focus_start_byte=len(text[:focus].encode());focus_record=next(row for row in rows if row['output_start']<=focus_start_byte<row['output_end'])
prefix=raw[:last['file_end']];out.mkdir(exist_ok=False);(out/'transcript.cast').write_bytes(prefix)
parent=json.loads((source/'run.json').read_text())
write(out/'run.json',{'capabilities':['acceptance'],'repo':parent.get('repo',{}),'artifact_kind':'derived-media-only','parent_run_id':source.name,'execution_performed':False})
write(out/'result.json',{'ok':False,'data':{'case':{'id':case_id},'derivation_only':True},'error':{'code':'derived-media-only','message':'Replay media only; no new execution or functional PASS.'}})
write(out/'acceptance-points.json',[{**point,'offset_ms':math.ceil(last['timestamp_seconds']*1000)}])
env={k:v for k,v in os.environ.items() if not k.startswith('COSH_LAB_')};env.update(PYTHONPATH=str(TOOL/'runtime/src'),PYTHONDONTWRITEBYTECODE='1')
argv=[sys.executable,'-B','-m','cosh_lab','evidence','render',str(out),'--output','json'];write(out/'render-command.json',{'argv':argv,'cwd':str(TOOL),'PYTHONPATH':env['PYTHONPATH']})
command=subprocess.run(argv,cwd=TOOL,env=env,capture_output=True,text=True);(out/'render.stdout').write_text(command.stdout);(out/'render.stderr').write_text(command.stderr)
assert command.returncode==0,(command.stdout,command.stderr)
rendered=json.loads(command.stdout);assert rendered['ok'] is True;row=rendered['data']['screenshots'][0]
assert row['source_sha256']==sha(out/'transcript.cast')
for key in ['screenshot','screen']:assert sha(out/row[key])==row[key+'_sha256']
assert (out/'transcript.cast').read_bytes()==raw[:last['file_end']]
assert {str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()}==before
versions={}
for name in ['agg','ffmpeg']:
    probe=subprocess.run([name,'--version' if name=='agg' else '-version'],capture_output=True,text=True,check=True);versions[name]=probe.stdout.splitlines()[0]
receipt={'artifact_kind':'derived-media-only','case_id':case_id,'point_id':'approval-card','canonical':str(canonical),'canonical_sha256':sha(canonical),'canonical_wait_text':trigger['text'],'boundary_type':'complete-initial-card-non-OSC','basis':'first actual canonical Allow focus plus complete original footer; selected source record remainder contains only SGR and CR/LF, no later repaint','focus_record':focus_record,'footer_records':[r for r in rows if r['output_end']>footer_start_byte and r['event_index']<=last['event_index']],'source_cast':str(source/'transcript.cast'),'source_cast_sha256':expected,'source_record_end_byte':last['file_end'],'source_output_end_byte':last['output_end'],'source_final_event_index':last['event_index'],'prefix_sha256':sha(out/'transcript.cast'),'literal_original_byte_prefix':True,'events_or_timestamps_rewritten':False,'driver_input_timestamp_claimed':False,'source_assets_unchanged':True,'script_sha256':sha(Path(__file__)),'renderer_source_sha256':{name:sha(TOOL/'runtime/src/cosh_lab'/name) for name in ['evidence.py','resize_render.py','cli.py']},'versions':versions,'rendered':row,'new_execution':False,'new_functional_pass':False,'semantic_status':'PENDING_VISUAL_QA','video_meaning':'context replay of literal original prefix, not independent exact-time recording'}
write(out/'EXPORT-RECEIPT.json',receipt);write(out/'EVIDENCE-SHA256.json',{str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file() and p.name!='EVIDENCE-SHA256.json'})
print(json.dumps({'out':str(out),'prefix_end':last['file_end'],'prefix_sha256':receipt['prefix_sha256'],'script_sha256':receipt['script_sha256']}))
