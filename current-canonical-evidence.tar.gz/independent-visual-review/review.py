import csv
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import subprocess


ROOT = Path("/Users/quejianming/vscode/cosh-shell-dev")
RUNS = ROOT / ".worktrees/cosh-track2-ui-approval-slice/.cosh-lab/runs"
OUTPUT = ROOT / "outputs/codex-takeover-20261013/ui/terminal/final-source-visual-review"
HEAD = "2e7fc1720511479c25374246b0ff50a38596aee4"
BINARY_SHA = {"cosh-shell": "790f049fc20f863dbf8c37de0d393d456cac020d9d1f5adb22cfa8f6c7488b36", "cosh-core": "9c73f00310b66dea10302e101009edc6dfffa425fe36f3703c6f8d1b80cc2ee9", "cosh-ui-worker": "cfe30b7de19165edd0883cd9f2aa1b9b993e8659f0a73d0c2bc7dac8c2127787"}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def decode(path, filters=None):
    command = ["ffmpeg", "-v", "error", "-i", str(path)]
    if filters:
        command += ["-vf", filters, "-fps_mode", "passthrough"]
    command += ["-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"]
    return subprocess.check_output(command), command


OUTPUT.mkdir(exist_ok=True)
reviews = []
for name in ["20261013T210121Z-962f7310", "20261013T210137Z-149480a9"]:
    run = RUNS / name
    assert json.loads((run / "run.json").read_text())["repo"]["commit"] == HEAD
    result = json.loads((run / "result.json").read_text())
    assert result["ok"] and result["data"]["exit_status"] == 0 and not result["data"]["failures"]
    cast = [json.loads(line) for line in (run / "transcript.cast").read_text().splitlines()]
    source_sha = digest(run / "transcript.cast")
    for row in csv.DictReader((run / "visual-evidence-index.tsv").open(), delimiter="\t"):
        point = row["acceptance_point_id"]
        provenance = json.loads((run / row["replay_provenance"]).read_text())
        assert row["source_sha256"] == provenance["source_sha256"] == source_sha
        assert provenance["source_head"] == HEAD and provenance["point_id"] == point
        assert digest(run / row["replay_provenance"]) == row["replay_provenance_sha256"]
        offset = int(row["cast_offset_ms"])
        assert offset == provenance["cast_offset_ms"]
        eligible = [frame for frame in provenance["frames"] if frame["pts_ms"] <= offset]
        expected = eligible[-1]
        assert expected["source_event"] == provenance["source_event"]
        assert expected["viewport"] == provenance["viewport"]
        for frame in provenance["frames"]:
            if frame["source_event"]:
                event = cast[frame["source_event"]]
                assert event[0] == frame["source_time_seconds"]
                assert frame["pts_ms"] == math.ceil(event[0] * 1000)
        viewport = [cast[0]["width"], cast[0]["height"]]
        for event in cast[1:provenance["source_event"] + 1]:
            if event[1] == "r":
                viewport = [int(value) for value in event[2].split("x")]
        assert viewport == provenance["viewport"]
        png, video = run / row["screenshot"], run / row["screen"]
        assert digest(png) == row["screenshot_sha256"] == provenance["screenshot_sha256"]
        assert digest(video) == row["screen_sha256"] == provenance["screen_sha256"]
        size = list(struct.unpack(">II", png.read_bytes()[16:24]))
        assert size == provenance["png_dimensions"]
        probe = json.loads(subprocess.check_output(["ffprobe", "-v", "error", "-show_frames", "-show_entries", "frame=best_effort_timestamp_time", "-of", "json", str(video)]))
        times = [int(Decimal(frame["best_effort_timestamp_time"]) * 1000) for frame in probe["frames"]]
        assert times == provenance["encoded_pts_ms"]
        number = max(index for index, pts in enumerate(times) if pts <= offset)
        assert times[number] == expected["pts_ms"]
        filters = f"select=eq(n\\,{number}),crop={size[0]}:{size[1]}:0:0"
        video_pixels, command = decode(video, filters)
        png_pixels, unused = decode(png)
        assert len(video_pixels) == len(png_pixels) == size[0] * size[1] * 3
        max_difference = max(abs(left - right) for left, right in zip(video_pixels, png_pixels))
        assert max_difference <= 2
        keyframe = OUTPUT / f"{name}-{point}.png"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(video), "-vf", filters, "-fps_mode", "passthrough", "-frames:v", "1", str(keyframe)], check=True)
        screen, history = provenance["screen_text"], provenance["logical_history"]
        content = {}
        if "RESIZE" in row["case_id"]:
            content["entire_cjk_history"] = "UI_LEFT_SENTINEL" + "abcdefgh终端输出" * 16 + "UI_RIGHT_SENTINEL" in history
        if point in {"worker-card", "resized-current-card", "fault-current-card", "fault-resized-card"}:
            content["one_current_complete_card"] = screen.count("Approval req-1") == 1 and bool(re.search("[╰└]─+[╯┘]", screen.replace("\n", "")))
        if point == "fault-focused-deny":
            content["deny_selected"] = "> [ Deny ]" in screen
        if point in {"bash-returned", "fault-bash-returned"}:
            content["ordinary_bash_ready"] = "UI_BASH_READY" in screen
        assert all(content.values())
        reviews.append({"run": name, "point": point, "source_sha256": source_sha, "source_event": provenance["source_event"], "offset_ms": offset, "selected_video_frame": number, "selected_pts_ms": times[number], "viewport": viewport, "png_dimensions": size, "pixel_max_difference": max_difference, "content_checks": content, "keyframe": str(keyframe), "decode_command": command})
facts = []
for path in sorted((ROOT / "outputs/codex-takeover-20261013/ui/terminal/canonical/final-source-sidecars").glob("*/result.json")):
    data = json.loads(path.read_text())
    assert data["binary_sha256"] == BINARY_SHA
    assert data["shell_exit"] == 0 and data["effect_count"] == 1 and data["request_count"] == 2
    assert data["host_tool_result"] and data["outer_termios_restored"] and not data["bash_drift"] and data["bash_baseline"] and data["remaining_pids"] == []
    assert any(item["inner"] == item["outer"] == {"rows": 20, "cols": 47} for item in data["geometry_observations"])
    if data["scenario"] == "kill-frame":
        assert len(data["fault"]) == 3 and len({(item["pid"], item["start"]) for item in data["fault"]}) == 3
        frames = data["focus_roundtrip"]
        assert [item["selected"] for item in frames] == ["Allow once", "Deny", "Allow once"]
        assert len({(item["worker_pid"], item["worker_start"]) for item in frames}) == 1
        raw = (path.parent / "script-output.bin").read_bytes()
        assert all(hashlib.sha256(raw[item["begin_offset"]:item["end_offset"]]).hexdigest() == item["sha256"] for item in frames + [fault["frame"] for fault in data["fault"]])
    facts.append({"sidecar": str(path), "all_checked_facts_passed": True})
assert len(reviews) == 8 and len(facts) == 2
(OUTPUT / "review.json").write_text(json.dumps({"verdict": "Go: independent source/time/geometry/pixel/content/sidecar checks", "source_head": HEAD, "points": reviews, "sidecar_facts": facts, "no_artifact_or_source_mutation": True, "no_env_cargo": True}, indent=2) + "\n")
print(json.dumps({"verdict": "Go", "points": len(reviews), "pixel_max_difference": max(item["pixel_max_difference"] for item in reviews), "sidecars": len(facts)}))
