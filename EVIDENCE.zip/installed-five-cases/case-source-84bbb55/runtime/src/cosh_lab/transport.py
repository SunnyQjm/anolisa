from __future__ import annotations

import shlex
from typing import Any, Callable


class TransportError(RuntimeError):
    pass


NON_INTERACTIVE_TRANSPORTS = (
    "auto",
    "native",
    "workbench",
    "ssh",
    "proxyjump",
    "assistant",
)
INTERACTIVE_TRANSPORTS = ("auto", "native", "ssh", "proxyjump")
TRANSPORTS = set(NON_INTERACTIVE_TRANSPORTS)


def transport_candidates(
    manifest: dict[str, Any],
    operation: str,
) -> list[str]:
    if not isinstance(manifest, dict):
        raise TransportError("environment manifest must be an object")
    backend = manifest.get("backend")
    if not isinstance(backend, dict):
        raise TransportError("environment backend must be an object")
    kind = backend.get("kind")
    if kind in {"container", "vm"}:
        return ["native"]
    if kind != "ecs":
        raise TransportError(f"unsupported backend transport: {kind}")

    config = backend.get("transport", {})
    if not isinstance(config, dict):
        raise TransportError("environment transport must be an object")
    candidates = []
    if operation != "shell" and config.get("workbench_profile"):
        candidates.append("workbench")
    if config.get("public_host"):
        candidates.append("ssh")
    if config.get("private_host") and config.get("proxy_jump"):
        candidates.append("proxyjump")
    if operation != "shell":
        candidates.append("assistant")
    return candidates


def resolve_transport(
    manifest: dict[str, Any],
    requested: str,
    operation: str,
    probe: Callable[[str], dict[str, Any]],
) -> dict[str, Any]:
    if requested not in TRANSPORTS:
        raise TransportError(f"unsupported transport: {requested}")
    candidates = transport_candidates(manifest, operation)
    if requested != "auto":
        if requested not in candidates:
            raise TransportError(
                f"explicit transport is unavailable for {operation}: {requested}"
            )
        candidates = [requested]
    if not candidates:
        if operation == "shell":
            raise TransportError(
                "interactive shell requires SSH or ProxyJump"
            )
        raise TransportError(f"no transport is available for {operation}")

    probes = []
    for candidate in candidates:
        result = probe(candidate)
        probes.append(result)
        if result.get("ok") is True:
            return {
                "requested": requested,
                "selected": candidate,
                "probes": probes,
            }
        if requested != "auto":
            break
    if requested != "auto":
        raise TransportError(f"explicit transport failed: {requested}")
    if operation == "shell":
        raise TransportError("interactive shell requires SSH or ProxyJump")
    raise TransportError(f"no usable transport for {operation}")


def ssh_argv(
    backend: dict[str, Any],
    transport: str,
    command: list[str] | None = None,
) -> list[str]:
    target, options = ssh_target_and_options(backend, transport)
    argv = ["ssh", *options, target]
    if command:
        argv.append(shlex.join(command))
    return argv


def ssh_target_and_options(
    backend: dict[str, Any],
    transport: str,
) -> tuple[str, list[str]]:
    config = backend.get("transport", {})
    if transport == "ssh":
        host = config.get("public_host")
    elif transport == "proxyjump":
        host = config.get("private_host")
    else:
        raise TransportError(f"not an SSH transport: {transport}")
    user = config.get("ssh_user", "root")
    if not isinstance(host, str) or not host:
        raise TransportError(f"{transport} target host is unavailable")
    if not isinstance(user, str) or not user:
        raise TransportError("SSH user is unavailable")
    timeout = config.get("connect_timeout_seconds", 5)
    options = [
        "-o",
        "BatchMode=yes",
        "-o",
        "StrictHostKeyChecking=yes",
        "-o",
        f"ConnectTimeout={timeout}",
    ]
    identity_file = config.get("identity_file")
    if identity_file:
        options.extend(("-o", f"IdentityFile={identity_file}"))
        options.extend(("-o", "IdentitiesOnly=yes"))
    known_hosts_file = config.get("known_hosts_file")
    if known_hosts_file:
        options.extend(("-o", f"UserKnownHostsFile={known_hosts_file}"))
    if transport == "proxyjump":
        proxy_jump = config.get("proxy_jump")
        if not isinstance(proxy_jump, str) or not proxy_jump:
            raise TransportError("ProxyJump alias is unavailable")
        options.extend(("-J", proxy_jump))
    return f"{user}@{host}", options


def scp_argv(
    backend: dict[str, Any],
    transport: str,
    local_path: str,
    remote_path: str,
    *,
    upload: bool,
) -> list[str]:
    target, ssh_options = ssh_target_and_options(backend, transport)
    options: list[str] = []
    iterator = iter(ssh_options)
    for option in iterator:
        value = next(iterator)
        if option == "-J":
            options.extend(("-o", f"ProxyJump={value}"))
        else:
            options.extend((option, value))
    remote = f"{target}:{shlex.quote(remote_path)}"
    paths = (local_path, remote) if upload else (remote, local_path)
    return ["scp", *options, "--", *paths]
