# cosh-lab env-up

- Run: `20261016T004839Z-9cd0060f`
- Status: `PASS`
- Cleanup: `retained-by-policy`
- Environment: `host`
