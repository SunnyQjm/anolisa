import hashlib
import json
import platform
from pathlib import Path
import stat
import subprocess

try:
    from .inline_contract import PREFIX, REQUIRED, require, validate_manifest, validate_release_binding
except ImportError:
    from inline_contract import PREFIX, REQUIRED, require, validate_manifest, validate_release_binding


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(*args):
    return subprocess.check_output(args,text=True,timeout=30).strip()


def validate_payload_bytes(data, path, architecture):
    if path=='/usr/bin/cosh-switch':
        require(data.startswith(b'#!'),'switch must be an executable script')
        return
    require(architecture in {'aarch64','x86_64'},'unsupported native architecture')
    require(len(data)>=64 and data[:6]==b'\x7fELF\x02\x01','native ELF64 little-endian payload required: '+path)
    require(int.from_bytes(data[18:20],'little')=={'aarch64':183,'x86_64':62}[architecture],'native ELF machine mismatch: '+path)


def validate_package_inventory(paths):
    require(REQUIRED<=set(paths),'five payload package inventory incomplete')
    require(not any('cosh-ui-worker' in path for path in paths),'worker path remains in RPM')


def identity(candidate_path, binding_path):
    candidate=Path(candidate_path)
    binding=json.loads(Path(binding_path).read_text())
    validate_release_binding(binding)
    require(digest(candidate)==binding['candidate_sha256'],'candidate differs from Root binding')
    manifest=json.loads(candidate.read_text())
    architecture=platform.machine()
    artifact=validate_manifest(manifest,architecture)
    source=manifest['source']
    require(binding['source_commit']==source.get('commit',source.get('git_commit')),'source commit differs from Root binding')
    require(binding['source_tree']==source.get('tree',source.get('git_tree')),'source tree differs from Root binding')
    for name,key in [('inline_contract.py','contract_sha256'),('inline_identity.py','identity_sha256')]:
        require(digest(Path(__file__).with_name(name))==binding[key],'unfrozen dependency: '+name)
    require(digest(artifact['rpm_path'])==artifact['rpm_sha256'],'RPM archive mismatch')
    nevra=command('rpm','-q','--qf','%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}','cosh-ng')
    require(nevra==artifact['nevra'],'installed NEVRA mismatch')
    command('rpm','-V','cosh-ng')
    records=command('rpm','-qp','--qf','[%{FILENAMES}\t%{FILEDIGESTS}\n]',artifact['rpm_path'])
    package=dict(line.split('\t',1) for line in records.splitlines())
    validate_package_inventory(package)
    validate_package_inventory(command('rpm','-ql','cosh-ng').splitlines())
    require(not Path(PREFIX+'cosh-ui-worker').exists(),'installed worker path remains')
    dependencies=command('rpm','-qp','--requires',artifact['rpm_path'])
    scripts=command('rpm','-qp','--scripts',artifact['rpm_path'])
    require('cosh-ui-worker' not in dependencies+scripts,'worker package activation/dependency remains')
    elf={}
    for path,expected in artifact['payload_sha256'].items():
        file=Path(path)
        metadata=file.lstat()
        require(stat.S_ISREG(metadata.st_mode) and metadata.st_uid==0 and metadata.st_gid==0 and stat.S_IMODE(metadata.st_mode)==0o755,'root-owned regular executable 0755 required: '+path)
        require(digest(file)==expected==package.get(path),'installed/archive payload digest mismatch: '+path)
        require(command('rpm','-qf','--qf','%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}',path)==nevra,'package owner mismatch: '+path)
        data=file.read_bytes()
        validate_payload_bytes(data,path,architecture)
        if path!='/usr/bin/cosh-switch':
            elf[path]={'sha256':expected,'machine':int.from_bytes(data[18:20],'little')}
    return {'delivery_mode':'inline-first','architecture':architecture,'source':source,'rpm_sha256':artifact['rpm_sha256'],'rpm_nevra':nevra,'payload_sha256':artifact['payload_sha256'],'ELF':elf,'binary_origin':'installed-rpm','resolved_path':PREFIX+'cosh-shell','binary_sha256':artifact['payload_sha256'][PREFIX+'cosh-shell'],'adapter_version':command(PREFIX+'cosh-shell','--version'),'candidate_sha256':digest(candidate),'tool_binding':binding}


if __name__=='__main__':
    import sys
    print(json.dumps(identity(sys.argv[1],sys.argv[2]),sort_keys=True))
