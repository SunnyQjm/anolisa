from __future__ import annotations

import base64
import copy
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import fcntl
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import time
from typing import Any, Callable


def _sleep_scale() -> float:
    # Polling pauses scale via COSH_LAB_ECS_SLEEP_SCALE (default 1.0).
    # Lets fake-CLI test drivers and interactive debugging shrink waits;
    # invalid or non-positive values fail safe to the unscaled behavior.
    raw = os.environ.get("COSH_LAB_ECS_SLEEP_SCALE")
    if not raw:
        return 1.0
    try:
        scale = float(raw)
    except ValueError:
        return 1.0
    if scale <= 0:
        return 1.0
    return scale


def _pause(seconds: float) -> None:
    time.sleep(seconds * _sleep_scale())


class EcsError(RuntimeError):
    def __init__(
        self,
        message: str,
        commands: list[dict[str, Any]],
        *,
        cleanup_safe: bool = True,
        active_invoke_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.commands = commands
        self.cleanup_safe = cleanup_safe
        self.active_invoke_id = active_invoke_id


class EcsCommandInterrupted(KeyboardInterrupt):
    def __init__(
        self,
        commands: list[dict[str, Any]],
        *,
        cleanup_safe: bool = True,
    ) -> None:
        super().__init__("Cloud Assistant command interrupted")
        self.commands = commands
        self.cleanup_safe = cleanup_safe


@contextmanager
def ecs_creation_lock(region: str):
    default_root = (
        Path(
            os.environ.get(
                "XDG_CACHE_HOME",
                str(Path.home() / ".cache"),
            )
        )
        / "cosh-lab"
        / "locks"
    )
    lock_root = Path(os.environ.get("COSH_LAB_LOCK_ROOT", str(default_root)))
    lock_root.mkdir(mode=0o700, parents=True, exist_ok=True)
    lock_path = lock_root / (
        f"ecs-create-{hashlib.sha256(region.encode()).hexdigest()[:16]}.lock"
    )
    with lock_path.open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def aliyun_call(
    cli_path: str,
    action: str,
    parameters: list[str],
) -> dict[str, Any]:
    return aliyun_product_call(cli_path, "ecs", action, parameters)


def aliyun_product_call(
    cli_path: str,
    product: str,
    action: str,
    parameters: list[str],
) -> dict[str, Any]:
    argv = [cli_path, product, action, *parameters]
    started = time.monotonic()
    result = subprocess.run(
        argv,
        text=True,
        capture_output=True,
        check=False,
    )
    payload: dict[str, Any] = {}
    streams = [part.strip() for part in (result.stdout, result.stderr) if part.strip()]
    for text in streams:
        try:
            candidate = json.loads(text)
        except json.JSONDecodeError:
            continue
        if isinstance(candidate, dict):
            payload = candidate
            break
    combined = "\n".join(streams)
    if not payload:
        for line in reversed(combined.splitlines()):
            try:
                candidate = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(candidate, dict):
                payload = candidate
                break
    if not payload and "DryRunOperation" in combined:
        payload = {"Code": "DryRunOperation"}
    return {
        "argv": argv,
        "exit_code": result.returncode,
        "duration_seconds": round(time.monotonic() - started, 6),
        "stdout": result.stdout,
        "stderr": result.stderr,
        "payload": payload,
    }


def require_ecs_resources(
    cli_path: str,
    profile: dict[str, Any],
) -> list[dict[str, Any]]:
    ecs = profile["ecs"]
    calls = [
        (
            "image",
            aliyun_call(
                cli_path,
                "DescribeImages",
                [
                    "--RegionId",
                    ecs["region"],
                    "--ImageId",
                    ecs["image_id"],
                    "--Status",
                    "Available",
                ],
            ),
            lambda payload: len(payload.get("Images", {}).get("Image", [])) == 1,
        ),
        (
            "instance type",
            aliyun_call(
                cli_path,
                "DescribeInstanceTypes",
                ["--InstanceTypes.1", ecs["instance_type"]],
            ),
            lambda payload: (
                len(payload.get("InstanceTypes", {}).get("InstanceType", [])) == 1
            ),
        ),
        (
            "VPC",
            aliyun_product_call(
                cli_path,
                "vpc",
                "DescribeVpcs",
                ["--RegionId", ecs["region"], "--VpcId", ecs["vpc_id"]],
            ),
            lambda payload: int(payload.get("TotalCount", 0)) == 1,
        ),
        (
            "vSwitch",
            aliyun_product_call(
                cli_path,
                "vpc",
                "DescribeVSwitches",
                [
                    "--RegionId",
                    ecs["region"],
                    "--VSwitchId",
                    ecs["vswitch_id"],
                ],
            ),
            lambda payload: int(payload.get("TotalCount", 0)) == 1,
        ),
        (
            "security group",
            aliyun_call(
                cli_path,
                "DescribeSecurityGroups",
                [
                    "--RegionId",
                    ecs["region"],
                    "--SecurityGroupIds",
                    json.dumps([ecs["security_group_id"]]),
                ],
            ),
            lambda payload: int(payload.get("TotalCount", 0)) == 1,
        ),
    ]
    commands = []
    for name, result, valid in calls:
        commands.append(result)
        if result["exit_code"] != 0 or not valid(result["payload"]):
            raise EcsError(f"ECS {name} preflight failed", commands)
    return commands


def describe_instances(
    cli_path: str,
    region: str,
    *,
    instance_id: str | None = None,
    run_id: str | None = None,
) -> dict[str, Any]:
    parameters = ["--RegionId", region]
    if instance_id:
        parameters.extend(("--InstanceIds", json.dumps([instance_id])))
    else:
        parameters.extend(("--Tag.1.Key", "managed-by", "--Tag.1.Value", "cosh-lab"))
        if run_id:
            parameters.extend(("--Tag.2.Key", "run-id", "--Tag.2.Value", run_id))
    return aliyun_call(cli_path, "DescribeInstances", parameters)


def instances_from(result: dict[str, Any]) -> list[dict[str, Any]]:
    payload = result["payload"]
    instances = payload.get("Instances", {}).get("Instance", [])
    return instances if isinstance(instances, list) else []


def recover_instance_by_run(
    cli_path: str,
    region: str,
    run_id: str,
) -> dict[str, Any]:
    commands: list[dict[str, Any]] = []
    for _ in range(5):
        result = describe_instances(cli_path, region, run_id=run_id)
        commands.append(result)
        if result["exit_code"] != 0:
            raise EcsError("ECS create recovery query failed", commands)
        instances = instances_from(result)
        if len(instances) == 1:
            instance_id = instances[0].get("InstanceId")
            if isinstance(instance_id, str) and instance_id:
                return {"instance_id": instance_id, "commands": commands}
        if len(instances) > 1:
            raise EcsError("multiple ECS instances match one run ID", commands)
        _pause(1)
    return {"instance_id": None, "commands": commands}


def ecs_status(manifest: dict[str, Any]) -> dict[str, Any]:
    backend = manifest["backend"]
    resources = manifest.get("resources", [])
    if len(resources) != 1 or resources[0].get("kind") != "ecs":
        raise EcsError("ECS manifest does not contain one exact instance", [])
    result = describe_instances(
        backend["cli_path"],
        backend["region"],
        instance_id=resources[0]["id"],
    )
    instances = instances_from(result)
    if result["exit_code"] != 0:
        raise EcsError("ECS status query failed", [result])
    state = instances[0].get("Status", "Unknown") if len(instances) == 1 else "Absent"
    return {"commands": [result], "state": state, "present": len(instances) == 1}


def ecs_public_endpoint(
    manifest: dict[str, Any], *, require_security_group: bool = False
) -> dict[str, Any]:
    backend = manifest.get("backend", {})
    resources = manifest.get("resources", [])
    if backend.get("kind") != "ecs":
        raise EcsError("transport refresh requires an ECS environment", [])
    if len(resources) != 1 or resources[0].get("kind") != "ecs":
        raise EcsError("ECS manifest does not contain one exact instance", [])
    instance_id = resources[0].get("id")
    if not isinstance(instance_id, str) or not instance_id:
        raise EcsError("ECS instance identity is missing", [])
    cli_path = backend.get("cli_path")
    region = backend.get("region")
    if not isinstance(cli_path, str) or not cli_path:
        raise EcsError("ECS CLI identity is missing", [])
    if not isinstance(region, str) or not region:
        raise EcsError("ECS region identity is missing", [])

    result = describe_instances(
        cli_path,
        region,
        instance_id=instance_id,
    )
    commands = [result]
    if result["exit_code"] != 0:
        raise EcsError("ECS endpoint query failed", commands)
    instances = instances_from(result)
    total = result.get("payload", {}).get("TotalCount")
    if type(total) is not int or total != 1 or len(instances) != 1:
        raise EcsError("ECS endpoint query did not return one instance", commands)
    instance = instances[0]
    if instance.get("InstanceId") != instance_id:
        raise EcsError("ECS endpoint instance identity mismatch", commands)
    if instance.get("Status") != "Running":
        raise EcsError("ECS endpoint instance is not Running", commands)
    if require_security_group:
        expected_security_group = backend.get("security_group_id")
        if not isinstance(expected_security_group, str) or not expected_security_group:
            raise EcsError("ECS security group identity is missing", commands)
        security_group_section = instance.get("SecurityGroupIds")
        if not isinstance(security_group_section, dict):
            raise EcsError("ECS security group response is malformed", commands)
        security_groups = security_group_section.get("SecurityGroupId")
        if (
            not isinstance(security_groups, list)
            or any(not isinstance(value, str) or not value for value in security_groups)
            or security_groups != [expected_security_group]
        ):
            raise EcsError("ECS security group identity mismatch", commands)

    public_section = instance.get("PublicIpAddress")
    if public_section is None:
        public_section = {}
    if not isinstance(public_section, dict):
        raise EcsError("ECS public address response is malformed", commands)
    public_values = public_section.get("IpAddress", [])
    if not isinstance(public_values, list) or any(
        not isinstance(value, str) or not value for value in public_values
    ):
        raise EcsError("ECS public address response is malformed", commands)
    candidates = set(public_values)
    eip_section = instance.get("EipAddress")
    if eip_section is None:
        eip_section = {}
    if not isinstance(eip_section, dict):
        raise EcsError("ECS EIP response is malformed", commands)
    eip = eip_section.get("IpAddress")
    if eip is not None and not isinstance(eip, str):
        raise EcsError("ECS EIP response is malformed", commands)
    if eip:
        candidates.add(eip)
    if len(candidates) != 1:
        raise EcsError("ECS endpoint requires one public address", commands)
    public_host = next(iter(candidates))
    try:
        address = ipaddress.ip_address(public_host)
    except ValueError as error:
        raise EcsError("ECS endpoint public address is invalid", commands) from error
    if address.version != 4 or not address.is_global:
        raise EcsError("ECS endpoint address is not a public IPv4 address", commands)
    return {
        "commands": commands,
        "instance_id": instance_id,
        "public_host": public_host,
        "payload": result["payload"],
    }


def invocation_results(payload: dict[str, Any]) -> list[dict[str, Any]]:
    candidates = (
        payload.get("Invocation", {}).get("InvocationResults", {}),
        payload.get("InvocationResults", {}),
    )
    for candidate in candidates:
        results = candidate.get("InvocationResult", [])
        if isinstance(results, list):
            return results
    return []


def invocations_from(payload: dict[str, Any]) -> list[dict[str, Any]]:
    invocations = payload.get("Invocations", {}).get("Invocation", [])
    return invocations if isinstance(invocations, list) else []


def recover_invocation(
    cli_path: str,
    region: str,
    instance_id: str,
    command_name: str,
) -> dict[str, Any]:
    commands = []
    invoke_id = None
    for _ in range(120):
        result = aliyun_call(
            cli_path,
            "DescribeInvocations",
            [
                "--RegionId",
                region,
                "--InstanceId",
                instance_id,
                "--CommandName",
                command_name,
            ],
        )
        commands.append(result)
        if result["exit_code"] != 0:
            raise EcsError("Cloud Assistant invocation recovery failed", commands)
        matches = [
            item
            for item in invocations_from(result["payload"])
            if item.get("CommandName") == command_name
        ]
        if len(matches) > 1:
            raise EcsError(
                "multiple Cloud Assistant invocations match command",
                commands,
            )
        candidate = matches[0].get("InvokeId") if matches else None
        if isinstance(candidate, str) and candidate:
            invoke_id = candidate
            break
        _pause(0.5)
    return {
        "invoke_id": invoke_id,
        "commands": commands,
    }


def stop_ecs_invocation(
    manifest: dict[str, Any],
    invoke_id: str | None = None,
) -> dict[str, Any] | None:
    invocations = manifest.get("invocations", [])
    if not invocations:
        return None
    invocation = next(
        (
            item
            for item in reversed(invocations)
            if item.get("status") in {"submitted", "active"}
            and (invoke_id is None or item.get("invoke_id") == invoke_id)
        ),
        None,
    )
    if invocation is None:
        return None
    selected_invoke_id = invocation.get("invoke_id")
    if not isinstance(selected_invoke_id, str) or not selected_invoke_id:
        return None
    backend = manifest["backend"]
    result = aliyun_call(
        backend["cli_path"],
        "StopInvocation",
        [
            "--RegionId",
            backend["region"],
            "--InvokeId",
            selected_invoke_id,
        ],
    )
    if result["exit_code"] != 0:
        raise EcsError("Cloud Assistant StopInvocation failed", [result])
    invocation["status"] = "stop-requested"
    result["invoke_id"] = selected_invoke_id
    commands = [redact_cloud_assistant_record(result)]
    for _ in range(15):
        confirmation = aliyun_call(
            backend["cli_path"],
            "DescribeInvocationResults",
            [
                "--RegionId",
                backend["region"],
                "--InvokeId",
                selected_invoke_id,
            ],
        )
        commands.append(redact_cloud_assistant_record(confirmation))
        if confirmation["exit_code"] != 0:
            raise EcsError("Cloud Assistant stop confirmation failed", commands)
        statuses = {
            item.get("InvocationStatus")
            for item in invocation_results(confirmation["payload"])
        }
        terminal = statuses & {"Stopped", "Finished", "Success", "Failed"}
        if terminal:
            invocation["status"] = "completed"
            result["terminal_status"] = sorted(terminal)[0]
            result["confirmations"] = commands[1:]
            return result
        _pause(1)
    raise EcsError("Cloud Assistant stop remains unconfirmed", commands)


def redact_cloud_assistant_record(result: dict[str, Any]) -> dict[str, Any]:
    redacted = copy.deepcopy(result)
    argv = redacted.get("argv", [])
    if "--CommandContent" in argv:
        index = argv.index("--CommandContent") + 1
        if index < len(argv):
            argv[index] = "[REDACTED]"
    if "--Content" in argv:
        index = argv.index("--Content") + 1
        if index < len(argv):
            argv[index] = "[REDACTED]"
    if len(argv) > 2 and argv[2] == "DescribeInvocationResults":
        redacted["stdout"] = ""
        redacted["payload"] = {"redacted": True}
    return redacted


def send_file_statuses(payload: Any) -> list[str]:
    statuses = []
    if isinstance(payload, dict):
        status = payload.get("InvocationStatus")
        if isinstance(status, str):
            statuses.append(status)
        for value in payload.values():
            statuses.extend(send_file_statuses(value))
    elif isinstance(payload, list):
        for value in payload:
            statuses.extend(send_file_statuses(value))
    return statuses


def ecs_send_file(
    manifest: dict[str, Any],
    *,
    target_dir: str,
    file_name: str,
    content: bytes,
    execution_id: str,
    on_invoke: Callable[[str, str, str], None] | None = None,
) -> list[dict[str, Any]]:
    if len(content) > 24 * 1024:
        raise EcsError("Cloud Assistant file chunk exceeds 24 KiB", [])
    backend = manifest["backend"]
    instance_id = manifest["resources"][0]["id"]
    encoded = base64.b64encode(content).decode()
    request_hash = hashlib.sha256(
        (
            manifest["run_id"]
            + "\0"
            + execution_id
            + "\0"
            + target_dir
            + "\0"
            + file_name
        ).encode()
    ).hexdigest()[:32]
    client_token = f"cosh-lab-file-{request_hash}"
    file_task_name = file_name
    parameters = [
            "--RegionId",
            backend["region"],
            "--Name",
            file_task_name,
            "--ClientToken",
            client_token,
            "--Description",
            f"cosh-lab {execution_id}",
            "--TargetDir",
            target_dir,
            "--Content",
            encoded,
            "--ContentType",
            "Base64",
            "--Overwrite",
            "true",
            "--Timeout",
            "60",
            "--InstanceId.1",
            instance_id,
        ]
    if on_invoke:
        on_invoke("", file_task_name, client_token)
    try:
        result = aliyun_call(
            backend["cli_path"],
            "SendFile",
            parameters,
        )
    except KeyboardInterrupt as error:
        commands = []
        recovered_id = None
        for _ in range(120):
            try:
                recovery = aliyun_call(
                    backend["cli_path"],
                    "DescribeSendFileResults",
                    [
                        "--RegionId",
                        backend["region"],
                        "--InstanceId",
                        instance_id,
                        "--Name",
                        file_task_name,
                        "--MaxResults",
                        "2",
                    ],
                )
            except KeyboardInterrupt:
                continue
            commands.append(redact_cloud_assistant_record(recovery))
            invoke_ids = []

            def collect_invoke_ids(value: Any) -> None:
                if isinstance(value, dict):
                    recovered = value.get("InvokeId")
                    if isinstance(recovered, str) and recovered:
                        invoke_ids.append(recovered)
                    for child in value.values():
                        collect_invoke_ids(child)
                elif isinstance(value, list):
                    for child in value:
                        collect_invoke_ids(child)

            collect_invoke_ids(recovery["payload"])
            unique_ids = sorted(set(invoke_ids))
            if len(unique_ids) > 1:
                raise EcsCommandInterrupted(commands) from error
            if len(unique_ids) == 1:
                recovered_id = unique_ids[0]
                if on_invoke:
                    on_invoke(recovered_id, file_task_name, client_token)
                break
            _pause(0.5)
        if recovered_id:
            for _ in range(120):
                try:
                    terminal = aliyun_call(
                        backend["cli_path"],
                        "DescribeSendFileResults",
                        [
                            "--RegionId",
                            backend["region"],
                            "--InvokeId",
                            recovered_id,
                        ],
                    )
                except KeyboardInterrupt:
                    continue
                commands.append(redact_cloud_assistant_record(terminal))
                statuses = set(send_file_statuses(terminal["payload"]))
                if statuses & {
                    "Success",
                    "Finished",
                    "Failed",
                    "Stopped",
                }:
                    if on_invoke and hasattr(on_invoke, "complete"):
                        on_invoke.complete(recovered_id)
                    break
                _pause(1)
        raise EcsCommandInterrupted(commands) from error
    commands = [redact_cloud_assistant_record(result)]
    invoke_id = result["payload"].get("InvokeId")
    if result["exit_code"] != 0 or not invoke_id:
        raise EcsError("Cloud Assistant SendFile failed", commands)
    if on_invoke:
        on_invoke(invoke_id, file_task_name, client_token)

    def await_terminal_after_interrupt(error: KeyboardInterrupt) -> None:
        for _ in range(60):
            try:
                terminal = aliyun_call(
                    backend["cli_path"],
                    "DescribeSendFileResults",
                    [
                        "--RegionId",
                        backend["region"],
                        "--InvokeId",
                        invoke_id,
                    ],
                )
            except KeyboardInterrupt:
                continue
            commands.append(redact_cloud_assistant_record(terminal))
            terminal_statuses = set(send_file_statuses(terminal["payload"]))
            if terminal_statuses & {
                "Success",
                "Finished",
                "Failed",
                "Stopped",
            }:
                if on_invoke and hasattr(on_invoke, "complete"):
                    on_invoke.complete(invoke_id)
                raise EcsCommandInterrupted(commands) from error
            try:
                _pause(1)
            except KeyboardInterrupt:
                continue
        raise EcsCommandInterrupted(commands) from error

    for _ in range(60):
        try:
            describe = aliyun_call(
                backend["cli_path"],
                "DescribeSendFileResults",
                [
                    "--RegionId",
                    backend["region"],
                    "--InvokeId",
                    invoke_id,
                ],
            )
        except KeyboardInterrupt as error:
            await_terminal_after_interrupt(error)
        commands.append(redact_cloud_assistant_record(describe))
        statuses = set(send_file_statuses(describe["payload"]))
        if statuses & {"Success", "Finished"}:
            if on_invoke and hasattr(on_invoke, "complete"):
                on_invoke.complete(invoke_id)
            return commands
        if statuses & {"Failed", "Stopped"}:
            if on_invoke and hasattr(on_invoke, "complete"):
                on_invoke.complete(invoke_id)
            raise EcsError("Cloud Assistant SendFile failed", commands)
        try:
            _pause(2)
        except KeyboardInterrupt as error:
            await_terminal_after_interrupt(error)
    raise EcsError(
        "Cloud Assistant SendFile timed out",
        commands,
        active_invoke_id=invoke_id,
    )


def ecs_upload_file(
    manifest: dict[str, Any],
    local_path: Path,
    remote_path: str,
    execution_id: str,
    on_invoke: Callable[[str, str, str], None] | None = None,
) -> dict[str, Any]:
    content_hash = hashlib.sha256(local_path.read_bytes()).hexdigest()
    size = local_path.stat().st_size
    transfer_hash = hashlib.sha256(
        (manifest["run_id"] + "\0" + execution_id).encode()
    ).hexdigest()[:24]
    target_dir = f"/tmp/.cosh-lab-transfer-{transfer_hash}"
    commands = []
    staging = f"{remote_path}.cosh-lab-{transfer_hash}.tmp"

    def cleanup_failed_transfer() -> None:
        cleanup = ecs_exec(
            manifest,
            ["rm", "-rf", target_dir, staging],
            execution_id=f"{execution_id}-cleanup",
            on_invoke=on_invoke,
        )
        commands.extend(cleanup["commands"])

    try:
        with local_path.open("rb") as source:
            index = 0
            while True:
                chunk = source.read(24 * 1024)
                if not chunk and index:
                    break
                commands.extend(
                    ecs_send_file(
                        manifest,
                        target_dir=target_dir,
                        file_name=f"chunk-{index:06d}",
                        content=chunk,
                        execution_id=f"{execution_id}-{index}",
                        on_invoke=on_invoke,
                    )
                )
                index += 1
                if not chunk:
                    break
        script = (
            'set -eu; directory=$1; staging=$2; target=$3; expected=$4; '
            'mkdir -p "$(dirname "$target")"; '
            'cat "$directory"/chunk-* >"$staging"; '
            'actual=$(sha256sum "$staging" | awk \'{print $1}\'); '
            '[ "$actual" = "$expected" ]; mv -f "$staging" "$target"; '
            'rm -rf "$directory"; printf "%s\\n" "$actual"'
        )
        result = ecs_exec(
            manifest,
            [
                "sh",
                "-lc",
                script,
                "cosh-lab-upload",
                target_dir,
                staging,
                remote_path,
                content_hash,
            ],
            execution_id=f"{execution_id}-assemble",
            on_invoke=on_invoke,
        )
        commands.extend(result["commands"])
        if result["exit_code"] != 0 or result["stdout"].strip() != content_hash:
            raise EcsError("Cloud Assistant upload verification failed", commands)
    except KeyboardInterrupt as error:
        commands.extend(getattr(error, "commands", []))
        cleanup_safe = getattr(error, "cleanup_safe", True)
        try:
            stopped = stop_ecs_invocation(manifest)
            if stopped is not None:
                commands.append(redact_cloud_assistant_record(stopped))
        except EcsError as stop_error:
            commands.extend(stop_error.commands)
            cleanup_safe = False
        if cleanup_safe:
            try:
                cleanup_failed_transfer()
            except (EcsError, KeyboardInterrupt) as cleanup_error:
                commands.extend(getattr(cleanup_error, "commands", []))
        raise EcsCommandInterrupted(commands, cleanup_safe=cleanup_safe) from error
    except EcsError as error:
        if error.commands is not commands:
            commands.extend(error.commands)
        cleanup_safe = True
        active_invoke_id = getattr(error, "active_invoke_id", None)
        if active_invoke_id:
            try:
                stopped = stop_ecs_invocation(manifest, active_invoke_id)
                if stopped is not None:
                    commands.append(redact_cloud_assistant_record(stopped))
                else:
                    cleanup_safe = False
            except (EcsError, KeyboardInterrupt) as stop_error:
                commands.extend(getattr(stop_error, "commands", []))
                cleanup_safe = False
        if cleanup_safe:
            try:
                cleanup_failed_transfer()
            except (EcsError, KeyboardInterrupt) as cleanup_error:
                commands.extend(getattr(cleanup_error, "commands", []))
        raise EcsError(str(error), commands, cleanup_safe=cleanup_safe) from error
    return {
        "commands": commands,
        "exit_code": 0,
        "stdout": "",
        "stderr": "",
        "size": size,
        "sha256": content_hash,
        "chunk_count": index,
        "transport": "assistant",
    }


def ecs_download_file(
    manifest: dict[str, Any],
    remote_path: str,
    local_path: Path,
    execution_id: str,
    on_invoke: Callable[[str, str, str], None] | None = None,
) -> dict[str, Any]:
    metadata = ecs_exec(
        manifest,
        [
            "sh",
            "-lc",
            'stat -c %s "$1"; sha256sum "$1" | awk \'{print $1}\'',
            "cosh-lab-download",
            remote_path,
        ],
        execution_id=f"{execution_id}-metadata",
        on_invoke=on_invoke,
    )
    commands = list(metadata["commands"])
    lines = metadata["stdout"].splitlines()
    if (
        metadata["exit_code"] != 0
        or len(lines) != 2
        or not lines[0].isdigit()
        or not re.fullmatch(r"[0-9a-f]{64}", lines[1])
    ):
        raise EcsError("Cloud Assistant download metadata failed", commands)
    size = int(lines[0])
    expected = lines[1]
    chunk_size = 12 * 1024
    digest = hashlib.sha256()
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(local_path, flags, 0o600)
    try:
        with os.fdopen(descriptor, "wb") as destination:
            for index, offset in enumerate(range(0, size, chunk_size)):
                count = min(chunk_size, size - offset)
                chunk_result = ecs_exec(
                    manifest,
                    [
                        "sh",
                        "-lc",
                        'dd if="$1" bs=1 skip="$2" count="$3" status=none | base64 -w0',
                        "cosh-lab-download",
                        remote_path,
                        str(offset),
                        str(count),
                    ],
                    execution_id=f"{execution_id}-chunk-{index}",
                    on_invoke=on_invoke,
                )
                commands.extend(chunk_result["commands"])
                try:
                    chunk = base64.b64decode(
                        chunk_result["stdout"].strip(),
                        validate=True,
                    )
                except (ValueError, TypeError) as error:
                    raise EcsError(
                        "Cloud Assistant download chunk is invalid",
                        commands,
                    ) from error
                if chunk_result["exit_code"] != 0 or len(chunk) != count:
                    raise EcsError(
                        "Cloud Assistant download chunk failed",
                        commands,
                    )
                destination.write(chunk)
                digest.update(chunk)
    except (EcsError, KeyboardInterrupt, OSError):
        local_path.unlink(missing_ok=True)
        raise
    if digest.hexdigest() != expected:
        local_path.unlink(missing_ok=True)
        raise EcsError("Cloud Assistant download verification failed", commands)
    return {
        "commands": commands,
        "exit_code": 0,
        "stdout": "",
        "stderr": "",
        "size": size,
        "sha256": expected,
        "chunk_count": (size + chunk_size - 1) // chunk_size,
        "transport": "assistant",
    }


def ecs_exec(
    manifest: dict[str, Any],
    command: list[str],
    execution_id: str,
    on_invoke: Callable[[str, str, str], None] | None = None,
) -> dict[str, Any]:
    backend = manifest["backend"]
    resources = manifest.get("resources", [])
    if len(resources) != 1 or resources[0].get("kind") != "ecs":
        raise EcsError("ECS manifest does not contain one exact instance", [])
    instance_id = resources[0]["id"]
    cli_path = backend["cli_path"]
    region = backend["region"]
    content = base64.b64encode(("exec " + shlex.join(command)).encode()).decode()
    request_hash = hashlib.sha256(
        (
            manifest["run_id"]
            + "\0"
            + execution_id
            + "\0"
            + shlex.join(command)
        ).encode()
    ).hexdigest()[:32]
    client_token = f"cosh-lab-cmd-{request_hash}"
    command_name = f"cosh-lab-{request_hash}"
    command_timeout_seconds = 1800
    terminal_statuses = {"Finished", "Success", "Failed", "Stopped", "Terminated"}
    commands = []
    if on_invoke:
        on_invoke("", command_name, client_token)
    # Include submission and polling API time in the existing command budget.
    deadline = time.monotonic() + command_timeout_seconds
    try:
        run_result = aliyun_call(
            cli_path,
            "RunCommand",
            [
                "--RegionId",
                region,
                "--Name",
                command_name,
                "--ClientToken",
                client_token,
                "--Type",
                "RunShellScript",
                "--CommandContent",
                content,
                "--ContentEncoding",
                "Base64",
                "--InstanceId.1",
                instance_id,
                "--Timeout",
                str(command_timeout_seconds),
            ],
        )
    except KeyboardInterrupt as error:
        try:
            recovery = recover_invocation(
                cli_path,
                region,
                instance_id,
                command_name,
            )
            commands.extend(recovery["commands"])
            if recovery["invoke_id"] and on_invoke:
                on_invoke(recovery["invoke_id"], command_name, client_token)
        except EcsError as recovery_error:
            commands.extend(recovery_error.commands)
        raise EcsCommandInterrupted(commands) from error
    commands.append(redact_cloud_assistant_record(run_result))
    invoke_id = run_result["payload"].get("InvokeId")
    if run_result["exit_code"] != 0 or not invoke_id:
        raise EcsError("Cloud Assistant RunCommand failed", commands)
    if on_invoke:
        on_invoke(invoke_id, command_name, client_token)

    while time.monotonic() < deadline:
        describe = aliyun_call(
            cli_path,
            "DescribeInvocationResults",
            ["--RegionId", region, "--InvokeId", invoke_id],
        )
        commands.append(redact_cloud_assistant_record(describe))
        results = invocation_results(describe["payload"])
        if len(results) == 1:
            status = results[0].get("InvocationStatus")
            if status in terminal_statuses:
                result = results[0]
                output = result.get("Output", "")
                try:
                    stdout = base64.b64decode(output).decode("utf-8", errors="replace")
                except (ValueError, TypeError):
                    stdout = ""
                raw_exit_code = result.get("ExitCode")
                exit_code = int(raw_exit_code) if raw_exit_code is not None else 1
                if status not in {"Finished", "Success"} and exit_code == 0:
                    exit_code = 1
                if on_invoke and hasattr(on_invoke, "complete"):
                    on_invoke.complete(invoke_id)
                return {
                    "commands": commands,
                    "argv": command,
                    "exit_code": exit_code,
                    "duration_seconds": round(
                        sum(item["duration_seconds"] for item in commands),
                        6,
                    ),
                    "stdout": stdout,
                    "stderr": str(result.get("ErrorInfo", "")),
                    "invoke_id": invoke_id,
                }
        remaining = deadline - time.monotonic()
        if remaining > 0:
            _pause(min(2, remaining))
    stop = aliyun_call(
        cli_path,
        "StopInvocation",
        ["--RegionId", region, "--InvokeId", invoke_id],
    )
    commands.append(redact_cloud_assistant_record(stop))
    if stop["exit_code"] != 0:
        raise EcsError(
            "Cloud Assistant invocation timed out and StopInvocation failed",
            commands,
        )
    stop_deadline = time.monotonic() + 15
    while time.monotonic() < stop_deadline:
        confirmation = aliyun_call(
            cli_path,
            "DescribeInvocationResults",
            ["--RegionId", region, "--InvokeId", invoke_id],
        )
        commands.append(redact_cloud_assistant_record(confirmation))
        if confirmation["exit_code"] != 0:
            raise EcsError(
                "Cloud Assistant stop confirmation failed",
                commands,
            )
        statuses = {
            item.get("InvocationStatus")
            for item in invocation_results(confirmation["payload"])
        }
        if statuses & terminal_statuses:
            if on_invoke and hasattr(on_invoke, "complete"):
                on_invoke.complete(invoke_id)
            raise EcsError(
                "Cloud Assistant invocation timed out; terminal status confirmed",
                commands,
            )
        remaining = stop_deadline - time.monotonic()
        if remaining > 0:
            _pause(min(1, remaining))
    raise EcsError(
        "Cloud Assistant invocation timed out; stop remains unconfirmed",
        commands,
    )


def build_run_parameters(
    profile: dict[str, Any],
    run_id: str,
) -> tuple[list[str], dict[str, Any]]:
    ecs = profile["ecs"]
    auth = profile["auth"]
    client_token = f"cosh-lab-{hashlib.sha256(run_id.encode()).hexdigest()[:32]}"
    auto_release = datetime.now(timezone.utc) + timedelta(
        minutes=ecs["max_lifetime_minutes"]
    )
    auto_release_value = auto_release.replace(second=0, microsecond=0).strftime(
        "%Y-%m-%dT%H:%M:%SZ"
    )
    expires_at = auto_release_value
    bandwidth = ecs["internet_max_bandwidth_out"]
    parameters = [
        "--RegionId",
        ecs["region"],
        "--ImageId",
        ecs["image_id"],
        "--InstanceType",
        ecs["instance_type"],
        "--SecurityGroupId",
        ecs["security_group_id"],
        "--VSwitchId",
        ecs["vswitch_id"],
        "--RamRoleName",
        auth["ram_role_name"],
        "--SystemDisk.Category",
        ecs["system_disk_category"],
        "--InstanceChargeType",
        "PostPaid",
        "--InternetMaxBandwidthOut",
        str(bandwidth),
        "--Amount",
        "1",
        "--ClientToken",
        client_token,
        "--HttpEndpoint",
        "enabled",
        "--HttpTokens",
        "required",
        "--DeletionProtection",
        "false",
        "--AutoReleaseTime",
        auto_release_value,
        "--Tag.1.Key",
        "managed-by",
        "--Tag.1.Value",
        "cosh-lab",
        "--Tag.2.Key",
        "run-id",
        "--Tag.2.Value",
        run_id,
        "--Tag.3.Key",
        "expires-at",
        "--Tag.3.Value",
        expires_at,
    ]
    if bandwidth == 1:
        parameters.extend(("--InternetChargeType", "PayByTraffic"))
    return parameters, {
        "client_token": client_token,
        "auto_release_time": auto_release_value,
        "internet_max_bandwidth_out": bandwidth,
        "tags": {
            "managed-by": "cosh-lab",
            "run-id": run_id,
            "expires-at": expires_at,
        },
    }


def plan_or_create_ecs(
    profile: dict[str, Any],
    run_id: str,
    apply: bool,
    on_plan: Callable[[dict[str, Any], str, list[dict[str, Any]]], None] | None = None,
    on_instance: Callable[[str, dict[str, Any], str], None] | None = None,
) -> dict[str, Any]:
    cli_path = shutil.which("aliyun")
    if cli_path is None:
        raise EcsError("aliyun CLI is unavailable", [])
    ecs = profile["ecs"]
    commands: list[dict[str, Any]] = []
    price_network_parameters = [
        "--InternetMaxBandwidthOut",
        str(ecs["internet_max_bandwidth_out"]),
    ]
    if ecs["internet_max_bandwidth_out"] == 1:
        price_network_parameters.extend(
            ("--InternetChargeType", "PayByTraffic")
        )

    price_result = aliyun_call(
        cli_path,
        "DescribePrice",
        [
            "--RegionId",
            ecs["region"],
            "--ResourceType",
            "instance",
            "--InstanceType",
            ecs["instance_type"],
            "--Amount",
            "1",
            "--PriceUnit",
            "Hour",
            "--Period",
            "1",
            "--SystemDisk.Category",
            ecs["system_disk_category"],
            *price_network_parameters,
        ],
    )
    commands.append(price_result)
    if price_result["exit_code"] != 0:
        raise EcsError("ECS price query failed", commands)
    price_payload = price_result["payload"].get("PriceInfo", {}).get("Price", {})
    hourly = price_payload.get("TradePrice")
    currency = price_payload.get("Currency")
    if not isinstance(hourly, (int, float)) or currency != ecs["cost"]["currency"]:
        raise EcsError(
            "ECS price response is incomplete or uses another currency", commands
        )
    worst_case = round(hourly * ecs["max_lifetime_minutes"] / 60, 6)
    if worst_case > ecs["cost"]["max_estimated_run"]:
        raise EcsError(
            f"worst-case ECS cost {worst_case} exceeds profile limit",
            commands,
        )

    count_result = describe_instances(cli_path, ecs["region"])
    commands.append(count_result)
    if count_result["exit_code"] != 0:
        raise EcsError("cannot count tool-owned ECS instances", commands)
    active_count = int(count_result["payload"].get("TotalCount", 0))
    if active_count >= ecs["max_parallel_instances"]:
        raise EcsError("tool-owned ECS concurrency limit reached", commands)

    try:
        commands.extend(require_ecs_resources(cli_path, profile))
    except EcsError as error:
        commands.extend(error.commands)
        raise EcsError(str(error), commands) from error

    run_parameters, request = build_run_parameters(profile, run_id)
    dry_run_result = aliyun_call(
        cli_path,
        "RunInstances",
        [*run_parameters, "--DryRun", "true"],
    )
    commands.append(dry_run_result)
    if dry_run_result["payload"].get("Code") != "DryRunOperation":
        raise EcsError("ECS API DryRun did not pass", commands)

    plan = {
        "backend": "ecs",
        "amount": 1,
        "active_count": active_count,
        "max_parallel_instances": ecs["max_parallel_instances"],
        "price": {
            "hourly": hourly,
            "currency": currency,
            "worst_case": worst_case,
            "limit": ecs["cost"]["max_estimated_run"],
        },
        **request,
    }
    if on_plan:
        on_plan(plan, cli_path, list(commands))
    if not apply:
        return {
            "commands": commands,
            "plan": plan,
            "instance_id": None,
            "cli_path": cli_path,
        }

    create_result = aliyun_call(cli_path, "RunInstances", run_parameters)
    commands.append(create_result)
    instance_ids = (
        create_result["payload"].get("InstanceIdSets", {}).get("InstanceIdSet", [])
    )
    instance_id = (
        instance_ids[0]
        if create_result["exit_code"] == 0 and len(instance_ids) == 1
        else None
    )
    if instance_id is None:
        recovery = describe_instances(
            cli_path,
            ecs["region"],
            run_id=run_id,
        )
        commands.append(recovery)
        recovered = instances_from(recovery)
        if len(recovered) == 1:
            instance_id = recovered[0].get("InstanceId")
        elif not recovered:
            retry = aliyun_call(cli_path, "RunInstances", run_parameters)
            commands.append(retry)
            retry_ids = (
                retry["payload"]
                .get("InstanceIdSets", {})
                .get(
                    "InstanceIdSet",
                    [],
                )
            )
            if retry["exit_code"] == 0 and len(retry_ids) == 1:
                instance_id = retry_ids[0]
        if not instance_id:
            raise EcsError("cannot recover ECS create result", commands)

    if on_instance:
        on_instance(instance_id, plan, cli_path)

    post_create_count = describe_instances(cli_path, ecs["region"])
    commands.append(post_create_count)
    if post_create_count["exit_code"] != 0:
        raise EcsError("cannot verify ECS concurrency after create", commands)
    post_create_total = int(post_create_count["payload"].get("TotalCount", 0))
    if post_create_total > ecs["max_parallel_instances"]:
        rollback = aliyun_call(
            cli_path,
            "DeleteInstance",
            ["--InstanceId", instance_id, "--Force", "true"],
        )
        commands.append(rollback)
        if rollback["exit_code"] != 0:
            raise EcsError(
                "ECS concurrency exceeded and rollback failed",
                commands,
            )
        raise EcsError(
            "ECS concurrency exceeded after create; new instance rolled back",
            commands,
        )

    running_instance = None
    for _ in range(30):
        status_result = describe_instances(
            cli_path,
            ecs["region"],
            instance_id=instance_id,
        )
        commands.append(status_result)
        instances = instances_from(status_result)
        if len(instances) == 1 and instances[0].get("Status") == "Running":
            running_instance = instances[0]
            break
        _pause(2)
    else:
        raise EcsError("ECS instance did not reach Running", commands)

    for _ in range(3):
        settled_count = describe_instances(cli_path, ecs["region"])
        commands.append(settled_count)
        if settled_count["exit_code"] != 0:
            raise EcsError(
                "cannot verify settled ECS concurrency",
                commands,
            )
        settled_total = int(settled_count["payload"].get("TotalCount", 0))
        if settled_total > ecs["max_parallel_instances"]:
            rollback = aliyun_call(
                cli_path,
                "DeleteInstance",
                ["--InstanceId", instance_id, "--Force", "true"],
            )
            commands.append(rollback)
            if rollback["exit_code"] != 0:
                raise EcsError(
                    "settled ECS concurrency exceeded and rollback failed",
                    commands,
                )
            raise EcsError(
                "settled ECS concurrency exceeded; new instance rolled back",
                commands,
            )
        _pause(2)

    return {
        "commands": commands,
        "plan": plan,
        "instance_id": instance_id,
        "instance": running_instance,
        "cli_path": cli_path,
    }


def cleanup_ecs(manifest: dict[str, Any]) -> dict[str, Any]:
    backend = manifest["backend"]
    resources = manifest.get("resources", [])
    cli_path = backend["cli_path"]
    region = backend["region"]
    commands: list[dict[str, Any]] = []
    if not resources:
        recovery = recover_instance_by_run(
            cli_path,
            region,
            manifest["run_id"],
        )
        commands.extend(recovery["commands"])
        if recovery["instance_id"] is None:
            raise EcsError(
                "cannot prove ECS absence for a persisted create intent",
                commands,
            )
        resources = [{"kind": "ecs", "id": recovery["instance_id"]}]
        manifest["resources"] = resources
    if len(resources) != 1 or resources[0].get("kind") != "ecs":
        raise EcsError("ECS manifest does not contain one exact instance", [])
    instance_id = resources[0]["id"]

    def confirm_absent() -> bool:
        consecutive = 0
        for _ in range(5):
            by_id = describe_instances(
                cli_path,
                region,
                instance_id=instance_id,
            )
            by_run = describe_instances(
                cli_path,
                region,
                run_id=manifest["run_id"],
            )
            commands.extend((by_id, by_run))
            if by_id["exit_code"] != 0 or by_run["exit_code"] != 0:
                raise EcsError(
                    "ECS DescribeInstances failed while confirming absence",
                    commands,
                )
            if not instances_from(by_id) and not instances_from(by_run):
                consecutive += 1
                if consecutive == 3:
                    return True
            else:
                consecutive = 0
            _pause(1)
        return False

    before = describe_instances(cli_path, region, instance_id=instance_id)
    commands.append(before)
    if before["exit_code"] != 0:
        raise EcsError("ECS DescribeInstances failed before cleanup", commands)
    instances = instances_from(before)
    if not instances:
        if confirm_absent():
            return {"commands": commands, "remaining": 0}
        raise EcsError("cannot prove ECS instance absence", commands)
    tags = {
        item.get("TagKey"): item.get("TagValue")
        for item in instances[0].get("Tags", {}).get("Tag", [])
    }
    if tags.get("managed-by") != "cosh-lab":
        raise EcsError(
            "refusing to delete ECS instance without ownership tag", commands
        )
    if tags.get("run-id") != manifest.get("run_id"):
        raise EcsError(
            "refusing to delete ECS instance owned by another run",
            commands,
        )

    delete_result = aliyun_call(
        cli_path,
        "DeleteInstance",
        ["--InstanceId", instance_id, "--Force", "true"],
    )
    commands.append(delete_result)
    if delete_result["exit_code"] != 0:
        raise EcsError("ECS DeleteInstance failed", commands)

    if not confirm_absent():
        raise EcsError("ECS instance still exists after delete", commands)
    return {"commands": commands, "remaining": 0}
