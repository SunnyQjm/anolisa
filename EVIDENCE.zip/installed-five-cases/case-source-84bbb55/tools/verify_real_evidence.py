import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fixtures.production_contract import verify_real_join

parser=argparse.ArgumentParser()
parser.add_argument('--provider',required=True)
parser.add_argument('--observer',required=True)
args=parser.parse_args()
result=json.loads(Path(args.provider).read_text())
if result.get('ok') is not True:
    raise ValueError('canonical provider case is not successful')
verify_real_join(result['data']['provider_evidence'],json.loads(Path(args.observer).read_text()))
print(json.dumps({'functional_join':'PASS','real_provider_and_worker_observed':True,'U02_whole_contract':'not established by this join','visual_manual_review':'separate required evidence'}))
