# Issue 7891 immutable local evidence

Source review: [PR7979](https://github.com/agentic-os-org/ANOLISA/pull/7979).

Native source commit: `b353d6185b2abe0b99460430ccd7954bd4ce21ad`.
Tree: `cf23b75a2c151da8e85a16e44b3653422cbb4f7b`; Cosh subtree: `f1dbd5bd1cee77ee311a9a104aa539dcdd692afc`.

[Final measured report](local-linux/final-report.md) · [Acceptance JSON](local-linux/final-acceptance.json) · [Native source equivalence](local-linux/final-native-source-attestation.json) · [Final commit preflight](local-linux/final-b353d-preflight/audit.json) · [Cleanup](local-linux/final-owned-cleanup-audit.json).

The first full raw run was610PASS/16FAIL/1ignored. After correcting only owned test environment prerequisites, the unchanged command returned626PASS/0FAIL/1originalignored. Both complete results are retained. R5 production23/debug34 and six installed named tests, real compiling mutation controls, two installed canonical cases/eight points, and native RPM lifecycle are separately classified in the report. Protocol Core fixtures are not actual release Core evidence; the deny inline-reference leg uses the explicit debug reference.

`0.27.0-2.alnx4` and `0.27.1-2.alnx4` are local transaction VERSION overrides. The first is built from pristine a37 baseline without a packaged worker; the second is built from the reviewed candidate. These RPM/SRPM files are test evidence, not formal release candidates. Final integrated dual-architecture, real-provider and login/release acceptance remain ParentRoot-owned.

Canonical capture repo.commit=null is retained honestly: the native supported case archive has no.git. Source0 file hashes, actual installed three-ELF hashes and fixture/YAML identity bind those captures externally. Original execution labels remain2b4/ec6349; the native rebase equivalence receipt binds identical source to finalb353d without relabeling old runs.

Baseline canonical084958 is incomplete/unattributed after two reached points; its legacy inline card is a real baseline screenshot, not proof that a worker existed or that the whole case passed. Definitive activation RED is the actual test expecting worker1 and observing0.

The two `bash-returned` screenshots are after the canonical fixture explicitly printsUI_BASH_READY and exits. They do not establish an idle prompt before input. That requirement is tested by the installed second-prompt-EIO case: original text/color/current line/caret assertions execute before ordinary input; the same Bash then executes ordinary input and a second request with one approved effect/HostResult. Its actual sidecars are under installed-pty.

Cast publication review found only fixture commands, loopback model output and terminal state; no credential input or credential-like material was found. Captures remain byte-identical to the verified rendered evidence. PNG/WebM provenance is included. U02a/b/c remain open for the explicitly missing broader witnesses/interfaces; seePRODUCTION-INTERFACES.json.
