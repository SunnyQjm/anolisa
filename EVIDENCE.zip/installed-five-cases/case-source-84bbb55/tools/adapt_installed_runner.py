import ast
import difflib
import hashlib
from pathlib import Path

ROOT = Path('/Users/quejianming/vscode/cosh-shell-dev')
OUT = Path(__file__).resolve().parents[1]
source = OUT / 'runtime/src/cosh_lab/cli.py'
before = source.read_text()
if "def installed_provider_binary(" in before:
    raise RuntimeError("already adapted; use the clean input snapshot to regenerate")
helper_sha = hashlib.sha256((OUT / 'fixtures/installed_identity.py').read_bytes()).hexdigest()
helper = 'def installed_provider_binary(environment_manifest, candidate_path, acceptance_run_id, on_invoke=None):\n    candidate_file = Path(candidate_path)\n    candidate = json.loads(candidate_file.read_text())\n    binding_path = os.environ.get(\'COSH_LAB_INSTALLED_BINDING_JSON\')\n    if not binding_path:\n        raise ValueError(\'Root installed binding is required\')\n    binding_file = Path(binding_path)\n    verifier = (\n        "import hashlib,pathlib,subprocess,sys; "\n        "root=pathlib.Path(\'/var/lib/cosh-production-accept\'); "\n        "helper=root/\'tools/fixtures/installed_identity.py\'; "\n        "contract=root/\'tools/fixtures/production_contract.py\'; "\n        "manifest=root/\'candidate.json\';binding=root/\'binding.json\'; "\n        "assert hashlib.sha256(helper.read_bytes()).hexdigest()==sys.argv[1]; "\n        "assert hashlib.sha256(contract.read_bytes()).hexdigest()==sys.argv[2]; "\n        "assert hashlib.sha256(manifest.read_bytes()).hexdigest()==sys.argv[3]; "\n        "assert hashlib.sha256(binding.read_bytes()).hexdigest()==sys.argv[4]; "\n        "subprocess.run([\'python3\',\'-B\',str(helper),str(manifest),str(binding)],check=True)"\n    )\n    result, commands = execute_in_environment(\n        environment_manifest,\n        [\'python3\', \'-B\', \'-c\', verifier, \'072607b7230c9f37e3415123c733d2555693793e9d7905c2e1eed18c7b0fdab6\', \'a5b0085793f7a37db7c09ee57ef50c58f24976e830e74e4076bbade27880c651\',\n         hashlib.sha256(candidate_file.read_bytes()).hexdigest(),\n         hashlib.sha256(binding_file.read_bytes()).hexdigest()],\n        execution_id=f\'{acceptance_run_id}-installed-rpm\', on_invoke=on_invoke,\n    )\n    if result[\'exit_code\'] != 0:\n        error = ValueError(\'installed release six-payload identity preflight failed\')\n        error.commands = commands\n        raise error\n    parsed = json.loads(result[\'stdout\'])\n    artifact = candidate[\'architectures\'][parsed[\'architecture\']]\n    if (parsed[\'source\'] != candidate[\'source\']\n            or parsed[\'rpm_sha256\'] != artifact[\'rpm_sha256\']\n            or parsed[\'rpm_nevra\'] != artifact[\'nevra\']\n            or parsed[\'payload_sha256\'] != artifact[\'payload_sha256\']):\n        raise ValueError(\'installed RPM differs from the new frozen input\')\n    parsed[\'isolated_build\'] = False\n    parsed[\'installed_manifest_sha256\'] = hashlib.sha256(candidate_file.read_bytes()).hexdigest()\n    parsed[\'build_attestation_sha256\'] = hashlib.sha256(\n        json.dumps({\'command\': result[\'argv\'], \'identity\': parsed},sort_keys=True).encode()).hexdigest()\n    return parsed, commands\n\n\n'
after = before.replace('def build_provider_binary(\n', helper + 'def build_provider_binary(\n', 1)
needle = '    if re.fullmatch(r"[0-9A-Za-z-]+", acceptance_run_id) is None:\n'
after = after.replace(needle, '''    installed_candidate = os.environ.get('COSH_LAB_INSTALLED_CANDIDATE_JSON')
    if installed_candidate:
        if re.fullmatch(r"[0-9A-Za-z-]+", acceptance_run_id) is None:
            raise ValueError("acceptance run ID is unsafe")
        return installed_provider_binary(environment_manifest, installed_candidate, acceptance_run_id, on_invoke)
''' + needle, 1)
after = after.replace('        or binary_preflight.get("isolated_build") is not True\n', '''        or not (
            binary_preflight.get("isolated_build") is True
            or (
                binary_preflight.get("binary_origin") == "installed-rpm"
                and resolved_path == "/usr/libexec/anolisa/cosh-ng/cosh-shell"
                and re.fullmatch(r"[0-9a-f]{64}", str(binary_preflight.get("installed_manifest_sha256", "")))
                and re.fullmatch(r"[0-9a-f]{64}", str(binary_preflight.get("rpm_sha256", "")))
                and binary_preflight.get("payload_sha256", {}).get(resolved_path) == binary_sha256
            )
        )
''', 1)
needle = '    timestamps = (\n        lifecycle.get("request_started_at"),\n'
after = after.replace(needle, '''    if binary_preflight.get("binary_origin") == "installed-rpm" and (
        argv[-3:] != [resolved_path, "raw", "cosh-core"]
        or argv[0] != "env"
        or "COSH_CORE_PATH=/usr/libexec/anolisa/cosh-ng/cosh-core" not in argv
    ):
        raise ValueError("installed RPM production argv differs from attested Shell/Core")
''' + needle, 1)
after = after.replace('        "argv": [resolved_path, *argv[1:]],', '        "argv": argv[argv.index(resolved_path):] if binary_preflight.get("binary_origin") == "installed-rpm" else [resolved_path, *argv[1:]],\n        "launch_argv": argv,\n        "core_path": "/usr/libexec/anolisa/cosh-ng/cosh-core" if binary_preflight.get("binary_origin") == "installed-rpm" else None,', 1)
after = after.replace('        "isolated_build": True,\n        "build_attestation_sha256": build_attestation_sha256,', '''        "isolated_build": binary_preflight.get("isolated_build") is True,
        "binary_origin": binary_preflight.get("binary_origin", "isolated-build"),
        "installed_manifest_sha256": binary_preflight.get("installed_manifest_sha256"),
        "rpm_sha256": binary_preflight.get("rpm_sha256"),
        "payload_sha256": binary_preflight.get("payload_sha256"),
        "build_attestation_sha256": build_attestation_sha256,''', 1)
assert after != before
ast.parse(after)
(OUT / 'cosh_lab_cli.installed.py').write_text(after)
(OUT / 'installed-provider-preflight.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='a/src/cosh_lab/cli.py', tofile='b/src/cosh_lab/cli.py')))
(OUT / 'runner-baseline.sha256').write_text(hashlib.sha256(source.read_bytes()).hexdigest() + '  ' + str(source) + '\n')
print('prepared syntax-valid test-only preflight patch; shared CLI untouched')

evidence_source = source.with_name('evidence.py')
evidence_before = evidence_source.read_text()
evidence_after = evidence_before.replace('            or provider_evidence.get("isolated_build") is not True\n', '\n'.join([
    '            or not (',
    '                provider_evidence.get("isolated_build") is True',
    '                or (',
    '                    provider_evidence.get("binary_origin") == "installed-rpm"',
    '                    and provider_evidence.get("core_path") == "/usr/libexec/anolisa/cosh-ng/cosh-core"',
    '                    and isinstance(argv, list) and argv and argv[0] == "/usr/libexec/anolisa/cosh-ng/cosh-shell"',
    '                    and re.fullmatch(r"[0-9a-f]{64}", str(provider_evidence.get("installed_manifest_sha256", "")))',
    '                    and re.fullmatch(r"[0-9a-f]{64}", str(provider_evidence.get("rpm_sha256", "")))',
    '                    and provider_evidence.get("payload_sha256", {}).get(argv[0]) == provider_evidence.get("binary_sha256")',
    '                    and re.fullmatch(r"[0-9a-f]{64}", str(provider_evidence.get("payload_sha256", {}).get(provider_evidence.get("core_path"), "")))',
    '                )',
    '            )',
    ''
]), 1)
ast.parse(evidence_after)
(OUT / 'cosh_lab_evidence.installed.py').write_text(evidence_after)
with (OUT / 'installed-provider-preflight.patch').open('a') as patch:
    patch.write(''.join(difflib.unified_diff(evidence_before.splitlines(True), evidence_after.splitlines(True), fromfile='a/src/cosh_lab/evidence.py', tofile='b/src/cosh_lab/evidence.py')))
