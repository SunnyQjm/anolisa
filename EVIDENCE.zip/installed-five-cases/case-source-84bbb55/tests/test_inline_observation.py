import sys
from pathlib import Path
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'fixtures'))
from inline_fixture import original_prompt, agent_row_observed, details_panel_observed, environment


class InlineObservationTests(unittest.TestCase):
    def snapshot(self):
        return {'plain':'old card\noriginal@bash:~$ \n','grid':'old card\n\x1b[32moriginal@bash:~$\x1b[0m \n','x':17,'y':1,'cursor_visible':True}

    def test_prompt_requires_current_row_color_cursor_and_foreground_bash(self):
        snap=self.snapshot();who={'pid':7,'start':1,'tty':'/dev/pts/2','foreground_pgrp':7,'pgrp':7}
        self.assertTrue(original_prompt(snap,who))
        for key,value in [('x',0),('y',0),('cursor_visible',False),('grid','old card\noriginal@bash:~$ \n')]:
            wrong=dict(snap);wrong[key]=value;self.assertFalse(original_prompt(wrong,who))
        for key,value in [('foreground_pgrp',8),('tty','/dev/null')]:
            wrong=dict(who);wrong[key]=value;self.assertFalse(original_prompt(snap,wrong))

    def test_echoed_or_incomplete_reply_is_not_an_agent_row(self):
        self.assertTrue(agent_row_observed('│ INL_MODEL_DONE \n','INL_MODEL_DONE'))
        for value in ['?? INL_MODEL_DONE','original@bash:~$ INL_MODEL_DONE','│ INL_MODEL_DO']:
            self.assertFalse(agent_row_observed(value,'INL_MODEL_DONE'))

    def test_details_focus_without_expanded_policy_is_not_details_success(self):
        selected='> [ Details ]\nINL_EFFECT\n'
        self.assertFalse(details_panel_observed(selected))
        self.assertFalse(details_panel_observed(selected+'old history Keys: Left/Right select  Enter confirm  d details  Esc cancel'))
        panel='╭ Approval required ─╮\n│ INL_EFFECT         │\n│ > [ Details ]      │\n│ Keys: Left/Right select  Enter confirm  d details  Esc cancel │\n│ Default: deny. Approved command is rechecked by read-only broker. │\n╰────────────────────╯'
        self.assertTrue(details_panel_observed(panel))

    def test_inner_environment_preserves_native_bashrc_entry(self):
        values=environment(Path('/tmp/owned'),1234)
        self.assertFalse('COSH_SHELL_ISOLATED' in values)
        self.assertFalse('COSH_SHELL_INTEGRATION' in values)
        self.assertEqual(values['HOME'],'/tmp/owned')
