# Inline paired native evidence join — current design

This section supersedes only the paired native-proof preparation domain. The ca52/b2dc3ac archives remain immutable. The worker design below is retained history. This domain is test-only; product execution/resources remain zero until new Root source/RPM/profile/run/native-Bash bindings arrive.

## Review circuit breaker

Independent review exposed two projections of a missing provenance design: recording the static /bin/bash digest without proving the running Bash identity, then comparing arbitrary casts without proving they belong to the fixture results. Stop counterexample patches and implement the following conjunction before another freeze. No new product mechanism, generic proof framework, SLO, threshold or blocked C2/D path is introduced.

## Minimal invariants

| Invariant | Required witness and rejection rule |
| --- | --- |
| P1 Actual identity | New frozen candidate/RPM/architecture and Root environment run ID match across the pair. Observed kernel boot-id digest and mount namespace must agree, so equal binary labels on different machines/containers cannot form a same-environment control; Root-frozen system Bash SHA/NEVRA/path. Each observed managed Bash resolves to that actual executable, with /proc PID/start pinned before and after reading its executable digest. Initial/final actual Bash identity and cwd stay equal. A static file digest or basename alone is insufficient. |
| P2 Unique execution | Each fixture creates a fresh 128-bit test nonce. Result, begin OSC metadata and final result receipt agree on nonce, scenario, installed/native variant and controlled-input protocol digest. The two nonces must differ. Missing, foreign, duplicate or wrong-scenario/variant metadata fails. This is correlation, not a credential. |
| P3 Actual controlled input | Only these native canonical cases opt into driver-write recording. A separate instance of the existing UTF8/stream redaction filters records i frames without affecting output matching or screenshots. The full ordered driver writes must equal the bounded per-scenario native-input protocol, and match across the pair; empty input, arbitrary a, wrong bytes/order, missing ShiftTab or extra Enter fails. This proves driver writes, not OS read chunk boundaries. |
| P4 Result belongs to cast | The final fixture marker is emitted after validation and cleanup and carries SHA256 of the exact result.json bytes. The verifier takes those exact file bytes and the corresponding cast, requires its unique begin nonce/metadata and final result digest, and then compares controlled inputs. Old/same cast twice, result replacement, wrong execution or a successful result beside unrelated input cannot join. Verified CLI artifact/checksum provenance remains a required outer boundary. |
| P5 Non-vacuous behavior | Each per-case result independently requires actual foreground consumer at the relevant read/secondary-prompt/draft point, exact hard-coded consumer output bytes, zero provider requests, unchanged raw PS1 and same Bash, physical current editable native prompt before one fresh effect, restored terminal and no owned residue. Caller-supplied expected bytes cannot redefine the oracle. Shell-only additionally requires actual off state, native command-not-found observation, exactly one native history entry and off state after a fresh command. |
| P6 Bounded claim | All invariants are ANDed. Native pair PASS covers only its scenario on the new bound candidate. Sampled /proc cannot exclude an unobserved short-lived worker; source activation review/trace remain separate. No whole U02/original34/default-enable, timing, arbitrary fault takeback or old-session survival verdict follows. |

## Input and evidence matrix

| Domain | Positive/control dimensions | Negative invariant family |
| --- | --- | --- |
| Identity | Installed managed Bash and independent same-machine Bash, exact candidate/RPM/arch and actual binary | Wrong binary/path/SHA or reused PID/start; empty process observation; same labels on different identities |
| Execution lineage | Unique nonce for each variant, same scenario/protocol, one begin and one final receipt | Same old cast twice; foreign run/scenario/variant/protocol; missing/duplicate receipt; changed result bytes |
| Driver writes | read/read-e; native PS2; quoted heredoc; draft+ShiftTab+Enter; foreground read with raw ShiftTab; healthy idle off | Empty/arbitrary inputs; changed/order-swapped packet; dropped key; extra Enter; a cast from another scenario |
| Consumer/effect | Foreground fd/TTY/pgrp or actual secondary/draft cursor; exact output; one fresh command | Empty observation/output, wrong reader, both caller expected/actual empty, repeated effect, fake prompt or changed PS1 |
| Routing | Empty healthy prompt toggles off and stays off; draft/card/foreground do not toggle | Wrong state before/after, absent native history or duplicate dispatch/effect; card focus alone does not authorize |
| Cleanup and aggregation | Normal exit, restored termios, no owned PID, separate source/installed/real-provider classes | Lost cleanup, mocked/loopback promoted to real provider, incomplete case promoted to whole gate |

Implementation is limited to existing inline fixtures/contracts, the private runner's opt-in controlled input i frames, two small evidence join tools and canonical cases. Synthetic tests and compiling mutants target these invariants; they do not stand in for installed/native execution. New freeze requires an independent review of the full conjunction and its controls.

---

# Retained historical worker design

# Production installed worker acceptance preparation

Root approved Option A on 2026-10-16. This exclusive tool repository owns test-only tooling. No product source, shared skill, lock, dependency or environment file is changed. No new product acceptance has run.

The initial commit snapshots the actual embedded runtime 0.8.0. Its dirty shared source derives from eaa3b9fd45d2582d77071bf1051948e83572181d, whose committed runtime was 0.7.0. provenance/ORIGIN.json and ORIGIN-TO-ACTUAL.patch record those differences. The private baseline commit is 8a67f9435734b72c1e387a9f4145c82e3d0d227d. Resize renderer adoption has separate source hashes and diff. Historical debug fixture and canonical bytes are retained unchanged and are not used as new production evidence.

Seven production-installed loopback cases use real installed Shell/Core/worker and a local SSE server. They check approval, rejection, one effect, physical PID/start isolation, resize, pinned SIGKILL/SIGSTOP, focus fallback and small-terminal inline fallback. They are mechanism evidence, not a real-provider result. No COSH_UI_* environment override, worker path override or debug width is injected. The case deadlines are execution guards, not new product SLOs. The finite failure policy must be read from the final product HEAD; no test-only override is allowed.

One real-provider case uses env -i and installed Shell raw cosh-core. Root must stage the approved role/auth configuration into the explicitly selected provider home, then verify installed Core auth with this private CLI. The sidecar observes installed Host/Core/worker independently in the dedicated workspace. A fresh nonce-bound effect and strict Agent response/follow-up are joined to the same candidate and RPM; CLI success alone does not establish worker execution. Neither loopback nor fabricated protocol negatives can substitute for this evidence.

Identity requires a clean exact source commit/tree, native release attestation, RPM archive SHA/NEVRA, and all six installed payload hashes: Shell, Core, Gateway, worker, CLI, switch. Installed RPM verification and package ownership are checked before the helper runs product commands. Root's build collector additionally verifies native ELF architecture, worker root ownership and 0755. Frozen helper hashes are embedded in the private runtime. Candidate/binding files must be hashed before invoking guest helpers.

Raw token presence is only a transcript oracle. It cannot prove preservation of the visible viewport or scrollback. Resize-aware replay preserves cast resize event order, actual geometry, frame cutoff, screen and logical history provenance. Required layout points need PNG/WebM/cast inspection and an actual terminal consumer review before visual acceptance.

Original U02 remains open: U02a descendants retaining IPC and old-generation late events need genuine revocation evidence; the physical worker PID/start observation does not prove internal generation revocation. U02b bounded persistent failures and Running/Unknown non-replay need a real observable scenario. U02c needs the actual public explicit-takeback operation, live foreground/read and Core-loss conditions, exclusion of retained input, and disabled automatic re-entry. A single pending-card focus fault does not close those contracts. Protocol-negative Rust tests remain separately labelled source evidence.

No new source/RPM binding, run IDs or profile freeze exists in this preparation. Old v7 is superseded. Do not execute these cases on v7 or inherit old passes. Root deferred new 8h signing, short ECS, rescue snapshots/keypair, disk/zone readbacks until the new freeze; Root owns all purchases and TTL decisions. The old debug build environment request is superseded.

After Root review: freeze this clean tool HEAD/tree and every case/profile/helper SHA; bind the new source/RPM identities; stage helpers/candidate/binding using cosh-lab upload and verify guest hashes; run installed identity and Core auth first. Execute the eight worker loopback cases on isolated functional machines. For real-provider: create an empty owned workspace, start the sidecar through cosh-lab with its owned PID/start/output and stop marker, run PW-PROD-REAL-APPROVAL-001, stop/join the sidecar, run tools/verify_real_evidence.py, and inspect visual artifacts. Always preserve original failures, cleanup the owned sidecar/fixtures/effects, and record fresh process/resource readbacks. Long measurement resources must remain isolated.

Local verification evidence lives in the parent acceptance directory: CONTRACT-FINAL.stderr (16), RESIZE-FINAL.stderr (5 synthetic replay/cleanup), mutations/RESULTS.json (3 compiling negative controls), strict-agent-controls/RESULTS.json (echo negative and Agent-row positive), CANONICAL-DISCOVERY.json and eight describe results. No historical product-cast test is included in these counts. Product execution and full U02 acceptance remain pending.

Root isolation review correction: 6684b548 accepted a synthetic worker with unexpected cwd and extra FD. The validator now requires cwd=/ and the exact descriptor keys 0,1,2,3. Valid isolated workers remain accepted; wrong cwd, extra regular FD and extra socket FD each have an independent RED/GREEN test. The original accepted negative control and first tool commit remain preserved. Latest evidence is ../isolation-review-fix: 20 contract tests, five compiling mutations, and the complete six resize/cleanup tests (one historical-cast replay, five synthetic controls). Historical replay is tooling verification, not a new product acceptance run.

## v8 recovery correction

This revision derives from the preserved 4b18eb546 tool freeze. New source 2bca152af71f7798b9d7d4d0c511f70081140c14 rebuilds a worker after one kill/hang; the old three canonical cases incorrectly waited for immediate inline fallback. The old freeze and mismatch evidence remain retained. Single-fault KILL/STALL/FOCUS now wait for the selected card to be repainted and require a replacement installed worker PID/start, old process retirement, post-fault complete selected frame, exact effect and real Core HostResult. One fault cannot be replaced with three faults to obtain the old fallback message. Focus remains Deny and its effect count remains zero.

The separate PW-PROD-EXHAUSTED-001 case faults three successive actual workers, verifies two rebuilds, observes worker-free inline fallback before any effect, then checks the product's current approval/result behavior. Renderer-budget exhaustion with a healthy physical terminal intentionally retains one inline approval, requiring fresh explicit approval before its one effect. This is expected fallback behavior, not evidence of a U02b unstarted-revocation defect; see U02B-RENDERER-EXHAUSTION-ERRATUM.md. Physical retirement is checked from /proc/PID/stat, including zombie identity; inability to read stat is not accepted as disappearance. A retired process is not proof of descendant-held IPC revocation or old-generation late-event rejection. Those U02a witnesses remain separate and open. No general terminal takeback interface is added or inferred.

Current tool matrix contains eight loopback cases plus one real-provider case. Local RED/GREEN, valid positive samples and nine compiling contract mutations are in ../v8-recovery-evidence. Twenty-six contract/observation/schema/hash tests and six replay/cleanup tests must pass before this revision is proposed to Root. Product acceptance remains unexecuted until Root binds its exact source, new dualarch release RPMs, profiles and run IDs. The original 4b18 working tree is untouched.

## Control mode correction

The first real ARM installed ALLOW attempt at run20261016T135020Z-33766257 exposed a tool configuration error: ask is unsupported and falls back to recommend. The product parser at the exact v8 source only supports recommend (plus legacy aliases), auto and trust. Both Shell/Core launch variables and canonical metadata now use auto, matching the real Core source harness. Trust is forbidden. Actual high-risk approval must still be shown and explicitly allowed/denied; effect, HostResult, worker and process-retirement predicates are unchanged. Every case rejects invalid-mode warnings. The failed run, timeout137 and original62 freeze are preserved. The original readback actually reported owned_home_absent=false; that exact directory was later preserved by rename. Current effect.txt was absent, so historical effect remains unknown; no zero-effect verdict is inferred. Subsequent success must be fresh actual execution after Root reviews the new clean tool, case overlay and derived binding chain.

## Complete physical frame trigger correction

The original KILL attempt at20261016T141155Z-8b5baf77 never established a valid fault trigger: its actual2669-byte physical frame contained a complete38-dash bottom border, but the encoded bytes regex applied its quantifier to only the final UTF8 byte. The preserved original attempt remains failed, not an injected product-rebuild failure. The parser now decodes complete UTF8, reads the latest panel and current selected action, and requires the closed bottom border after that selection. Partial UTF8, incomplete/newer frames, wrong focus and stale frames are rejected. Redacted actual Allow and Deny byte fixtures keep geometry unchanged. One-fault counts, replacement PID/start, old process retirement, Core HostResult, exact effects and terminal/cleanup checks remain unchanged. Pure trigger/regex/startup/focus preconditions were audited before another product run.

The failed KILL fixture left a script/Host/Bash/Core/worker tree. Only freshly verified PID/start, installed ELF and parent/cwd-scoped identities were signaled through pidfds; independent readback showed no remaining Cosh processes including zombies. Failure files and the exact owned home were preserved and downloaded. Current missing effect.txt is not a historical zero-effect proof. Existing180-second guards and original137 outputs remain unchanged. No old PASS is inherited into this new tool version.


## Current U02 installed preparation

Root authorized this test-only extension of the already approved public Ctrl+] contract. Four new canonical cases use only installed Shell/Core/worker and the public 0x1d keyboard input: pending cancellation, original Core loss, managed Bash read, and ordinary foreground byte passthrough. The prior nine canonical cases remain byte-identical. There are now twelve loopback scenarios and one real-provider scenario; none was executed on a new package by this preparation.

`fixtures/production_takeback.py` verifies Root's candidate/RPM/six payloads and explicit hashes for its own module, takeback contract, inherited worker helper and existing tmux replay before product launch. The owned HOME sets the original green native PS1, uses native Bash startup (no isolated/enhanced override), mode auto and a loopback provider. It adds no product flag or interface. Missing tmux or binding is a precondition failure; it does not install dependencies.

The observer reconstructs only product physical bytes through the existing private tmux replay. It checks the current cursor line, original green first cell, original caret column/visibility and unchanged Bash PID/start/cwd/TTY before notifying the driver to send its first fresh native command. Observer-ready metadata uses an ignored OSC9999 on the outer recording, with no text/caret motion; it is not a product protocol or input. A real tmux synthetic control proves the stage signal leaves the whole snapshot unchanged. Canonical screenshots/WebM still require the existing evidence verifier and visual review after future execution.

The managed-read case first explicitly approves one real Core shell request, then takes back to the same foreground consumer without synthesizing PS1. Only its first post-ACK new answer may finish that original operation once; the original native PS1 must return before the first new ordinary Bash command. Idle pending cases require no pending operation effect and the exact same Core denial continuation; Core-loss requires a successful verified pidfd signal, old-process absence and no replacement. Ordinary foreground is not treated as takeback and must receive literal 0x1d.

A single driver write containing an old prefix/Ctrl+]/suffix, or a read-answer canary, demonstrates only that observed packet/window. It cannot prove every queued read-ahead, deadline buffer, blocked generic reader or final short-write race. Those are explicit source-harness/compiled-control requirements in U02-ACCEPTANCE-MAP.md, not silently closed by this fixture. The ordinary case has no concurrent background Agent; that mixed-owner condition also remains a separate witness. U02a descendant IPC and U02b physical TTY/RunningUnknown remain source-scoped until exact final-source evidence and an agreed installed supplement exist.

All prior freeze trees and first failures remain immutable. This version must first become a clean commit/tree/archive/manifest and receive Root review, then bind future clean product source/native dual-architecture RPMs/case overlays/profiles. Existing v8 passes are not inherited. No product execution, provider call, purchase or 8h run is authorized by tool tests.


## External-session foreground observation correction (2026-10-17)

PR8042 ARM media first run 20261017T131638Z-be79d560 failed before
startup-ready because Linux rejects tcgetpgrp on another session's terminal
with ENOTTY. The observer must not acquire that terminal or change its session.
It reads the target process's kernel tty_nr and tpgid, checks the open fd0 is
the same character device as its controlling terminal, and brackets the read
with stable process start, session, group and tty identity. The existing
contract still compares actual terminal foreground group against the Bash
process group. No timeout, prompt, approval, effect or cleanup rule changes.

Actual Linux PTY regression compares the external observation to an in-session
tcgetpgrp positive control. Background, stale-start and nonterminal controls
remain rejected. A compiled mutation substituting pgrp for tpgid must fail the
background assertion. Original first failure, termios_restored=false and all
e5f34a7 artifacts remain immutable. This tool correction is not product or
release acceptance. A new tool binding is required before any canonical rerun.


## Unified bounded consumer lifecycle

Approved design: CONSUMER-LIFECYCLE-DESIGN.md, SHA256
20f0947b0f26fe822da7fb8d78ca881296dfeb95184798b7f4d48a28e0f0ca69.
The strict observer distinguishes live valid samples, kernel-proven termination
and invalid evidence. Terminal/identity/read errors remain fail closed.
Both fixture callers record only the verified current sample; all new stage
markers require a current foreground consumer. Native executable binding and
cwd are sampled within the same anchored observation. No case or aggregate
contract/timeout change. The independent review's path-stability P2 was
reproduced by an assertion RED and fixed with final fd0 readlink comparison.
Actual Linux PTY evidence is separate from controlled proc/OS phase injection
and compiled fixture-fragment composition controls. Original e5/411 product
failures and initial mutant-controller error-only rejection remain preserved.
