from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'fixtures'))
from inline_native_fixture import SECONDARY, DRAFT, at_secondary, draft_observed
from inline_support import assistance_enabled


class NativeObservationTests(unittest.TestCase):
    def who(self):return {'pid':7,'start':2,'foreground_pgrp':7,'pgrp':7,'tty':'/dev/pts/4'}

    def test_secondary_prompt_requires_actual_cursor_and_foreground_consumer(self):
        snap={'plain':SECONDARY,'x':len(SECONDARY),'y':0,'cursor_visible':True}
        self.assertTrue(at_secondary(snap,self.who()))
        for key,value in [('x',0),('y',1),('cursor_visible',False),('plain','old '+SECONDARY)]:
            wrong=dict(snap);wrong[key]=value;self.assertFalse(at_secondary(wrong,self.who()))
        wrong=self.who();wrong['foreground_pgrp']=8
        self.assertFalse(at_secondary(snap,wrong))
        wrong=self.who();wrong['tty']='/dev/null'
        self.assertFalse(at_secondary(snap,wrong))

    def test_draft_must_be_the_current_editable_line_not_old_history(self):
        line='original@bash:~$ '+DRAFT
        snap={'plain':line,'x':len(line),'y':0,'cursor_visible':True}
        self.assertTrue(draft_observed(snap,self.who()))
        for key,value in [('x',18),('cursor_visible',False),('plain','old '+line)]:
            wrong=dict(snap);wrong[key]=value;self.assertFalse(draft_observed(wrong,self.who()))

    def test_assistance_observer_reads_actual_runtime_file_without_changing_it(self):
        with tempfile.TemporaryDirectory() as temporary:
            home=Path(temporary)
            self.assertIsNone(assistance_enabled(home))
            state=home/'enabled';state.write_text('enabled\n')
            (home/'assistance-path').write_text(str(state))
            self.assertIs(assistance_enabled(home),True)
            self.assertEqual(state.read_text(),'enabled\n')
            state.unlink();self.assertIs(assistance_enabled(home),False)
