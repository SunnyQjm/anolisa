import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import time

from installed_identity import digest, identity
from production_contract import PREFIX, WORKER
from production_worker import descendants, process_info, worker_record


def observe(args):
    bound=identity(args.candidate,args.binding)
    if digest(__file__)!=bound['tool_binding']['observer_sha256']:
        raise ValueError('observer differs from frozen binding')
    target=Path(args.workspace).resolve()
    output=Path(args.out)
    if output.exists():
        raise ValueError('preserve the prior observer result')
    started=datetime.now(timezone.utc).isoformat()
    workers={};hosts={};cores={};deadline=time.monotonic()+args.timeout_seconds
    while not Path(args.stop_marker).exists():
        if time.monotonic()>=deadline:
            raise RuntimeError('observer deadline; no production acceptance verdict')
        for path in Path('/proc').iterdir():
            if not path.name.isdigit():continue
            host=process_info(int(path.name))
            if not host or host['exe']!=PREFIX+'cosh-shell' or Path(host['cwd']).resolve()!=target:continue
            if digest(path/'exe')!=bound['payload_sha256'][PREFIX+'cosh-shell']:
                raise ValueError('observed Host differs from installed identity')
            hosts[(host['pid'],host['start'])]={**host,'sha256':bound['payload_sha256'][PREFIX+'cosh-shell']}
            for row in descendants(host['pid']):
                if row['exe']==WORKER:
                    key=(row['pid'],row['start'])
                    if key not in workers:workers[key]=worker_record(row,host['pid'],bound['payload_sha256'][WORKER])
                if row['exe']==PREFIX+'cosh-core':
                    if digest(Path('/proc')/str(row['pid'])/'exe')!=bound['payload_sha256'][PREFIX+'cosh-core']:
                        raise ValueError('observed Core differs from installed identity')
                    cores[(row['pid'],row['start'])]={**row,'sha256':bound['payload_sha256'][PREFIX+'cosh-core']}
        time.sleep(0.01)
    effects={str(p):p.read_text().splitlines() for p in target.glob('effect-*.txt')}
    result={'evidence_class':'installed-release-real-provider-observer','source':bound['source'],'rpm_sha256':bound['rpm_sha256'],'candidate_sha256':bound['candidate_sha256'],'workspace':str(target),'started_at':started,'finished_at':datetime.now(timezone.utc).isoformat(),'hosts':list(hosts.values()),'cores':list(cores.values()),'workers':list(workers.values()),'effects':effects,'new_product_authority':False,'verdict':'observation only; join strict CLI provider evidence and exact effect oracle separately'}
    output.write_text(json.dumps(result,indent=2)+'\n')
    if not hosts or not cores or not workers:
        raise RuntimeError('required real installed process observation missing')


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--candidate',required=True)
    parser.add_argument('--binding',required=True)
    parser.add_argument('--workspace',required=True)
    parser.add_argument('--out',required=True)
    parser.add_argument('--stop-marker',required=True)
    parser.add_argument('--timeout-seconds',type=int,default=180)
    observe(parser.parse_args())
