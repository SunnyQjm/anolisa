import re
import hashlib
import json

try:
    from .inline_contract import require
except ImportError:
    from inline_contract import require

EXPECTED={'native-read':b'?? native read\n','native-read-e':b'?? native read-e\n','native-ps2':b'\n?? native ps2\n','native-heredoc':b'?? native heredoc\n','route-draft':b'INL_DRAFT\n','route-foreground':b'\x1b[Z?? native foreground\n','route-idle':b''}
SCENARIOS=set(EXPECTED)



BEFORE="printf '%s' \"$PS1\" > ps1-before; printf '%s' \"${COSH_ASSISTANCE_STATE_FILE-}\" > assistance-path"
FRESH="printf '%s' \"$PS1\" > ps1-after; history > routing-history; printf '%s\\n' INL_FRESH >> fresh"
READ="printf ready > consumer-ready; IFS= read -r answer; printf '%s\\n' \"$answer\" > consumer-result"
MIDDLE={
    'native-read':[READ+'\r','?? native read\r'],
    'native-read-e':[READ.replace('read -r','read -e -r')+'\r','?? native read-e\r'],
    'native-ps2':["printf '%s\\n' > consumer-result '\r","?? native ps2'\r"],
    'native-heredoc':["cat > consumer-result <<'INL_EOF'\r",'?? native heredoc\r','INL_EOF\r'],
    'route-draft':["printf '%s\\n' INL_DRAFT >> consumer-result",'\x1b[Z\r'],
    'route-foreground':[READ+'\r','\x1b[Z?? native foreground\r'],
    'route-idle':['\x1b[Z','?? INL_ROUTING_OFF_SENTINEL\r'],
}


def controlled_inputs(scenario):
    require(scenario in MIDDLE,'unknown controlled input protocol')
    return [BEFORE+'\r',*MIDDLE[scenario],FRESH+'\r','exit 0\r']


def input_protocol_sha256():
    value={'version':'inline-native-v1','geometry':[80,30],'inputs':{name:controlled_inputs(name) for name in sorted(MIDDLE)}}
    return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()


def verify_native(result):
    scenario=result.get('scenario')
    require(scenario in SCENARIOS,'unknown native consumer scenario')
    require(type(result.get('native_baseline')) is bool,'baseline identity required')
    require(re.fullmatch('[0-9a-f]{32}',result.get('fixture_run_token','')) is not None,'unique fixture execution nonce required')
    require(result.get('input_protocol_sha256')==input_protocol_sha256(),'controlled input protocol differs')
    baseline=result['native_baseline']
    require(result.get('evidence_class')==('native-bash-control' if baseline else 'installed-inline-native') and result.get('identity_verified') is True,'native/installed evidence class mismatch')
    for key in ['candidate_sha256','rpm_sha256','native_bash_sha256','host_boot_sha256']:
        require(re.fullmatch('[0-9a-f]{64}',result.get(key,'')) is not None,'native pair digest required: '+key)
    require(isinstance(result.get('environment_run_id'),str) and bool(result['environment_run_id']),'Root environment run identity required')
    require(re.fullmatch(r'mnt:\[\d+\]',result.get('mount_namespace','')) is not None,'actual mount namespace required')
    require(result.get('architecture') in {'aarch64','x86_64'},'native architecture required')
    require(result.get('requests')==0,'native consumer unexpectedly entered Agent')
    require(result.get('workers')==[] and result.get('monitor_complete') is True,'native observation incomplete or worker observed')
    require(result.get('consumer_observed') is True,'actual foreground consumer witness required')
    require(result.get('consumer_result_hex')==result.get('consumer_expected_hex')==EXPECTED[scenario].hex(),'native consumer bytes mismatch')
    require(result.get('physical_prompt_before_fresh') is True and result.get('fresh_effect')==['INL_FRESH'],'current native prompt and one fresh command required')
    expected=result.get('ps1_expected_hex')
    require(isinstance(expected,str) and bool(expected) and result.get('ps1_before_hex')==result.get('ps1_after_hex')==expected,'raw PS1 changed')
    require(result.get('bash_before') is not None and result.get('bash_before')==result.get('bash_after'),'native Bash identity changed')
    actual=result['bash_before']
    require(all(type(actual.get(k)) is int and actual[k]>0 for k in ['pid','start']),'nonempty actual Bash PID/start required')
    require(isinstance(result.get('native_bash_path'),str) and result['native_bash_path'].startswith('/') and actual.get('exe')==result['native_bash_path'],'actual Bash path differs from bound native path')
    require(result['bash_before'].get('sha256')==result['native_bash_sha256'],'observed Bash differs from bound native binary')
    require(result.get('shell_exit')==0 and result.get('remaining_pids')==[] and result.get('termios_restored') is True,'native cleanup/terminal failed')
    if not baseline:
        require(result.get('routing_before') is True,'initial assisted state required')
        require(result.get('routing_after') is (False if scenario=='route-idle' else True),'routing boundary changed unexpectedly')
    if scenario=='route-idle':
        require(not baseline and result.get('routing_off_observed') is True and result.get('routing_history_count')==1,'shell-only native probe or sticky off missing')


def verify_pair(candidate, baseline, candidate_events, baseline_events, candidate_result_bytes, baseline_result_bytes):
    verify_native(candidate);verify_native(baseline)
    require(candidate['native_baseline'] is False and baseline['native_baseline'] is True,'installed and native Bash pair required')
    for key in ['candidate_sha256','rpm_sha256','architecture','scenario','native_bash_sha256','native_bash_path','input_protocol_sha256','environment_run_id','host_boot_sha256','mount_namespace']:
        require(candidate.get(key)==baseline.get(key),'native pair binding differs: '+key)
    require(candidate['fixture_run_token']!=baseline['fixture_run_token'],'paired executions must have distinct nonces')
    def bound_packets(result, events, raw_result):
        require(json.loads(raw_result)==result,'result file bytes do not describe this result')
        output='';spans=[]
        for index,row in enumerate(events):
            if len(row)==3 and row[1]=='o':
                start=len(output);output+=row[2];spans.append((start,len(output),index))
        pattern=r'\x1b\]9999;COSH_LAB_STAGE=INL_NATIVE_RUN=([0-9a-f]{32});scenario=([a-z-]+);baseline=([01]);protocol=([0-9a-f]{64})\x07'
        begin_matches=list(re.finditer(pattern,output));begins=[match.groups() for match in begin_matches]
        expected=(result['fixture_run_token'],result['scenario'],str(int(result['native_baseline'])),result['input_protocol_sha256'])
        require(len(begins)==1 and begins[0]==expected and output.count('COSH_LAB_STAGE=INL_NATIVE_RUN=')==1,'cast begin metadata does not belong to result')
        end_matches=list(re.finditer(r'INL_NATIVE_RESULT (\{[^\r\n]*\})',output));markers=[match[1] for match in end_matches]
        require(len(markers)==1,'one final fixture result receipt required')
        receipt=json.loads(markers[0])
        require(receipt.get('fixture_run_token')==result['fixture_run_token'] and receipt.get('scenario')==result['scenario'] and receipt.get('native_baseline') is result['native_baseline'] and receipt.get('input_protocol_sha256')==result['input_protocol_sha256'] and receipt.get('status')=='PASS','cast final execution metadata differs')
        require(receipt.get('result_sha256')==hashlib.sha256(raw_result).hexdigest(),'cast does not bind these result bytes')
        begin_index=next(index for start,end,index in spans if start<=begin_matches[0].end()-1<end)
        end_index=next(index for start,end,index in spans if start<=end_matches[0].start()<end)
        require(all(begin_index<index<end_index for index,row in enumerate(events) if len(row)==3 and row[1] in {'i','r'}),'driver writes must lie between this execution begin and final receipt')
        packets=[(row[1],row[2]) for row in events if len(row)==3 and row[1] in {'i','r'}]
        require(packets==[('i',text) for text in controlled_inputs(result['scenario'])],'actual driver writes differ from controlled native protocol')
        return packets
    a=bound_packets(candidate,candidate_events,candidate_result_bytes)
    b=bound_packets(baseline,baseline_events,baseline_result_bytes)
    require(a==b,'actual driver writes differ across native pair')
