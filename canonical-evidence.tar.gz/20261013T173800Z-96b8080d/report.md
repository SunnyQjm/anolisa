# cosh-lab test

- Run: `20261013T173800Z-96b8080d`
- Status: `PASS`
- Cleanup: `not-applicable`
- Scope: `raw-cli`
- Environment: `20261013T173325Z-4fd39a56`
