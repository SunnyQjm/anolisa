# Inline first-release test preparation for #8028

This test-only tree continues the immutable b2dc3ac checkpoint (base ca52f256b4d242fe10148fa10d44d912c1437c5e). No new product candidate, RPM, resource, run, native Bash or real-provider configuration is bound. No product case has run. Committee/default-enable approval remains pending.

The current catalog has 19 prepared cases: five deterministic real-Core loopback approval/card cases; seven installed native-consumer/routing cases; six paired system-Bash controls; one strict real-provider case. Python/Ruby controls prove test-tool behavior, not these installed cases or whole gates.

- Loopback checks Allow/Deny/Cancel/actual Details expansion, raw original colored PS1, current prompt/caret and foreground Bash, one fresh command and a second Agent request. Card ShiftTab must move Deny focus back to Allow while assistance remains enabled, then the explicit Deny must produce no effect. Known Host completion evidence is accepted only with exact approved command/cwd, completed/exit0 and actual bounded output; unknown result formats fail closed.
- Native cases cover read/read-e/PS2/quoted heredoc, healthy idle ShiftTab to sticky shell-only, a native Readline draft, and raw ShiftTab inside foreground read. They require exact consumer bytes, zero provider POST attempts, unchanged PS1, the same actual Bash and one fresh command. The draft case does not claim generic AI composer/question coverage.
- Each paired Bash case requires the same frozen candidate/RPM/architecture, Root environment run ID, observed boot digest/mount namespace and actual Bash path/SHA/NEVRA. A unique fixture nonce, controlled-input protocol digest and exact result-file SHA bind each cast to its own execution. The cast's full ordered driver writes must match that scenario's fixed protocol and be between its begin metadata and final result receipt. See DESIGN.md P1–P6 and its input/evidence matrix, including the review circuit breaker.
- Only the native ci cases opt into controlled_input_recording. The private runner uses independent instances of its existing streaming UTF8/redaction filters for i frames, including secrets split across driver writes. Output matching and screenshot replay remain output-only. Driver writes do not prove OS read chunk boundaries.
- Real provider reuses the existing nonce and actual Agent-row guards, including the strict-v3 followup fix. Its separate inline observer verifies installed Host/Core identities, nonce-bound effect once, raw PS1 samples and a fresh ordinary effect. The CLI report, canonical digest and observer must join. It does not replace the native physical-prompt cases or prove arbitrary failure recovery. Source provenance is in provenance/STRICT-V3-REUSE.json; no old auth/config/signatures were read or reused.

Root must supply the future metadata in INLINE-BINDING-REQUIREMENTS.json. For the real case, Root creates a fresh private workspace/HOME with the exact plain .bashrc template and uses the existing approved cosh-lab private-auth flow, starts the bound observer before the case, and checks fresh CLI authentication. The case writes observer-stop after the actual Agent followup and fresh ordinary command. No real auth preparation happens in this tool stage. Observer/case budgets must be explicitly matched to Root's profile; observation timeouts are not SLO verdicts.

After future cosh-lab accept/evidence verification, join the actual artifacts:

```sh
python3.12 -B tools/verify_inline_real.py --provider CLI_RESULT --observer OBSERVER_RESULT
python3.12 -B tools/verify_inline_native_pair.py --candidate-result INSTALLED_RESULT --bash-result BASH_RESULT --candidate-cast INSTALLED_CAST --bash-cast BASH_CAST
```

The join outputs index the exact input artifact hashes. CLI screenshots/layout WebM and final source/installed evidence remain separate mandatory review. Sampled /proc cannot exclude a worker that lived entirely between polls; source activation audit and tracing remain required for a complete no-worker claim.

INLINE-ACCEPTANCE-MAP.json preserves all 34 original requirements and exact approved deferrals; whole gates remain Blocked until new bindings and execution. Remaining mechanisms and concrete reusable source paths are listed there: detectable presentation failure, actual fragmented/multiline producer and resize/chunk matrix, complete authorization/identity matrix, final installed two-identity/data/write-failure cases, and fault-domain-external recovery. DATA-FINAL-CASE-GAPS.json retains the sanitized Root authority receipt. Original U02a/b/c and complete S01 are not PASS by withdrawal/deferral.

Original debug files remain under historical/. Old 13 worker/takeback cases and CASE-MATRIX are byte-preserved under historical/worker-and-takeback-ca52/. Legacy worker/takeback fixtures and U02 documents are history, absent from the current catalog. The original ca52 tree and b2dc3ac archive remain unchanged.

Local tool checks:

```sh
python3.12 -B -m unittest discover -s tests
python3.12 -B tools/check_inline_controls.py
python3.12 -B tools/check_inline_strict_agent.py --out NEW_CONTROL_DIRECTORY
python3.12 -B tools/check_inline_input_recording.py --out NEW_CONTROL_DIRECTORY
PYTHONPATH=runtime/src python3.12 -B -m cosh_lab accept list --output json
```

Product execution must use the newly frozen private cosh-lab runtime and Root's new source/RPM/profile/run bindings. Do not reuse v7/v8 resources, auth, signatures, snapshots/keypairs or mutable debug environments. Do not restart platform-blocked C2/D experiments.
