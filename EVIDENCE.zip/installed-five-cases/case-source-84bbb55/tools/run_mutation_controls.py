from pathlib import Path
import json
import os
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'mutations'
out.mkdir(exist_ok=True)
original=(root/'fixtures/production_contract.py').read_text()
mutations={
 'unsupported-ask-mode':("'COSH_APPROVAL_MODE':'auto'","'COSH_APPROVAL_MODE':'ask'"),
 'trust-mode-bypasses-pending-approval':("'COSH_SHELL_APPROVAL_MODE':'auto'","'COSH_SHELL_APPROVAL_MODE':'trust'"),
 'ignore-replacement-worker':("require(recovery['pid']!=fault['pid'] and (recovery['pid'],recovery['start']) in identities,'new installed worker identity missing')","pass"),
 'ignore-old-process-retirement':("require(recovery['old_process_absent'] is True,'old worker process not retired')","pass"),
 'reuse-old-frame':("require(recovery['physical_frame_end']>fault['physical_offset'],'old card reused as recovery evidence')","pass"),
 'ignore-rebuilt-focus':("require(recovery['selected']==('Deny' if scenario=='focus' else 'Allow once'),'rebuilt approval focus changed')","pass"),
 'ignore-worker-cwd':("require(record.get('cwd')=='/','worker working directory must be root')","pass"),
 'ignore-extra-descriptors':("require(set(fds)=={'0','1','2','3'},'worker must own exactly stdio and IPC descriptors')","pass"),
 'inherit-environment':("environment={k:base[k] for k in ['PATH','TERM','LANG','LC_ALL'] if k in base}","environment=dict(base)"),
 'ignore-duplicate-effect':("require(result['effect_lines']==([] if scenario in ['deny','focus'] else ['PW_EFFECT']),'wrong or duplicate effect')","pass"),
 'ignore-worker-parent':("require(record['ppid']==host_pid,'worker must be a child of the observed Host')","pass"),
}
results=[]
for name,(before,after) in mutations.items():
    assert original.count(before)==1
    mutated=original.replace(before,after)
    compile(mutated,name,'exec')
    target=out/name
    (target/'fixtures').mkdir(parents=True,exist_ok=True)
    (target/'tests').mkdir(exist_ok=True)
    (target/'fixtures/production_contract.py').write_text(mutated)
    shutil.copyfile(root/'tests/test_production_contract.py',target/'tests/test_production_contract.py')
    result=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(target/'tests')],cwd=target,env={**os.environ,'PYTHONPATH':str(target)},capture_output=True,text=True)
    (target/'stdout.txt').write_text(result.stdout)
    (target/'stderr.txt').write_text(result.stderr)
    assert result.returncode and 'FAIL:' in result.stderr and 'SyntaxError' not in result.stderr and 'ImportError' not in result.stderr,result.stderr
    results.append({'mutation':name,'compiles':True,'test_exit':result.returncode,'failures':[line for line in result.stderr.splitlines() if line.startswith('FAIL:')]})
(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
