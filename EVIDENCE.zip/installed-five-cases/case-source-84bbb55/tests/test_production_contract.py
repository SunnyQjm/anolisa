import copy
import unittest

from fixtures.production_contract import production_environment, validate_manifest, validate_worker, verify_outcome


class ProductionContractTests(unittest.TestCase):
    def manifest(self):
        names=['cosh-shell','cosh-core','cosh-gateway','cosh-ui-worker']
        payload={ '/usr/libexec/anolisa/cosh-ng/'+n:'a'*64 for n in names}
        payload.update({'/usr/bin/cosh-cli':'b'*64,'/usr/bin/cosh-switch':'c'*64})
        return {'candidate_kind':'frozen','source':{'commit':'a'*40,'tree':'b'*40,'dirty':False},'architectures':{'aarch64':{'rpm_sha256':'d'*64,'nevra':'cosh-ng-1-1.aarch64','payload_sha256':payload}}}

    def worker(self):
        return {'pid':31,'start':77,'ppid':11,'sid':31,'pgrp':31,'cwd':'/','exe':'/usr/libexec/anolisa/cosh-ng/cosh-ui-worker','sha256':'a'*64,'fd':{'0':'/dev/null','1':'/dev/null','2':'/dev/null','3':'socket:[7]'},'environment_keys':[]}

    def outcome(self):
        return {'evidence_class':'installed-release-loopback','identity_verified':True,'scenario':'allow','workers':[self.worker()],'effect_lines':['PW_EFFECT'],'host_tool_result':True,'requests':2,'remaining_pids':[],'termios_restored':True,'bash_before':{'pid':7,'start':2,'cwd':'/tmp/task'},'bash_after':{'pid':7,'start':2,'cwd':'/tmp/task'},'shell_exit':0,'faults':[],'resize_observed':False,'history_tokens_observed':True}

    def test_environment_drops_all_debug_path_and_provider_inputs(self):
        env=production_environment({'COSH_UI_APPROVAL_SLICE_TEST':'1','COSH_UI_TEST_FAILURE_LIMIT':'99','COSH_UI_WORKER_PATH':'/tmp/fake','OPENAI_API_KEY':'foreign','HOME':'/foreign','COSH_SHELL_WIDTH':'40'},'/tmp/owned')
        self.assertFalse(any(k.startswith('COSH_UI_') for k in env))
        self.assertNotIn('OPENAI_API_KEY',env)
        self.assertNotIn('COSH_SHELL_WIDTH',env)
        self.assertEqual(env['HOME'],'/tmp/owned')
        self.assertEqual(env['COSH_APPROVAL_MODE'],'auto')
        self.assertEqual(env['COSH_SHELL_APPROVAL_MODE'],'auto')

    def test_manifest_requires_installed_worker_and_frozen_source(self):
        good=self.manifest();self.assertEqual(validate_manifest(good,'aarch64')['nevra'],'cosh-ng-1-1.aarch64')
        del good['architectures']['aarch64']['payload_sha256']['/usr/libexec/anolisa/cosh-ng/cosh-ui-worker']
        with self.assertRaises(ValueError):validate_manifest(good,'aarch64')
        dirty=self.manifest();dirty['source']['dirty']=True
        with self.assertRaises(ValueError):validate_manifest(dirty,'aarch64')

    def test_manifest_rejects_missing_exact_source_and_bad_digest(self):
        m=self.manifest();m['source']['commit']='pending'
        with self.assertRaises(ValueError):validate_manifest(m,'aarch64')
        m=self.manifest();m['architectures']['aarch64']['rpm_sha256']=''
        with self.assertRaises(ValueError):validate_manifest(m,'aarch64')

    def test_worker_requires_actual_elf_parent_start_and_isolated_fd(self):
        w=self.worker();validate_worker(w,11,'a'*64)
        for field,value in [('ppid',10),('sha256','b'*64),('start',0),('sid',11)]:
            wrong=copy.deepcopy(w);wrong[field]=value
            with self.assertRaises(ValueError,msg=field):validate_worker(wrong,11,'a'*64)
        wrong=copy.deepcopy(w);wrong['fd']['0']='/dev/pts/8'
        with self.assertRaises(ValueError):validate_worker(wrong,11,'a'*64)
        wrong=copy.deepcopy(w);wrong['environment_keys']=['OPENAI_API_KEY']
        with self.assertRaises(ValueError):validate_worker(wrong,11,'a'*64)

    def test_worker_accepts_root_cwd_and_exact_four_descriptors(self):
        validate_worker(self.worker(),11,'a'*64)

    def test_worker_rejects_wrong_cwd(self):
        wrong=self.worker();wrong['cwd']='/tmp/unexpected-workdir'
        with self.assertRaises(ValueError):validate_worker(wrong,11,'a'*64)

    def test_worker_rejects_extra_regular_descriptor(self):
        wrong=self.worker();wrong['fd']['4']='/tmp/unexpected-inherited-file'
        with self.assertRaises(ValueError):validate_worker(wrong,11,'a'*64)

    def test_worker_rejects_extra_socket_descriptor(self):
        wrong=self.worker();wrong['fd']['4']='socket:[99]'
        with self.assertRaises(ValueError):validate_worker(wrong,11,'a'*64)

    def test_display_or_mock_worker_is_not_an_installed_closed_loop(self):
        verify_outcome(self.outcome())
        for field,value in [('workers',[]),('host_tool_result',False),('effect_lines',[]),('effect_lines',['PW_EFFECT','PW_EFFECT']),('evidence_class','protocol-negative'),('identity_verified',False),('requests',1)]:
            wrong=self.outcome();wrong[field]=value
            with self.assertRaises(ValueError,msg=field):verify_outcome(wrong)

    def test_deny_executes_no_effect(self):
        value=self.outcome();value.update(scenario='deny',effect_lines=[]);verify_outcome(value)
        value['effect_lines']=['PW_EFFECT']
        with self.assertRaises(ValueError):verify_outcome(value)

    def test_fallback_small_does_not_claim_real_worker(self):
        value=self.outcome();value.update(scenario='fallback-small',workers=[]);verify_outcome(value)
        value['workers']=[self.worker()]
        with self.assertRaises(ValueError):verify_outcome(value)

    def recovered_outcome(self, scenario='kill'):
        value=self.outcome();value['scenario']=scenario
        replacement=copy.deepcopy(self.worker());replacement.update(pid=32,start=88,sid=32,pgrp=32)
        value['workers'].append(replacement)
        value['faults']=[{'pid':31,'start':77,'signal':'SIGSTOP' if scenario=='stall' else 'SIGKILL','observed_complete_frame':True,'physical_offset':100}]
        value['recoveries']=[{'fault_pid':31,'fault_start':77,'pid':32,'start':88,'old_process_absent':True,'physical_frame_end':200,'selected':'Deny' if scenario=='focus' else 'Allow once'}]
        if scenario=='focus':value['effect_lines']=[]
        return value

    def test_single_fault_needs_new_physical_worker_and_retired_old_process(self):
        valid=self.recovered_outcome();verify_outcome(valid)
        for field,bad in [('pid',31),('start',99),('old_process_absent',False),('physical_frame_end',100)]:
            wrong=copy.deepcopy(valid);wrong['recoveries'][0][field]=bad
            with self.assertRaises(ValueError,msg=field):verify_outcome(wrong)
        wrong=copy.deepcopy(valid);wrong['recoveries']=[]
        with self.assertRaises(ValueError):verify_outcome(wrong)

    def test_rebuilt_focus_is_deny_and_fault_is_not_repeated_to_force_fallback(self):
        value=self.recovered_outcome('focus');verify_outcome(value)
        value['recoveries'][0]['selected']='Allow once'
        with self.assertRaises(ValueError):verify_outcome(value)
        value=self.recovered_outcome();value['faults']*=3
        with self.assertRaises(ValueError):verify_outcome(value)

    def test_three_failures_are_a_separate_exhaustion_case(self):
        value=self.recovered_outcome('exhausted')
        third=copy.deepcopy(value['workers'][-1]);third.update(pid=33,start=99,sid=33,pgrp=33);value['workers'].append(third)
        value['faults'] += [{'pid':32,'start':88,'signal':'SIGKILL','observed_complete_frame':True,'physical_offset':200},{'pid':33,'start':99,'signal':'SIGKILL','observed_complete_frame':True,'physical_offset':300}]
        value['recoveries'].append({'fault_pid':32,'fault_start':88,'pid':33,'start':99,'old_process_absent':True,'physical_frame_end':300,'selected':'Allow once'})
        value['exhausted_fallback_observed']=True;value['last_fault_process_absent']=True
        verify_outcome(value)
        for field in ['exhausted_fallback_observed','last_fault_process_absent']:
            wrong=copy.deepcopy(value);wrong[field]=False
            with self.assertRaises(ValueError):verify_outcome(wrong)

    def test_fault_requires_pinned_pid_and_actual_signal_record(self):
        value=self.outcome();value['scenario']='kill'
        with self.assertRaises(ValueError):verify_outcome(value)
        value=self.recovered_outcome();verify_outcome(value)
        value['faults'][0]['start']=78
        with self.assertRaises(ValueError):verify_outcome(value)

    def test_resize_requires_geometry_and_history_without_bash_replacement(self):
        value=self.outcome();value['scenario']='resize'
        with self.assertRaises(ValueError):verify_outcome(value)
        value['resize_observed']=True;verify_outcome(value)
        value['history_tokens_observed']=False
        with self.assertRaises(ValueError):verify_outcome(value)
        value=self.outcome();value['bash_after']['pid']=8
        with self.assertRaises(ValueError):verify_outcome(value)

    def test_cleanup_and_terminal_are_required(self):
        for field,value in [('remaining_pids',[31]),('termios_restored',False),('shell_exit',1)]:
            wrong=self.outcome();wrong[field]=value
            with self.assertRaises(ValueError):verify_outcome(wrong)


class ReleaseBindingTests(unittest.TestCase):
    def test_release_provenance_is_required_not_just_an_elf_name(self):
        from fixtures.production_contract import validate_release_binding
        value={'build_profile':'release','build_attestation_sha256':'a'*64}
        validate_release_binding(value)
        for wrong in [{'build_profile':'debug','build_attestation_sha256':'a'*64},{'build_profile':'release'},{'build_profile':True,'build_attestation_sha256':'a'*64}]:
            with self.assertRaises(ValueError):validate_release_binding(wrong)


class RealEvidenceJoinTests(unittest.TestCase):
    def sample(self):
        import hashlib
        nonce='0123456789abcdef0123456789abcdef'
        worker=ProductionContractTests().worker()
        payload={worker['exe']:'a'*64}
        provider={'binary_origin':'installed-rpm','mock_enabled':False,'upstream_response_observed':True,'semantic_checkpoint_observed':True,'prompt_recovered':True,'rpm_sha256':'d'*64,'installed_manifest_sha256':'c'*64,'payload_sha256':payload,'request_nonce_sha256':hashlib.sha256(nonce.encode()).hexdigest()}
        observer={'evidence_class':'installed-release-real-provider-observer','rpm_sha256':'d'*64,'candidate_sha256':'c'*64,'hosts':[{'pid':11}],'cores':[{'pid':12}],'workers':[worker],'effects':{'/owned/effect-'+nonce+'.txt':['PW_EFFECT']}}
        return provider,observer

    def test_real_provider_and_worker_and_effect_are_all_required(self):
        from fixtures.production_contract import verify_real_join
        provider,observer=self.sample();verify_real_join(provider,observer)
        for field,value in [('workers',[]),('effects',{}),('candidate_sha256','e'*64),('cores',[])]:
            bad=copy.deepcopy(observer);bad[field]=value
            with self.assertRaises(ValueError):verify_real_join(provider,bad)

    def test_mock_or_different_nonce_cannot_inherit_the_real_verdict(self):
        from fixtures.production_contract import verify_real_join
        provider,observer=self.sample();provider['mock_enabled']=True
        with self.assertRaises(ValueError):verify_real_join(provider,observer)
        provider,observer=self.sample();observer['effects']={'/owned/effect-ffffffffffffffffffffffffffffffff.txt':['PW_EFFECT']}
        with self.assertRaises(ValueError):verify_real_join(provider,observer)


if __name__=='__main__':
    unittest.main()
