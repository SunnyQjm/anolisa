import argparse
import json
import hashlib
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'runtime/src'))
from fixtures.inline_native_contract import verify_pair
from cosh_lab.resize_render import read_cast


def events(path):
    header,rows=read_cast(Path(path))
    if header.get('width')!=80 or header.get('height')!=30:raise ValueError('native pair requires recorded 80x30 geometry')
    return rows


def main():
    parser=argparse.ArgumentParser()
    for name in ['candidate-result','bash-result','candidate-cast','bash-cast']:parser.add_argument('--'+name,required=True)
    args=parser.parse_args()
    a=json.loads(Path(args.candidate_result).read_text());b=json.loads(Path(args.bash_result).read_text())
    verify_pair(a,b,events(args.candidate_cast),events(args.bash_cast),Path(args.candidate_result).read_bytes(),Path(args.bash_result).read_bytes())
    print(json.dumps({'native_pair':'PASS','scenario':a['scenario'],'candidate_sha256':a['candidate_sha256'],'rpm_sha256':a['rpm_sha256'],'environment_run_id':a['environment_run_id'],'fixture_run_tokens':[a['fixture_run_token'],b['fixture_run_token']],'input_artifact_sha256':{name:hashlib.sha256(Path(getattr(args,name.replace('-','_'))).read_bytes()).hexdigest() for name in ['candidate-result','bash-result','candidate-cast','bash-cast']},'scope':'same candidate inputs/native Bash digest/actual driver packets and per-case native assertions; no timing or full gate verdict'}))


if __name__=='__main__':main()
