import argparse
import codecs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import tempfile
import termios
import threading
import time

from inline_contract import PREFIX, require, verify_outcome
from inline_identity import digest, identity
from inline_support import InlineReplay, cleanup_processes, consumer, current_consumer, descendants, emit_stage, journal_event, process_info, process_start, prompt_observation, assistance_enabled

TOOL=Path(__file__).resolve().parents[1]
PROMPT='original@bash:~$ '
RAW_PS1=br'\[\e[32m\]original@bash:\w$\[\e[0m\] '
IMPLEMENTED={'allow','deny','cancel','details','route-card'}


def original_prompt(snapshot, who):
    prompt=prompt_observation(snapshot,0)
    return (prompt['line']==PROMPT.rstrip() and prompt['x']==len(PROMPT)
            and prompt['cursor_visible'] and prompt['first_cell_green']
            and bool(who) and who['tty'].startswith('/dev/pts/')
            and who['foreground_pgrp']==who['pgrp'])


def agent_row_observed(history, token):
    return any(re.match(r'^\s*│\s*'+re.escape(token)+r'\s*(?:│)?\s*$',line) for line in history.splitlines())


def details_panel_observed(plain):
    start=max(plain.rfind('╭'),plain.rfind('┌'))
    if start<0:return False
    panel=plain[start:]
    complete=re.search(r'[╰└]─+[╯┘]',panel) is not None
    keys='Left/Right select  Enter confirm  d details  Esc cancel'
    policies=['Policy: user approval is required before any executable tool request.','Default: deny. Approved command is rechecked by read-only broker.']
    return complete and '> [ Details ]' in panel and 'INL_EFFECT' in panel and keys in panel and any(policy in panel for policy in policies)


def environment(home, port):
    values={key:os.environ[key] for key in ['PATH','TERM','LANG','LC_ALL'] if key in os.environ}
    values.update({'HOME':str(home),'TMPDIR':str(home),'TERM':'xterm-256color','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','COSH_SHELL_BOOTSTRAP_PATH':'0','COSH_SHELL_HEALTH_SCAN':'disabled','COSH_RECOMMENDATIONS_ENABLED':'0','COSH_SHELL_RAW_SHELL':'bash','COSH_SHELL_DEFAULT_SHELL':'bash','COSH_SHELL_APPROVAL_MODE':'auto','COSH_APPROVAL_MODE':'auto','COSH_CORE_PATH':PREFIX+'cosh-core','OPENAI_BASE_URL':f'http://127.0.0.1:{port}/v1','OPENAI_API_KEY':'canonical-loopback-only','COSH_AI_PROVIDER':'inline-loopback','COSH_MODEL':'inline-loopback','COSH_TELEMETRY_DISABLED_PATH':str(home/'telemetry_disabled')})
    return values


def run(options):
    require(options.scenario in IMPLEMENTED,'Blocked: inline scenario mechanism not implemented')
    require(shutil.which('tmux') is not None,'Blocked: existing tmux prerequisite missing')
    bound=identity(options.candidate,options.binding)
    for relative,key in [('fixtures/inline_fixture.py','fixture_sha256'),('fixtures/inline_support.py','support_sha256'),('runtime/src/cosh_lab/resize_render.py','replay_sha256')]:
        require(digest(TOOL/relative)==bound['tool_binding'].get(key),'unfrozen dependency: '+relative)
    output=Path(options.out)/f'inline-{options.scenario}-{os.getpid()}'
    output.mkdir(parents=True,exist_ok=False)
    requests=[];owned={};flags=set();error=None;child=None;remaining=[];replay=None
    result={'evidence_class':'installed-inline-loopback','real_provider':False,'identity_verified':True,'identity':bound,'scenario':options.scenario,'workers':[],'worker_monitor_complete':False,'bash_before':None,'bash_after':None,'physical_prompt_before_fresh':False,'agent_reply_observed':False,'followup_reply_observed':False,'ps1_expected_hex':RAW_PS1.hex(),'details_observed':False}
    outer=termios.tcgetattr(0)
    deadline=time.monotonic()+options.timeout_seconds
    with tempfile.TemporaryDirectory(prefix='cosh-inline-') as temporary:
        home=Path(temporary);physical=output/'physical-output.bin';effect=home/'effect';fresh=home/'fresh'
        (home/'.bashrc').write_text("PS1='"+RAW_PS1.decode()+"'\n")
        (home/'telemetry_disabled').touch()
        journal_event(output,'fixture_started',scenario=options.scenario,identity=bound,owned_home=str(home),home_inode=home.stat().st_ino)
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*unused):pass
            def do_POST(self):
                body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                requests.append(body)
                (output/'requests.json').write_text(json.dumps(requests,indent=2)+'\n')
                if len(requests)==1:
                    command="printf '%s\\n' INL_EFFECT >> "+shlex.quote(str(effect))+"; printf '%s\\n' INL_TOOL_DONE"
                    result['tool_command']=command
                    delta={'tool_calls':[{'index':0,'id':'inline-tool-1','type':'function','function':{'name':'shell','arguments':json.dumps({'command':command})}}]};finish='tool_calls'
                else:
                    delta={'content':'INL_MODEL_DONE' if len(requests)==2 else 'INL_FOLLOWUP_DONE'};finish='stop'
                chunks=[{'choices':[{'index':0,'delta':delta}]},{'choices':[{'index':0,'delta':{},'finish_reason':finish}]}]
                payload=(''.join('data: '+json.dumps(chunk)+'\n\n' for chunk in chunks)+'data: [DONE]\n\n').encode()
                self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Content-Length',str(len(payload)));self.send_header('Connection','close');self.end_headers();self.wfile.write(payload);self.wfile.flush()
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        decoder=codecs.getincrementaldecoder('utf-8')('replace');offset=0
        try:
            replay_root=home/'replay';replay_root.mkdir()
            replay=InlineReplay(replay_root,80,30,deadline)
            command=[PREFIX+'cosh-shell','raw','cosh-core']
            child=subprocess.Popen(['/usr/bin/script','-q','-e','-f','-E','never','-O',str(physical),'-c','exec '+shlex.join(command)],cwd=home,env=environment(home,server.server_port))
            owned[child.pid]=process_info(child.pid)
            while child.poll() is None:
                require(time.monotonic()<deadline,'fixture observation deadline elapsed; no SLO verdict')
                rows=descendants(child.pid)
                for row in rows:
                    owned[row['pid']]=row
                    if Path(row['exe']).name=='cosh-ui-worker':
                        result['workers'].append(row)
                        raise ValueError('worker activation observed in inline candidate')
                hosts=[row for row in rows if row['exe']==PREFIX+'cosh-shell']
                bash=[row for row in rows if hosts and row['ppid']==hosts[0]['pid'] and Path(row['exe']).name=='bash']
                who=consumer(bash[0]) if bash else None
                if who is not None:
                    value={key:who[key] for key in ['pid','start','cwd']}
                    if result['bash_before'] is None:result['bash_before']=value
                    result['bash_after']=value
                data=physical.read_bytes() if physical.exists() else b''
                if len(data)>offset:
                    replay.feed('o',decoder.decode(data[offset:]));offset=len(data)
                snapshot=replay.snapshot()
                prompt=original_prompt(snapshot,who)
                journal_event(output,'observation',physical_offset=offset,prompt=prompt_observation(snapshot,offset),consumer=who,processes=rows)
                def stage(name):
                    if name not in flags and current_consumer(who):
                        flags.add(name);journal_event(output,'stage',name=name,physical_offset=offset);emit_stage(name)
                if prompt and 'startup-ready' not in flags:stage('startup-ready')
                before=home/'ps1-before'
                if before.exists() and prompt:
                    if 'before-ready' not in flags:result['routing_before']=assistance_enabled(home)
                    result['ps1_before_hex']=before.read_bytes().hex();stage('before-ready')
                if options.scenario=='route-card' and len(requests)==1 and not effect.exists():
                    start=max(snapshot['plain'].rfind('╭'),snapshot['plain'].rfind('┌'))
                    panel=snapshot['plain'][start:] if start>=0 else ''
                    complete=re.search(r'[╰└]─+[╯┘]',panel) is not None
                    if complete and '> [ Deny ]' in panel and 'card-deny-ready' not in flags:
                        result['card_deny_offset']=offset;stage('card-deny-ready')
                    if complete and '> [ Allow once ]' in panel and 'card-deny-ready' in flags and offset>result['card_deny_offset'] and assistance_enabled(home) is True:
                        result['card_shift_observed']=True;stage('card-shift-ready')
                if details_panel_observed(snapshot['plain']):
                    result['details_observed']=True;stage('details-ready')
                if len(requests)>=2 and agent_row_observed(snapshot['history'],'INL_MODEL_DONE'):
                    result['agent_reply_observed']=True
                    if prompt and not fresh.exists():
                        result['physical_prompt_before_fresh']=True;stage('fresh-ready')
                if fresh.exists() and prompt:stage('followup-ready')
                if len(requests)==3 and agent_row_observed(snapshot['history'],'INL_FOLLOWUP_DONE') and prompt:
                    result['followup_reply_observed']=True;result['routing_after']=assistance_enabled(home);stage('exit-ready')
                time.sleep(0.01)
        except BaseException as failure:
            error=failure
            journal_event(output,'fixture_error',error_type=type(failure).__name__,message=str(failure))
        finally:
            journal_event(output,'cleanup_started',owned=list(owned.values()))
            server.shutdown();server.server_close();thread.join(timeout=2)
            if child is not None:
                if child.poll() is None:child.terminate()
                try:child.wait(timeout=2)
                except subprocess.TimeoutExpired:child.kill();child.wait(timeout=2)
            try:remaining=cleanup_processes(output,owned)
            except BaseException as failure:
                if error is None:error=failure
                remaining=[pid for pid,row in owned.items() if row and process_start(pid)==row['start']]
            if replay is not None:
                try:replay.close()
                except BaseException as failure:
                    if error is None:error=failure
            result.update(worker_monitor_complete=error is None,remaining_pids=remaining,shell_exit=child.returncode if child is not None else None,termios_restored=termios.tcgetattr(0)==outer,tool_results=[x for x in requests[1].get('messages',[]) if x.get('role')=='tool'] if len(requests)>=2 else [],requests=len(requests),host_tool_result=len(requests)>=2 and any(x.get('role')=='tool' and x.get('tool_call_id')=='inline-tool-1' for x in requests[1].get('messages',[])),effect_lines=effect.read_text().splitlines() if effect.exists() else [],fresh_effect_lines=fresh.read_text().splitlines() if fresh.exists() else [],ps1_after_hex=(home/'ps1-after').read_bytes().hex() if (home/'ps1-after').exists() else None,error=str(error) if error else None)
            (output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
            journal_event(output,'cleanup_finished',remaining_pids=remaining)
        if error:raise error
        verify_outcome(result)
        print('INL_RESULT '+json.dumps({'scenario':options.scenario,'status':'PASS','evidence_class':result['evidence_class']}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--candidate',required=True)
    parser.add_argument('--binding',required=True)
    parser.add_argument('--scenario',choices=sorted(IMPLEMENTED),required=True)
    parser.add_argument('--out',default='/var/lib/cosh-production-accept/evidence')
    parser.add_argument('--timeout-seconds',type=int,default=180)
    run(parser.parse_args())
