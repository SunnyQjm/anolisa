from pathlib import Path
import hashlib
import re

root=Path(__file__).resolve().parents[1]
path=root/'runtime/src/cosh_lab/cli.py'
source=path.read_text()
pattern=r"verifier, '([0-9a-f]{64})', '([0-9a-f]{64})'"
assert len(re.findall(pattern,source))==1
helper=hashlib.sha256((root/'fixtures/installed_identity.py').read_bytes()).hexdigest()
contract=hashlib.sha256((root/'fixtures/production_contract.py').read_bytes()).hexdigest()
updated=re.sub(pattern,"verifier, '"+helper+"', '"+contract+"'",source)
compile(updated,str(path),'exec')
path.write_text(updated)
print('runtime identity helper and contract hashes refreshed')
