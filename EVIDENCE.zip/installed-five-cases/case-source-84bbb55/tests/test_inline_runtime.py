import hashlib
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime/src'))
from cosh_lab.cli import installed_verifier_spec


class InlineRuntimeTests(unittest.TestCase):
    def test_modes_must_match_and_unknown_modes_never_fall_back(self):
        for a,b in [(None,'inline-first'),('inline-first',None),('unknown','unknown')]:
            with self.assertRaises(ValueError):installed_verifier_spec({'delivery_mode':a},{'delivery_mode':b})

    def test_inline_pins_exact_new_helpers_and_legacy_preserves_old_helpers(self):
        for mode,names in [('inline-first',('inline_identity.py','inline_contract.py')),(None,('installed_identity.py','production_contract.py'))]:
            value={} if mode is None else {'delivery_mode':mode}
            actual=installed_verifier_spec(value,value)
            self.assertEqual(actual[:2],names)
            self.assertEqual(actual[2:],tuple(hashlib.sha256((ROOT/'fixtures'/n).read_bytes()).hexdigest() for n in names))
