from pathlib import Path
import json
import subprocess

root=Path(__file__).resolve().parents[1]
out=root.parent/'strict-agent-controls'
out.mkdir(exist_ok=True)
results=[]
for kind,text,expected in [('echo-only','PW_ACK',False),('agent-row','│ PW_ACK',True)]:
    case={'version':1,'suite':'synthetic-runner-control','cases':[{'id':'CONTROL','real_provider':True,'command':['/usr/bin/printf',text+'\n'],'timeout_ms':2000,'input':[{'id':'real-followup','type':'wait_for','text':'PW_ACK','timeout_ms':300}], 'evidence':{'points':[{'id':'agent','trigger_event':'real-followup','required_types':['screenshot'],'layout_sensitive':False}]}}]}
    case_path=out/(kind+'.json');case_path.write_text(json.dumps(case))
    p=subprocess.run(['ruby',str(root/'runtime/scripts/e2e/cosh-shell-run-case'),'--case',str(case_path),'--id','CONTROL','--out',str(out/kind),'--quarantine-root',str(out/'quarantine')],capture_output=True,text=True)
    (out/(kind+'.stdout')).write_text(p.stdout);(out/(kind+'.stderr')).write_text(p.stderr)
    assert (p.returncode==0)==expected,(kind,p.returncode,p.stdout,p.stderr)
    results.append({'synthetic_control':kind,'exit':p.returncode,'matched_expected':True,'product_evidence':False})
(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
