# Durable installed-worker diagnostic

This version adds fsynced JSONL events to the frozen 9053 fixture. Each event records monotonic time. Worker verification, physical byte growth, pre-signal PID/start/offset, successful or failed os.kill errno, old process absence, replacement workers, full-frame recovery, exceptions, and cleanup survive fixture termination. No event contains provider credentials or request bodies.

This is diagnostic instrumentation, not timing or release acceptance. fsync can perturb timing. Product bytes, verification predicates, canonical cases, signal choice, polling and failure thresholds remain unchanged. Run only a scoped KILL diagnosis with a 60 second fixture observation deadline below the canonical outer timeout after Root independently reviews the new commit/archive/binding. Do not inherit 9053 healthy-case passes.

RED: importing journal_event/inject_fault failed before implementation. GREEN: four focused tests cover fsync, event-before-signal ordering, errno propagation, and persistence after os._exit(137). Full original 31 tests plus four new tests pass from this repository root. A first discovery invocation from the parent cwd failed to import fixtures; this was a test invocation error and did not execute product code.
