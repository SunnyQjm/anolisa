import argparse
import json
import os
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[1]


def check(out):
    out.mkdir(parents=True,exist_ok=False)
    runner=ROOT/'runtime/scripts/e2e/cosh-shell-run-case'
    rows=[]
    for name,events,secret in [('plain',[{'type':'line','text':'INL_INPUT'}],None),('split-redaction',[{'type':'bytes','hex':b'sentinel-'.hex()},{'type':'bytes','hex':b'secret\r'.hex()}],'sentinel-secret')]:
        case={'version':1,'suite':'synthetic-controlled-input-recorder','cases':[{'id':'CONTROL','controlled_input_recording':True,'command':['/bin/sh','-c','IFS= read -r x; printf "%s\\n" "$x"'],'timeout_ms':2000,'input':events+[{'id':'done','type':'wait_for','text':'\n','timeout_ms':1000}],'expect':{'status':0},'evidence':{'points':[{'id':'done','trigger_event':'done','required_types':['screenshot'],'layout_sensitive':False}]}}]}
        path=out/(name+'.json');path.write_text(json.dumps(case))
        env=dict(os.environ)
        if secret:env['COSH_E2E_REDACT_VALUES']=json.dumps([secret])
        result=subprocess.run(['ruby',str(runner),'--case',str(path),'--id','CONTROL','--out',str(out/name),'--quarantine-root',str(out/'quarantine')],env=env,capture_output=True,text=True,timeout=10)
        (out/(name+'.stdout')).write_text(result.stdout);(out/(name+'.stderr')).write_text(result.stderr)
        if result.returncode:raise RuntimeError('synthetic recorder control failed: '+name)
        cast=(out/name/'transcript.cast').read_text();events=[json.loads(s) for s in cast.splitlines()[1:]]
        packets=[row[2] for row in events if row[1]=='i']
        if name=='plain' and packets!=['INL_INPUT\r']:raise RuntimeError('actual controlled driver write missing or changed')
        if secret and (secret in cast or ''.join(packets)!='[REDACTED]\r'):raise RuntimeError('cross-packet input redaction failed')
        rows.append({'control':name,'passed':True,'input_frames':len(packets),'product_evidence':False})
    (out/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(rows))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True)
    check(parser.parse_args().out)
