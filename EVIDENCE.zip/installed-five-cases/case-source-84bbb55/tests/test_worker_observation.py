from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'fixtures'))
from production_worker import process_start, frame_ready

class WorkerObservationTests(unittest.TestCase):
    def test_zombie_stat_still_identifies_unreaped_process(self):
        tail=['Z']+['0']*18+['77']
        with patch.object(Path,'read_text',return_value='31 (worker) '+' '.join(tail)):
            self.assertEqual(process_start(31),77)

    def test_missing_proc_stat_means_process_is_gone(self):
        with patch.object(Path,'read_text',side_effect=FileNotFoundError):
            self.assertIsNone(process_start(31))

    def test_unreadable_proc_stat_is_not_process_retirement(self):
        with patch.object(Path,'read_text',side_effect=PermissionError):
            with self.assertRaises(PermissionError):process_start(31)

class CompletePhysicalFrameTests(unittest.TestCase):
    def frame(self,selected):
        return ('╭ ! Approval req-1 '+'─'*17+'╮\r\n│ > [ '+selected+' ] │\r\n╰'+'─'*38+'╯').encode()

    def test_actual_installed_physical_allow_and_deny_traces(self):
        data=Path(__file__).with_name('data')
        allow=(data/'physical-kill-observed-2669.bin').read_bytes()
        deny=(data/'physical-deny-selected.bin').read_bytes()
        self.assertEqual(len(allow),2669)
        self.assertTrue(frame_ready(allow,'Allow once'))
        self.assertFalse(frame_ready(allow,'Deny'))
        self.assertTrue(frame_ready(deny,'Deny'))
        self.assertFalse(frame_ready(deny,'Allow once'))
        self.assertFalse(frame_ready(deny[:-1],'Deny'))

    def test_complete_real_width_allow_and_deny_frames(self):
        self.assertTrue(frame_ready(self.frame('Allow once'),'Allow once'))
        self.assertTrue(frame_ready(self.frame('Deny'),'Deny'))

    def test_partial_utf8_and_unclosed_border_are_not_ready(self):
        frame=self.frame('Allow once')
        self.assertFalse(frame_ready(frame[:-1],'Allow once'))
        self.assertFalse(frame_ready(frame[:-3],'Allow once'))
        self.assertFalse(frame_ready(frame+b'\xe2','Allow once'))

    def test_latest_focus_and_new_incomplete_frame_reject_old_frame(self):
        old=self.frame('Allow once')
        self.assertFalse(frame_ready(old+self.frame('Deny'),'Allow once'))
        self.assertTrue(frame_ready(old+self.frame('Deny'),'Deny'))
        self.assertFalse(frame_ready(old+'╭ ! Approval req-2 ─╮'.encode(),'Allow once'))
        self.assertFalse(frame_ready(old[len(old):],'Allow once'))

if __name__=='__main__':unittest.main()
