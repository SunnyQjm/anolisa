import re

PREFIX='/usr/libexec/anolisa/cosh-ng/'
WORKER=PREFIX+'cosh-ui-worker'
REQUIRED={PREFIX+x for x in ['cosh-shell','cosh-core','cosh-gateway','cosh-ui-worker']}|{'/usr/bin/cosh-cli','/usr/bin/cosh-switch'}
SCENARIOS={'allow','deny','resize','kill','stall','focus','fallback-small','exhausted'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def production_environment(base, home):
    environment={k:base[k] for k in ['PATH','TERM','LANG','LC_ALL'] if k in base}
    environment.update({'HOME':str(home),'TMPDIR':str(home),'TERM':'xterm-256color','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','COSH_SHELL_ISOLATED':'1','COSH_SHELL_INTEGRATION':'enhanced','COSH_SHELL_BOOTSTRAP_PATH':'0','COSH_SHELL_HEALTH_SCAN':'disabled','COSH_RECOMMENDATIONS_ENABLED':'0','COSH_SHELL_RAW_SHELL':'bash','COSH_SHELL_DEFAULT_SHELL':'bash','COSH_SHELL_APPROVAL_MODE':'auto','COSH_APPROVAL_MODE':'auto','COSH_CORE_PATH':PREFIX+'cosh-core'})
    return environment


def validate_manifest(manifest, architecture):
    require(manifest.get('candidate_kind')=='frozen','a new frozen candidate is required')
    source=manifest.get('source',{})
    require(source.get('dirty') is False,'dirty source is not an acceptance input')
    for name in ['commit','tree']:
        value=source.get(name,source.get('git_'+name,''))
        require(isinstance(value,str) and re.fullmatch('[0-9a-f]{40}',value),'exact source '+name+' required')
    artifact=manifest.get('architectures',{}).get(architecture,{})
    require(re.fullmatch('[0-9a-f]{64}',artifact.get('rpm_sha256','')),'RPM SHA required')
    require(artifact.get('nevra','').endswith('.'+architecture),'RPM architecture mismatch')
    payload=artifact.get('payload_sha256',{})
    require(REQUIRED<=set(payload),'installed release worker and all six payloads required')
    require(all(isinstance(h,str) and re.fullmatch('[0-9a-f]{64}',h) for h in payload.values()),'invalid payload digest')
    return artifact


def validate_worker(record, host_pid, expected_sha):
    require(record['pid']>0 and record['start']>0,'worker PID/start required')
    require(record['ppid']==host_pid,'worker must be a child of the observed Host')
    require(record['exe']==WORKER and record['sha256']==expected_sha,'installed worker executable mismatch')
    require(record['sid']==record['pid'] and record['pgrp']==record['pid'],'worker process isolation mismatch')
    require(not record['environment_keys'],'worker inherited environment')
    require(record.get('cwd')=='/','worker working directory must be root')
    fds=record['fd']
    require(set(fds)=={'0','1','2','3'},'worker must own exactly stdio and IPC descriptors')
    require(all(fds.get(str(n))=='/dev/null' for n in [0,1,2]),'worker must not own terminal stdio')
    require(fds.get('3','').startswith('socket:['),'worker IPC fd missing')
    require(not any('/dev/pts/' in v or v=='/dev/tty' for v in fds.values()),'worker inherited a terminal fd')


def verify_outcome(result):
    scenario=result['scenario']
    require(scenario in SCENARIOS,'unknown scenario')
    require(result['evidence_class']=='installed-release-loopback' and result['identity_verified'],'not an installed release run')
    require(result['shell_exit']==0 and result['host_tool_result'] and result['requests']==2,'real Core round trip incomplete')
    require(result['effect_lines']==([] if scenario in ['deny','focus'] else ['PW_EFFECT']),'wrong or duplicate effect')
    require(not result['remaining_pids'] and result['termios_restored'],'cleanup or terminal restoration failed')
    require(result['bash_before'] is not None and result['bash_before']==result['bash_after'],'native Bash identity changed')
    require(bool(result['workers'])==(scenario!='fallback-small'),'worker presence does not match scenario')
    if scenario in ['kill','stall','focus','exhausted']:
        expected='SIGSTOP' if scenario=='stall' else 'SIGKILL'
        faults=result['faults'];recoveries=result.get('recoveries',[])
        require(len(faults)==(3 if scenario=='exhausted' else 1),'wrong number of actual faults')
        require(len(recoveries)==(2 if scenario=='exhausted' else 1),'actual worker rebuild missing')
        identities={(x['pid'],x['start']) for x in result['workers']}
        for fault in faults:
            require(fault['signal']==expected and fault.get('observed_complete_frame') is True,'actual fault record missing')
            require((fault['pid'],fault['start']) in identities,'fault target is not the pinned worker')
        for index,recovery in enumerate(recoveries):
            fault=faults[index]
            require((recovery['fault_pid'],recovery['fault_start'])==(fault['pid'],fault['start']),'rebuild belongs to a different fault')
            require(recovery['pid']!=fault['pid'] and (recovery['pid'],recovery['start']) in identities,'new installed worker identity missing')
            require(recovery['old_process_absent'] is True,'old worker process not retired')
            require(recovery['physical_frame_end']>fault['physical_offset'],'old card reused as recovery evidence')
            require(recovery['selected']==('Deny' if scenario=='focus' else 'Allow once'),'rebuilt approval focus changed')
            if scenario=='exhausted':
                require((recovery['pid'],recovery['start'])==(faults[index+1]['pid'],faults[index+1]['start']),'exhaustion did not follow the rebuilt worker chain')
        if scenario=='exhausted':
            require(result.get('exhausted_fallback_observed') is True and result.get('last_fault_process_absent') is True,'exhausted fallback or final retirement missing')
    if scenario=='resize':
        require(result['resize_observed'] and result['history_tokens_observed'],'resize/history oracle incomplete')


def validate_release_binding(binding):
    require(binding.get('build_profile')=='release','Root release build provenance required')
    require(re.fullmatch('[0-9a-f]{64}',binding.get('build_attestation_sha256','')),'release build attestation SHA required')


def verify_real_join(provider, observer):
    import hashlib
    require(provider.get('binary_origin')=='installed-rpm' and provider.get('mock_enabled') is False,'real installed provider evidence required')
    require(all(provider.get(k) is True for k in ['upstream_response_observed','semantic_checkpoint_observed','prompt_recovered']),'strict provider lifecycle incomplete')
    require(observer.get('evidence_class')=='installed-release-real-provider-observer','wrong observation evidence class')
    require(observer.get('rpm_sha256')==provider.get('rpm_sha256') and observer.get('candidate_sha256')==provider.get('installed_manifest_sha256'),'candidate or RPM join mismatch')
    require(observer.get('hosts') and observer.get('cores') and observer.get('workers'),'actual installed process observations required')
    host_pids={row['pid'] for row in observer['hosts']}
    for row in observer['workers']:
        require(row['ppid'] in host_pids,'worker is not owned by observed Host')
        validate_worker(row,row['ppid'],provider.get('payload_sha256',{}).get(WORKER))
    effects=observer.get('effects',{})
    require(len(effects)==1,'exactly one nonce-bound effect file required')
    name,lines=next(iter(effects.items()))
    nonce=re.fullmatch(r'.*/effect-([0-9a-f]{32})\.txt',name)
    require(nonce is not None and hashlib.sha256(nonce[1].encode()).hexdigest()==provider.get('request_nonce_sha256'),'effect is from another provider request')
    require(lines==['PW_EFFECT'],'real provider effect missing or repeated')
