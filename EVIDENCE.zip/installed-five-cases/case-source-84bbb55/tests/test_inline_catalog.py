import json
from pathlib import Path
import unittest

from fixtures.inline_native_contract import controlled_inputs

ROOT=Path(__file__).resolve().parents[1]


class InlineCatalogTests(unittest.TestCase):
    def test_native_actual_driver_writes_match_the_controlled_protocol(self):
        doc=json.loads((ROOT/'specs/shell-e2e-validation/cases/inline-production-native.yaml').read_text())
        self.assertIs(doc['defaults']['controlled_input_recording'],True)
        self.assertEqual(len(doc['cases']),13)
        for case in doc['cases']:
            with self.subTest(case=case['id']):
                argv=case['command'];scenario=argv[argv.index('--scenario')+1]
                actual=[]
                for event in case['input']:
                    if event['type']=='line':actual.append(event['text']+'\r')
                    if event['type']=='bytes':actual.append(bytes.fromhex(event['hex']).decode())
                self.assertEqual(actual,controlled_inputs(scenario))
                self.assertEqual(case['input'][0]['type'],'wait_for')
                self.assertIn('startup-ready',case['input'][0]['text'])
                self.assertLessEqual(int(argv[argv.index('--timeout-seconds')+1]),150)

    def test_real_provider_has_native_home_and_actual_agent_guard_ids(self):
        doc=json.loads((ROOT/'specs/shell-e2e-validation/cases/inline-production-real.yaml').read_text());case=doc['cases'][0]
        text=json.dumps(case)
        self.assertNotIn('COSH_SHELL_ISOLATED',text);self.assertNotIn('COSH_SHELL_INTEGRATION',text)
        self.assertIn('HOME=/var/lib/cosh-production-accept/real-workspace',case['command'])
        self.assertEqual({e['id'] for e in case['input'] if e.get('id') in {'provider-response','real-followup','shell-recovered'}},{'provider-response','real-followup','shell-recovered'})
        self.assertIn('{{COSH_LAB_REQUEST_NONCE_REVERSED}}',text)
        self.assertTrue(any('observer-stop' in e.get('text','') for e in case['input']))
