from production_contract import require

SCENARIOS={'pending','core-loss','managed-read','ordinary-byte'}
PROMPT='owner@host:~$ '


def validate_prompt(snapshot, original=None):
    require(snapshot['line']==PROMPT.rstrip() and snapshot['x']==len(PROMPT),'original PS1 is not on the current cursor line')
    require(snapshot['cursor_visible'] is True and snapshot['first_cell_green'] is True,'original prompt color or editable caret missing')
    require(snapshot['physical_offset']>0,'physical prompt witness missing')
    if original:
        require(snapshot['physical_offset']>original['physical_offset'],'historical prompt reused as restoration')


def verify_takeback(result):
    scenario=result['scenario']
    require(scenario in SCENARIOS,'unknown public takeback scenario')
    require(result['evidence_class']=='installed-release-loopback-takeback' and result['identity_verified'] is True,'installed identity is required')
    require(result['shell_exit']==0,'native Shell did not exit successfully')
    require(result['bash_before'] is not None and result['bash_before']==result['bash_after'],'original Bash PID/start/cwd/TTY changed')
    require(not result['remaining_pids'] and result['termios_restored'] is True and result['replay_cleaned'] is True,'owned processes or terminal were not restored')
    require(not result['old_prefix_exists'] and not result['old_suffix_exists'],'old packet input was executed')
    require(result['fresh_lines']==['TB_FRESH'],'first new native command missing or duplicated')
    validate_prompt(result['original_prompt'])
    validate_prompt(result['restored_prompt'],result['original_prompt'])
    native=result['native_consumer'];bash=result['bash_before']
    require(native is not None and all(native[k]==bash[k] for k in ['pid','start','tty','pgrp']) and native['foreground_pgrp']==bash['pgrp'],'original Bash did not own the TTY foreground before fresh input')
    require(result['native_restored_ns']<result['fresh_observed_ns'],'new input preceded native prompt restoration')
    require(not result['implicit_agent_reentry'] and not result['workers_after_takeback'] and not result['workers_at_sticky'],'implicit Agent/UI reentry observed')
    if scenario=='ordinary-byte':
        reader=result['consumer_before']
        require(reader is not None and reader['pid']>0 and reader['start']>0 and reader['tty']==bash['tty'] and reader['foreground_pgrp']==reader['pgrp']>0,'ordinary reader was not on the original foreground TTY')
        require(not result['workers'],'ordinary foreground unexpectedly created a UI worker')
        require(result['raw_byte_hex']=='1d' and result['consumer_before'] is not None,'ordinary foreground did not receive unchanged 0x1d')
        require(result['ack_observed'] is False and result['cutover_observed_ns'] is None,'ordinary foreground was mistaken for managed takeback')
        require(result['requests']==0 and not result['tool_results'] and not result['effect_lines'],'ordinary foreground started an Agent/tool')
        return
    require(result['ack_observed'] is True and result['cutover_observed_ns']<result['native_restored_ns'],'actual input ownership acknowledgement missing')
    if scenario=='core-loss':
        loss=result['core_loss']
        require(loss and loss['pid']>0 and loss['start']>0 and loss['signal']=='SIGKILL' and loss['signal_success'] is True,'verified Core loss was not injected')
        require(loss['old_absent'] is True and not loss['replacement_cores'],'Core remained alive or implicitly restarted')
        require(result['requests']==1 and not result['tool_results'] and not result['effect_lines'],'Core-loss pending request executed or restarted')
        return
    require(len(result['core_before'])==1 and result['core_before']==result['core_after'],'original Core PID/start changed')
    require(result['requests']==2 and len(result['tool_results'])==1,'same Core continuation must have exactly one tool response')
    tool=result['tool_results'][0]
    require(tool['tool_call_id']=='takeback-tool-1','tool response belongs to a different request')
    if scenario=='managed-read':
        consumer=result['consumer_before'];bash=result['bash_before']
        require(consumer is not None and consumer==result['consumer_after'],'managed foreground consumer changed')
        require(all(consumer[k]==bash[k] for k in ['pid','start','tty']) and consumer['foreground_pgrp']==bash['pgrp'],'foreground read is not the original Bash consumer')
        require(result['cutover_observed_ns']<result['answer_observed_ns']<result['native_restored_ns'],'read answer did not follow foreground ACK before native prompt')
        require(result['answer_lines']==['TB_NEW_ANSWER'] and result['foreground_prompt_drawn'] is False,'old read input or synthetic foreground PS1 observed')
        require(result['effect_lines']==['PW_EFFECT'] and all(token in tool['content'] for token in ['ShellCommandCompleted evidence','status: completed','exit_code: 0']),'managed operation effect/result missing or replayed')
    else:
        require(not result['effect_lines'] and ('denied' in tool['content'].lower() or 'cancel' in tool['content'].lower()),'unstarted pending operation was not explicitly denied')
