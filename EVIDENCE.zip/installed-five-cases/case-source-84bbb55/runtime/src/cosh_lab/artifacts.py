from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import uuid
from typing import Any


class RunArtifacts:
    def __init__(
        self, artifact_root: Path, operation: str, repo: dict[str, Any]
    ) -> None:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        self.run_id = f"{timestamp}-{uuid.uuid4().hex[:8]}"
        self.run_dir = artifact_root.expanduser().resolve() / self.run_id
        self.run_dir.mkdir(parents=True, exist_ok=False)
        self.manifest = {
            "schema_version": 1,
            "run_id": self.run_id,
            "operation": operation,
            "state": "planned",
            "capabilities": [],
            "environment_ref": "host",
            "repo": repo,
            "profile": {},
            "backend": {},
            "resources": [],
            "commands": [],
            "artifacts": [],
            "cleanup": {"status": "not-applicable"},
            "started_at": datetime.now(timezone.utc).isoformat(),
        }
        (self.run_dir / "commands.log").write_text("")
        self._write_json("run.json", self.manifest)

    def save_manifest(self) -> None:
        self._write_json("run.json", self.manifest)

    def complete(self, payload: dict[str, Any], final_state: str | None = None) -> None:
        self.manifest["state"] = final_state or (
            "completed" if payload["ok"] else "failed"
        )
        self.manifest["completed_at"] = datetime.now(timezone.utc).isoformat()
        self._write_json("result.json", payload)
        status = "PASS" if payload["ok"] else "FAIL"
        data = payload.get("data") or {}
        details = []
        for label, key in (
            ("Scope", "scope"),
            ("Execution evidence", "execution_evidence"),
            ("Aggregate gate", "gate"),
        ):
            if data.get(key) is not None:
                details.append(f"- {label}: `{data[key]}`")
        details.append(f"- Environment: `{self.manifest['environment_ref']}`")
        (self.run_dir / "report.md").write_text(
            f"# cosh-lab {self.manifest['operation']}\n\n"
            f"- Run: `{self.run_id}`\n"
            f"- Status: `{status}`\n"
            f"- Cleanup: `{self.manifest['cleanup']['status']}`\n"
            + "\n".join(details)
            + "\n"
        )
        self.manifest["artifacts"] = sorted(
            str(path.relative_to(self.run_dir))
            for path in self.run_dir.rglob("*")
            if path.is_file() and path.name not in {"checksums.sha256", "run.json"}
        )
        self._write_json("run.json", self.manifest)
        refresh_checksums(self.run_dir)

    def _write_json(self, name: str, value: dict[str, Any]) -> None:
        destination = self.run_dir / name
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
        temporary.replace(destination)


def write_json(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def refresh_checksums(run_dir: Path) -> None:
    checksum_lines = []
    for path in sorted(run_dir.rglob("*")):
        if not path.is_file() or path.name == "checksums.sha256":
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        checksum_lines.append(f"{digest}  {path.relative_to(run_dir)}")
    (run_dir / "checksums.sha256").write_text("\n".join(checksum_lines) + "\n")
