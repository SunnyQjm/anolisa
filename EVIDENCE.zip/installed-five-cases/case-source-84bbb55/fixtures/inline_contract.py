import re

PREFIX='/usr/libexec/anolisa/cosh-ng/'
REQUIRED={PREFIX+n for n in ['cosh-shell','cosh-core','cosh-gateway']}|{'/usr/bin/cosh-cli','/usr/bin/cosh-switch'}
SCENARIOS={'allow','deny','cancel','details','resize','managed-read','route-off','fragmented-prompt','route-card'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_manifest(manifest, architecture):
    require(manifest.get('delivery_mode')=='inline-first','explicit inline-first delivery mode required')
    require(manifest.get('candidate_kind')=='frozen','new frozen candidate required')
    source=manifest.get('source',{})
    require(source.get('dirty') is False,'clean source required')
    for key in ['commit','tree']:
        require(re.fullmatch('[0-9a-f]{40}',source.get(key,source.get('git_'+key,''))) is not None,'exact source '+key+' required')
    artifact=manifest.get('architectures',{}).get(architecture,{})
    require(architecture in {'aarch64','x86_64'},'unsupported architecture')
    require(re.fullmatch('[0-9a-f]{64}',artifact.get('rpm_sha256','')) is not None,'RPM digest required')
    require(artifact.get('nevra','').endswith('.'+architecture),'RPM architecture mismatch')
    payload=artifact.get('payload_sha256',{})
    require(set(payload)==REQUIRED,'exactly five inline payloads required; worker forbidden')
    require(all(isinstance(v,str) and re.fullmatch('[0-9a-f]{64}',v) for v in payload.values()),'invalid payload digest')
    return artifact


def validate_release_binding(binding):
    require(binding.get('delivery_mode')=='inline-first','explicit inline-first binding required')
    require(binding.get('build_profile')=='release','release build required')
    require(re.fullmatch('[0-9a-f]{64}',binding.get('build_attestation_sha256','')) is not None,'release attestation required')


def validate_tool_result(results, scenario, approved_command=None, cwd=None):
    require(isinstance(results,list) and len(results)==1,'one tool result required')
    value=results[0]
    require(value.get('role')=='tool' and value.get('tool_call_id')=='inline-tool-1','tool result identity mismatch')
    content=value.get('content')
    expected={'route-card':'Tool call denied: User denied this operation','deny':'Tool call denied: User denied this operation','cancel':'Tool call denied: User cancelled this operation'}.get(scenario,'INL_TOOL_DONE')
    if isinstance(content,str) and content.startswith('ShellCommandCompleted evidence\n') and scenario not in {'deny','cancel','route-card'}:
        parts=content.split('bounded_output_summary:\n')
        require(len(parts)==2,'one bounded output section required')
        header,output=parts
        fields={}
        for line in header.splitlines()[1:]:
            key,separator,value=line.partition(': ')
            require(bool(separator) and key not in fields,'duplicate or malformed Host receipt field')
            fields[key]=value
        require(isinstance(approved_command,str) and bool(approved_command) and fields.get('command')==approved_command,'Host receipt command mismatch')
        require(isinstance(cwd,str) and bool(cwd) and fields.get('cwd')==fields.get('end_cwd')==cwd,'Host receipt cwd mismatch')
        require(fields.get('status')=='completed' and fields.get('exit_code')=='0','Host receipt did not complete successfully')
        require(fields.get('output_id','').startswith('terminal-output://'),'Host receipt output identity required')
        content=output
    require(isinstance(content,str) and content.strip()==expected,'tool result decision/completion semantics mismatch')


def verify_outcome(result):
    scenario=result.get('scenario')
    require(scenario in SCENARIOS,'not an inline scenario; historical U02 cannot pass by withdrawal')
    require(result.get('evidence_class')=='installed-inline-loopback' and result.get('identity_verified') is True,'installed inline loopback identity required')
    validate_tool_result(result.get('tool_results'),scenario,result.get('tool_command'),(result.get('bash_before') or {}).get('cwd'))
    require(result.get('requests')==3 and result.get('host_tool_result') is True,'Core tool result and second request required')
    require(result.get('workers')==[] and result.get('worker_monitor_complete') is True,'complete no-worker monitor required')
    require(result.get('effect_lines')==([] if scenario in {'deny','cancel','route-card'} else ['INL_EFFECT']),'wrong or repeated authorized effect')
    require(result.get('fresh_effect_lines')==['INL_FRESH'],'first fresh ordinary command must execute once')
    require(result.get('physical_prompt_before_fresh') is True,'current editable native prompt required before fresh input')
    ps1=result.get('ps1_expected_hex')
    require(isinstance(ps1,str) and bool(ps1) and len(ps1)%2==0 and re.fullmatch('[0-9a-f]+',ps1) is not None,'raw original PS1 required')
    require(result.get('ps1_before_hex')==result.get('ps1_after_hex')==ps1,'raw PS1 changed')
    require(result.get('agent_reply_observed') is True and result.get('followup_reply_observed') is True,'physical Agent replies required')
    require(result.get('bash_before') is not None and result.get('bash_before')==result.get('bash_after'),'native Bash identity changed')
    require(result.get('remaining_pids')==[] and result.get('termios_restored') is True and result.get('shell_exit')==0,'cleanup or terminal restoration failed')
    for name in {'details':'details_observed','resize':'resize_observed','managed-read':'native_read_observed','route-off':'routing_off_observed','fragmented-prompt':'fragmented_prompt_observed'}.get(scenario,'').split():
        require(result.get(name) is True,'scenario witness required: '+name)

    if scenario=='route-card':
        require(result.get('card_shift_observed') is True and result.get('routing_before') is True and result.get('routing_after') is True,'card ShiftTab must navigate while assistance stays enabled')
