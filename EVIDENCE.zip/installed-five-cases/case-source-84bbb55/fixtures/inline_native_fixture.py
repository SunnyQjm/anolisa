import argparse
import codecs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import hashlib
import os
from pathlib import Path
import re
import secrets
import shlex
import shutil
import subprocess
import tempfile
import termios
import threading
import time

from inline_identity import command, digest, identity
from inline_contract import PREFIX, require
from inline_fixture import RAW_PS1, environment, original_prompt, PROMPT
from inline_native_contract import EXPECTED, SCENARIOS, verify_native, input_protocol_sha256
from inline_support import TOOL, InlineReplay, cleanup_processes, consumer, current_consumer, descendants, emit_stage, journal_event, process_info, process_start, assistance_enabled

SECONDARY='native-cont> '
DRAFT="printf '%s\\n' INL_DRAFT >> consumer-result"


def at_secondary(snapshot, who):
    lines=snapshot['plain'].splitlines();row=snapshot['y']
    return (row<len(lines) and lines[row].rstrip()==SECONDARY.rstrip() and snapshot['x']==len(SECONDARY)
            and snapshot['cursor_visible'] and bool(who) and who['tty'].startswith('/dev/pts/') and who['foreground_pgrp']==who['pgrp'])



def draft_observed(snapshot, who):
    lines=snapshot['plain'].splitlines();row=snapshot['y']
    return (row<len(lines) and lines[row]==PROMPT+DRAFT and snapshot['x']==len(PROMPT+DRAFT)
            and snapshot['cursor_visible'] and bool(who) and who['tty'].startswith('/dev/pts/') and who['foreground_pgrp']==who['pgrp'])

routing=assistance_enabled


def run(args):
    require(shutil.which('tmux') is not None,'Blocked: existing tmux prerequisite missing')
    bound=identity(args.candidate,args.binding)
    for relative,key in [('fixtures/inline_native_fixture.py','native_fixture_sha256'),('fixtures/inline_native_contract.py','native_contract_sha256'),('fixtures/inline_fixture.py','fixture_sha256'),('fixtures/inline_support.py','support_sha256'),('runtime/src/cosh_lab/resize_render.py','replay_sha256'),('runtime/scripts/e2e/cosh-shell-run-case','runner_sha256')]:
        require(digest(TOOL/relative)==bound['tool_binding'].get(key),'unfrozen native dependency: '+relative)
    require(bound['tool_binding'].get('native_input_protocol_sha256')==input_protocol_sha256(),'Root controlled input protocol not frozen')
    native=Path('/bin/bash').resolve()
    require(bound['tool_binding'].get('native_bash_path')==str(native),'native Bash path not frozen by Root')
    require(digest(native)==bound['tool_binding'].get('native_bash_sha256'),'native Bash binary not frozen by Root')
    require(command('rpm','-qf','--qf','%{NAME}-%{VERSION}-%{RELEASE}.%{ARCH}',str(native))==bound['tool_binding'].get('native_bash_nevra'),'native Bash package not frozen by Root')
    require(isinstance(bound['tool_binding'].get('new_run_id'),str) and bool(bound['tool_binding']['new_run_id']),'Root environment run binding missing')
    require(not (args.native_baseline and args.scenario=='route-idle'),'native Bash has no assistance toggle')
    output=Path(args.out)/f'native-{args.scenario}-{int(args.native_baseline)}-{os.getpid()}'
    output.mkdir(parents=True,exist_ok=False)
    result={'environment_run_id':bound['tool_binding']['new_run_id'],'host_boot_sha256':hashlib.sha256(Path('/proc/sys/kernel/random/boot_id').read_bytes()).hexdigest(),'mount_namespace':os.readlink('/proc/self/ns/mnt'),'fixture_run_token':secrets.token_hex(16),'input_protocol_sha256':input_protocol_sha256(),'scenario':args.scenario,'evidence_class':'native-bash-control' if args.native_baseline else 'installed-inline-native','native_baseline':args.native_baseline,'identity_verified':True,'candidate_sha256':bound['candidate_sha256'],'rpm_sha256':bound['rpm_sha256'],'architecture':bound['architecture'],'native_bash_sha256':digest(native),'native_bash_path':str(native),'ps1_expected_hex':RAW_PS1.hex(),'bash_before':None,'bash_after':None,'workers':[],'consumer_observed':False,'physical_prompt_before_fresh':False,'routing_off_observed':False}
    requests=[];owned={};flags=set();error=None;replay=None;child=None;remaining=[]
    outer=termios.tcgetattr(0);deadline=time.monotonic()+args.timeout_seconds
    with tempfile.TemporaryDirectory(prefix='cosh-inline-native-') as temporary:
        home=Path(temporary);physical=output/'physical-output.bin'
        (home/'.bashrc').write_text("PS1='"+RAW_PS1.decode()+"'\nPS2='"+SECONDARY+"'\n")
        (home/'telemetry_disabled').touch()
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*unused):pass
            def do_POST(self):
                requests.append({'event':'provider_POST_started'})
                (output/'unexpected-requests.json').write_text(json.dumps(requests,indent=2)+'\n')
                payload=b'data: {"choices":[{"index":0,"delta":{"content":"UNEXPECTED_NATIVE_PROVIDER"}}]}\n\ndata: [DONE]\n\n'
                self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload)
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        offset=0;decoder=codecs.getincrementaldecoder('utf-8')('replace')
        journal_event(output,'fixture_started',identity=bound,native_bash_sha256=digest(native),owned_home=str(home),home_inode=home.stat().st_ino)
        try:
            directory=home/'replay';directory.mkdir();replay=InlineReplay(directory,80,30,deadline)
            env=environment(home,server.server_port)
            if args.native_baseline:
                env={key:env[key] for key in ['PATH','TERM','LANG','LC_ALL','HOME','TMPDIR']}
                argv=[str(native),'--noprofile','--rcfile',str(home/'.bashrc'),'-i']
            else:argv=[PREFIX+'cosh-shell','raw','cosh-core']
            emit_stage('INL_NATIVE_RUN='+result['fixture_run_token']+';scenario='+args.scenario+';baseline='+str(int(args.native_baseline))+';protocol='+result['input_protocol_sha256'])
            child=subprocess.Popen(['/usr/bin/script','-q','-e','-f','-E','never','-O',str(physical),'-c','exec '+shlex.join(argv)],cwd=home,env=env)
            owned[child.pid]=process_info(child.pid)
            while child.poll() is None:
                require(time.monotonic()<deadline,'native observation deadline; no SLO verdict')
                rows=descendants(child.pid)
                for row in rows:
                    owned[row['pid']]=row
                    if Path(row['exe']).name=='cosh-ui-worker':
                        result['workers'].append(row);raise ValueError('worker activated in inline native case')
                require(not requests,'native consumer unexpectedly entered Agent')
                host=next((r for r in rows if r['exe']==PREFIX+'cosh-shell'),None)
                bash=next((r for r in rows if Path(r['exe']).name=='bash' and (args.native_baseline or host and r['ppid']==host['pid'])),None)
                who=consumer(bash,expected_exe=(str(native),bound['tool_binding']['native_bash_sha256'])) if bash else None
                if who is not None:
                    value={key:who[key] for key in ['pid','start','cwd','exe','sha256']}
                    if result['bash_before'] is None:result['bash_before']=value
                    result['bash_after']=value
                data=physical.read_bytes() if physical.exists() else b''
                if len(data)>offset:replay.feed('o',decoder.decode(data[offset:]));offset=len(data)
                snapshot=replay.snapshot();prompt=original_prompt(snapshot,who)
                def stage(name):
                    if name not in flags and current_consumer(who):
                        flags.add(name);journal_event(output,'stage',name=name,physical_offset=offset,consumer=who,routing=routing(home),snapshot=snapshot);emit_stage(name)
                if prompt:stage('startup-ready')
                if prompt and (home/'ps1-before').exists():
                    if 'before-ready' not in flags:result['routing_before']=None if args.native_baseline else routing(home)
                    stage('before-ready')
                if args.scenario in {'native-read','native-read-e','route-foreground'} and (home/'consumer-ready').exists() and not (home/'consumer-result').exists():
                    require(who is not None and who['foreground_pgrp']==who['pgrp'] and not prompt,'actual native read must own foreground without a fake main prompt')
                    result['consumer_observed']=True;stage('consumer-ready')
                if args.scenario in {'native-ps2','native-heredoc'} and at_secondary(snapshot,who) and not (home/'consumer-result').exists():
                    result['consumer_observed']=True;stage('consumer-ready')
                if args.scenario=='route-draft' and 'before-ready' in flags and not (home/'consumer-result').exists():
                    if draft_observed(snapshot,who):
                        result['consumer_observed']=True;stage('draft-ready')
                if args.scenario=='route-idle' and 'before-ready' in flags and routing(home) is False and prompt:
                    result['routing_off_observed']=True;stage('routing-off')
                    if b'??: command not found' in data:
                        result['consumer_observed']=True;result['physical_prompt_before_fresh']=True;stage('fresh-ready')
                elif (home/'consumer-result').exists() and prompt:
                    result['physical_prompt_before_fresh']=True;stage('fresh-ready')
                if prompt and (home/'fresh').exists():
                    result['routing_after']=None if args.native_baseline else routing(home);stage('exit-ready')
                time.sleep(0.01)
        except BaseException as failure:
            error=failure;journal_event(output,'fixture_error',message=str(failure),error_type=type(failure).__name__)
        finally:
            journal_event(output,'cleanup_started',owned=list(owned.values()))
            server.shutdown();server.server_close();thread.join(timeout=2)
            if child is not None:
                if child.poll() is None:child.terminate()
                try:child.wait(timeout=2)
                except subprocess.TimeoutExpired:child.kill();child.wait(timeout=2)
            try:remaining=cleanup_processes(output,owned)
            except BaseException as failure:
                if error is None:error=failure
                remaining=[pid for pid,row in owned.items() if row and process_start(pid)==row['start']]
            if replay is not None:
                try:replay.close()
                except BaseException as failure:
                    if error is None:error=failure
            def hex_file(name):
                path=home/name
                return path.read_bytes().hex() if path.exists() else None
            history=(home/'routing-history').read_text() if (home/'routing-history').exists() else ''
            result.update(requests=len(requests),monitor_complete=error is None,shell_exit=child.returncode if child else None,remaining_pids=remaining,termios_restored=termios.tcgetattr(0)==outer,consumer_expected_hex=EXPECTED[args.scenario].hex(),consumer_result_hex=hex_file('consumer-result') if args.scenario!='route-idle' else '',fresh_effect=(home/'fresh').read_text().splitlines() if (home/'fresh').exists() else [],ps1_before_hex=hex_file('ps1-before'),ps1_after_hex=hex_file('ps1-after'),routing_after=result.get('routing_after'),routing_history_count=len(re.findall(r'^\s*\d+\s+\?\? INL_ROUTING_OFF_SENTINEL\s*$',history,re.MULTILINE)),error=str(error) if error else None)
            (output/'result.json').write_text(json.dumps(result,indent=2)+'\n');journal_event(output,'cleanup_finished',remaining_pids=remaining)
        if error:raise error
        verify_native(result)
        print('INL_NATIVE_RESULT '+json.dumps({'fixture_run_token':result['fixture_run_token'],'input_protocol_sha256':result['input_protocol_sha256'],'scenario':args.scenario,'native_baseline':args.native_baseline,'result_sha256':digest(output/'result.json'),'status':'PASS'}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--candidate',required=True);parser.add_argument('--binding',required=True)
    parser.add_argument('--scenario',choices=sorted(SCENARIOS),required=True);parser.add_argument('--native-baseline',action='store_true')
    parser.add_argument('--out',default='/var/lib/cosh-production-accept/evidence');parser.add_argument('--timeout-seconds',type=int,default=150)
    run(parser.parse_args())
