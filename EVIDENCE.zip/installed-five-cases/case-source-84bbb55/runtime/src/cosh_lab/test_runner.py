from __future__ import annotations

import os
from pathlib import Path
import re
import subprocess
import sys
import time
from typing import Any


SCOPE_ORDER = (
    "unit",
    "logic",
    "protocol",
    "raw-cli",
    "shell-host",
    "crate",
    "workspace",
)


def build_test_plan(paths: list[str]) -> dict[str, Any]:
    selected: set[str] = set()
    reasons: list[str] = []
    risks: list[str] = []

    for raw_path in paths:
        path = raw_path.replace("\\", "/")
        if path.endswith(("Cargo.toml", "Cargo.lock", "build.rs")):
            selected.add("crate")
            reasons.append(f"{raw_path}: build metadata")
        elif "/crates/cosh-shell/src/ui/" in path:
            selected.update(("unit", "raw-cli", "shell-host"))
            reasons.append(f"{raw_path}: terminal UI")
        elif "/crates/cosh-shell/src/adapter/" in path or "/protocol" in path:
            selected.update(("unit", "protocol", "raw-cli"))
            reasons.append(f"{raw_path}: adapter/control protocol")
        elif "/crates/cosh-shell/tests/raw_cli" in path:
            selected.add("raw-cli")
            reasons.append(f"{raw_path}: raw CLI")
        elif "/crates/cosh-shell/tests/shell_host" in path:
            selected.add("shell-host")
            reasons.append(f"{raw_path}: shell host")
        elif "/crates/cosh-shell/src/" in path and path.endswith(".rs"):
            selected.update(("unit", "logic"))
            reasons.append(f"{raw_path}: owned Rust source")
        else:
            selected.add("crate")
            risks.append("unclassified")
            reasons.append(f"{raw_path}: unclassified change")

    if not paths:
        risks.append("no-changes")

    if "workspace" in selected:
        scopes = ["workspace"]
    elif "crate" in selected:
        scopes = ["crate"]
    else:
        scopes = [scope for scope in SCOPE_ORDER if scope in selected]

    commands = [
        {
            "scope": scope,
            "argv": command_for_scope(scope, None),
            "parallel_group": (
                "non-pty" if scope in {"unit", "logic", "protocol"} else "pty"
            ),
        }
        for scope in scopes
    ]
    return {
        "scopes": scopes,
        "reasons": reasons,
        "risks": sorted(set(risks)),
        "commands": commands,
        "wider_gate": "crate" if scopes != ["workspace"] else "workspace",
    }


def command_for_scope(
    scope: str,
    filter_value: str | None,
    jobs: int | None = None,
) -> list[str]:
    if jobs is not None and jobs < 1:
        raise ValueError("jobs must be at least 1")
    base = ["cargo", "test", "--locked", "--package", "cosh-shell"]
    if scope == "unit":
        command = [*base, "--lib", "--bins", *([filter_value] if filter_value else [])]
        if jobs:
            command.extend(("--", f"--test-threads={jobs}"))
        return command
    if scope in {"logic", "protocol"}:
        command = [*base, "--test", scope]
        if filter_value:
            command.append(filter_value)
        if jobs:
            command.extend(("--", f"--test-threads={jobs}"))
        return command
    if scope in {"raw-cli", "shell-host"}:
        command = [*base, "--test", scope.replace("-", "_")]
        if filter_value:
            command.extend((filter_value, "--", "--exact", "--test-threads=1"))
        else:
            default_jobs = 4 if sys.platform.startswith("linux") else 1
            command.extend(("--", f"--test-threads={jobs or default_jobs}"))
        return command
    if scope == "crate":
        return [*base, *([filter_value] if filter_value else []), "--", f"--test-threads={jobs or 4}"]
    if scope == "workspace":
        return ["cargo", "test", "--workspace", "--locked"]
    raise ValueError(f"unsupported test scope: {scope}")


def command_for_exact_case(scope: str, case: str) -> list[str]:
    if scope in {"unit", "logic", "protocol"}:
        command = command_for_scope(scope, case)
        command.extend(("--", "--exact", "--test-threads=1"))
        return command
    return command_for_scope(scope, case, jobs=1)


def failed_test_cases(output: str) -> list[str]:
    return sorted(
        {
            match.group(1)
            for line in output.splitlines()
            if (match := re.match(r"^test (.+) \.\.\. FAILED$", line.strip()))
        }
    )


def changed_paths(repo_root: Path, base: str) -> list[str]:
    diff = subprocess.run(
        ["git", "diff", "--name-only", base, "--"],
        cwd=repo_root,
        text=True,
        capture_output=True,
        check=False,
    )
    if diff.returncode != 0:
        raise ValueError(diff.stderr.strip() or f"cannot diff base {base}")
    untracked = subprocess.run(
        ["git", "ls-files", "--others", "--exclude-standard"],
        cwd=repo_root,
        text=True,
        capture_output=True,
        check=False,
    )
    if untracked.returncode != 0:
        raise ValueError(untracked.stderr.strip() or "cannot list untracked files")
    return sorted(
        {
            line
            for line in [*diff.stdout.splitlines(), *untracked.stdout.splitlines()]
            if line
        }
    )


def run_command(
    argv: list[str],
    cwd: Path,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    started = time.monotonic()
    try:
        result = subprocess.run(
            argv,
            cwd=cwd,
            env=env or os.environ.copy(),
            text=True,
            capture_output=True,
            check=False,
        )
    except KeyboardInterrupt as error:
        error.commands = [
            {
                "argv": argv,
                "cwd": str(cwd),
                "exit_code": 130,
                "duration_seconds": round(time.monotonic() - started, 6),
                "stdout": "",
                "stderr": "command interrupted",
            }
        ]
        raise
    return {
        "argv": argv,
        "cwd": str(cwd),
        "exit_code": result.returncode,
        "duration_seconds": round(time.monotonic() - started, 6),
        "stdout": result.stdout,
        "stderr": result.stderr,
    }
