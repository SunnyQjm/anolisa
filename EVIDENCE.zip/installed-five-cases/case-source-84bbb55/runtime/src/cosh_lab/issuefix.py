"""Issue-fix workflow facts and lifecycle commands.

Deterministic execution layer for the cosh-issue-fix orchestration skill.
Every function returns plain fact dictionaries; interpretation, root-cause
analysis, and go/no-go judgement stay in the skill layer.
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Sequence


SCHEMA_VERSION = 1
ALLOWED_TOOLS = ("gh", "git", "cargo", "bash")
DEFAULT_MAX_SUBJECT = 50


class IssueFixError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def run_tool(
    argv: list[str],
    *,
    cwd: Path | None = None,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    tool = argv[0]
    if tool not in ALLOWED_TOOLS:
        raise IssueFixError("tool-not-allowed", f"tool not in allowlist: {tool}")
    path = shutil.which(tool)
    if path is None:
        raise IssueFixError("tool-missing", f"required tool not found on PATH: {tool}")
    result = subprocess.run(
        [path, *argv[1:]],
        cwd=str(cwd) if cwd else None,
        text=True,
        capture_output=True,
        check=False,
    )
    if check and result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        raise IssueFixError(
            f"{tool}-failed",
            f"{' '.join(argv)} exited {result.returncode}: {detail}",
        )
    return result


def parse_repo(repo: str) -> tuple[str, str]:
    match = re.fullmatch(r"([\w.-]+)/([\w.-]+)", repo)
    if not match:
        raise IssueFixError("invalid-repo", f"expected OWNER/REPO, got: {repo}")
    return match.group(1), match.group(2)


def gh_auth_status() -> dict[str, Any]:
    path = shutil.which("gh")
    if path is None:
        return {"ok": False, "path": None, "detail": "gh not found on PATH"}
    result = subprocess.run(
        [path, "auth", "status"],
        text=True,
        capture_output=True,
        check=False,
    )
    lines = (result.stdout or result.stderr).strip().splitlines()
    return {
        "ok": result.returncode == 0,
        "path": path,
        "detail": lines[0].strip() if lines else None,
    }


def _json_lines(raw: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    decoder = json.JSONDecoder()
    index = 0
    text = raw.strip()
    while index < len(text):
        while index < len(text) and text[index] in " \r\n\t":
            index += 1
        if index >= len(text):
            break
        value, offset = decoder.raw_decode(text, index)
        if isinstance(value, list):
            items.extend(item for item in value if isinstance(item, dict))
        elif isinstance(value, dict):
            items.append(value)
        index = offset
    return items


def issue_audit(repo: str, num: int, repo_root: Path) -> dict[str, Any]:
    parse_repo(repo)
    probe = run_tool(
        ["git", "rev-parse", "--show-toplevel"], cwd=repo_root, check=False
    )
    if probe.returncode != 0:
        raise IssueFixError(
            "target-root-not-git",
            f"{repo_root} is not a git repository; run inside the local "
            f"clone of {repo} or pass --target-root <path-to-clone>",
        )
    view = run_tool(
        [
            "gh",
            "issue",
            "view",
            str(num),
            "--repo",
            repo,
            "--json",
            "number,state,title,labels,assignees,url",
        ]
    )
    issue = json.loads(view.stdout)
    timeline = run_tool(
        [
            "gh",
            "api",
            f"repos/{repo}/issues/{num}/timeline",
            "--paginate",
        ]
    )
    cross_references = []
    for event in _json_lines(timeline.stdout):
        if event.get("event") != "cross-referenced":
            continue
        source_issue = (event.get("source") or {}).get("issue") or {}
        cross_references.append(
            {
                "number": source_issue.get("number"),
                "title": source_issue.get("title"),
                "state": source_issue.get("state"),
                "is_pull_request": "pull_request" in source_issue,
                "url": source_issue.get("html_url"),
            }
        )
    log = run_tool(
        ["git", "log", "--oneline", "--all", f"--grep=#{num}"],
        cwd=repo_root,
    )
    commits = []
    for line in log.stdout.strip().splitlines():
        sha, _, subject = line.partition(" ")
        commits.append({"sha": sha, "subject": subject})
    return {
        "schema_version": SCHEMA_VERSION,
        "repo": repo,
        "issue": {
            "number": issue.get("number"),
            "state": issue.get("state"),
            "title": issue.get("title"),
            "labels": [label.get("name") for label in issue.get("labels", [])],
            "assignees": [user.get("login") for user in issue.get("assignees", [])],
            "url": issue.get("url"),
        },
        "cross_references": cross_references,
        "commits": commits,
        "status": "facts-only",
    }


def worktree_path(repo_root: Path, issue: int, slug: str) -> Path:
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", slug):
        raise IssueFixError("invalid-slug", f"slug must be kebab-case: {slug}")
    return repo_root / ".worktrees" / f"cosh-{issue}-{slug}"


def refresh_remote_base(repo_root: Path, base: str) -> None:
    if base.startswith("origin/"):
        run_tool(["git", "fetch", "origin"], cwd=repo_root)


def ws_up(
    repo_root: Path, issue: int, slug: str, base: str, *, refresh: bool = False
) -> dict[str, Any]:
    path = worktree_path(repo_root, issue, slug)
    branch = f"fix/cosh-{issue}-{slug}"
    if path.exists():
        if not refresh:
            raise IssueFixError(
                "worktree-exists",
                f"refusing to overwrite existing worktree: {path}; "
                "inspect with `ws status`, rerun with --refresh to "
                "fast-forward a clean worktree, or pick another slug",
            )
        return _ws_refresh(repo_root, path, branch, base)
    refresh_remote_base(repo_root, base)
    base_commit = run_tool(
        ["git", "rev-parse", base], cwd=repo_root
    ).stdout.strip()
    run_tool(
        ["git", "worktree", "add", str(path), "-b", branch, base],
        cwd=repo_root,
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "path": str(path),
        "branch": branch,
        "base": base,
        "base_commit": base_commit,
        "created": True,
        "refreshed": False,
    }


def _ws_refresh(
    repo_root: Path, path: Path, branch: str, base: str
) -> dict[str, Any]:
    """Fast-forward an existing clean worktree to the latest base.

    Only the safe reuse shape is automated: registered worktree on the
    expected branch, no local changes, no commits of its own. Anything
    else keeps the manual decision with the operator.
    """
    resolved = path.resolve()
    registered = [
        entry
        for entry in ws_status(repo_root)["worktrees"]
        if Path(entry.get("path", "")).resolve() == resolved
    ]
    if not registered:
        raise IssueFixError(
            "worktree-unregistered",
            f"directory exists but is not a registered worktree: {path}",
        )
    entry = registered[0]
    if entry.get("branch") != branch:
        raise IssueFixError(
            "worktree-branch-mismatch",
            f"worktree {path} is on {entry.get('branch')}, expected {branch}",
        )
    if entry.get("dirty"):
        raise IssueFixError(
            "worktree-dirty",
            f"worktree has uncommitted changes, refusing refresh: {path}",
        )
    refresh_remote_base(repo_root, base)
    base_commit = run_tool(
        ["git", "rev-parse", base], cwd=repo_root
    ).stdout.strip()
    ancestry = run_tool(
        ["git", "merge-base", "--is-ancestor", "HEAD", base_commit],
        cwd=path,
        check=False,
    )
    if ancestry.returncode != 0:
        raise IssueFixError(
            "worktree-diverged",
            f"worktree {path} has commits not on {base}; "
            "rebase or clean up manually before refreshing",
        )
    run_tool(["git", "merge", "--ff-only", base_commit], cwd=path)
    return {
        "schema_version": SCHEMA_VERSION,
        "path": str(path),
        "branch": branch,
        "base": base,
        "base_commit": base_commit,
        "created": False,
        "refreshed": True,
    }


def ws_status(repo_root: Path, slug: str | None = None) -> dict[str, Any]:
    listing = run_tool(
        ["git", "worktree", "list", "--porcelain"], cwd=repo_root
    )
    worktrees = []
    current: dict[str, Any] = {}
    for line in listing.stdout.splitlines() + [""]:
        if not line.strip():
            if current:
                worktrees.append(current)
                current = {}
            continue
        key, _, value = line.partition(" ")
        if key == "worktree":
            current["path"] = value
        elif key == "branch":
            current["branch"] = value.removeprefix("refs/heads/")
        elif key == "HEAD":
            current["commit"] = value
    selected = []
    for entry in worktrees:
        path = Path(entry.get("path", ""))
        if ".worktrees" not in path.parts:
            continue
        if slug and not path.name.endswith(f"-{slug}"):
            continue
        status = run_tool(
            ["git", "status", "--short"], cwd=path, check=False
        )
        entry["dirty"] = bool(status.stdout.strip())
        selected.append(entry)
    return {"schema_version": SCHEMA_VERSION, "worktrees": selected}


def ws_down(
    repo_root: Path, slug: str, *, apply: bool = False
) -> dict[str, Any]:
    matches = [
        entry
        for entry in ws_status(repo_root)["worktrees"]
        if Path(entry["path"]).name.endswith(f"-{slug}")
    ]
    if not matches:
        raise IssueFixError("worktree-not-found", f"no worktree matches slug: {slug}")
    if len(matches) > 1:
        raise IssueFixError(
            "worktree-ambiguous",
            f"slug matches multiple worktrees: {[m['path'] for m in matches]}",
        )
    entry = matches[0]
    if entry.get("dirty"):
        raise IssueFixError(
            "worktree-dirty",
            f"worktree has uncommitted changes, refusing removal: {entry['path']}",
        )
    result = {
        "schema_version": SCHEMA_VERSION,
        "path": entry["path"],
        "branch": entry.get("branch"),
        "dry_run": not apply,
        "removed": False,
        "branch_deleted": False,
        "registration_removed": False,
        "dir_residue": None,
        "residue_removed": False,
        "remove_error": None,
    }
    if not apply:
        return result
    removal = run_tool(
        ["git", "worktree", "remove", entry["path"]], cwd=repo_root, check=False
    )
    result["removed"] = removal.returncode == 0
    still_registered = any(
        e["path"] == entry["path"] for e in ws_status(repo_root)["worktrees"]
    )
    result["registration_removed"] = not still_registered
    if removal.returncode != 0:
        detail = (removal.stderr or removal.stdout).strip()
        result["remove_error"] = detail[-500:] or None
    # Ignored/untracked build residue routinely survives `git worktree
    # remove` (Directory not empty). Once the registration is gone the
    # directory is plain files, so finish the removal instead of leaving
    # a manual rm -rf step behind. Scope-guarded to .worktrees/.
    residue_path = Path(entry["path"])
    if (
        not still_registered
        and residue_path.exists()
        and ".worktrees" in residue_path.parts
    ):
        shutil.rmtree(residue_path, ignore_errors=True)
        result["residue_removed"] = not residue_path.exists()
    result["dir_residue"] = residue_path.exists()
    branch = entry.get("branch")
    if branch and not still_registered:
        deleted = run_tool(
            ["git", "branch", "-D", branch], cwd=repo_root, check=False
        )
        result["branch_deleted"] = deleted.returncode == 0
    return result


def _check_step(argv: list[str], cwd: Path) -> dict[str, Any]:
    result = run_tool(argv, cwd=cwd, check=False)
    detail = (result.stderr or result.stdout).strip()
    return {
        "command": " ".join(argv),
        "ok": result.returncode == 0,
        "detail": None if result.returncode == 0 else detail[-2000:],
    }


def _commit_lint(
    repo_root: Path, base: str, max_subject: int
) -> list[dict[str, Any]]:
    merge_base = run_tool(
        ["git", "merge-base", base, "HEAD"], cwd=repo_root
    ).stdout.strip()
    log = run_tool(
        ["git", "log", "--format=%H%x00%s%x00%b%x1e", f"{merge_base}..HEAD"],
        cwd=repo_root,
    )
    findings = []
    for record in log.stdout.split("\x1e"):
        record = record.strip("\n")
        if not record.strip():
            continue
        sha, _, rest = record.partition("\x00")
        subject, _, body = rest.partition("\x00")
        problems = []
        if len(subject) > max_subject:
            problems.append(
                f"subject length {len(subject)} exceeds {max_subject}"
            )
        if "Signed-off-by:" not in body:
            problems.append("missing Signed-off-by trailer")
        if problems:
            findings.append(
                {"sha": sha.strip(), "subject": subject, "problems": problems}
            )
    return findings


def _detect_cargo_root(repo_root: Path) -> Path | None:
    """Locate a unique nested cargo workspace when the repo root has none.

    Bounded to two directory levels and skips hidden directories, so
    monorepos like anolisa (src/cosh-ng) resolve without a flag while
    ambiguous layouts still fail loudly.
    """
    candidates = [
        manifest.parent
        for pattern in ("*/Cargo.toml", "*/*/Cargo.toml")
        for manifest in sorted(repo_root.glob(pattern))
        if not any(part.startswith(".") for part in manifest.parent.relative_to(repo_root).parts)
    ]
    if len(candidates) == 1:
        return candidates[0]
    if len(candidates) > 1:
        listed = ", ".join(
            str(path.relative_to(repo_root)) for path in candidates
        )
        raise IssueFixError(
            "cargo-root-ambiguous",
            f"multiple cargo workspaces found: {listed}; "
            "pass --cargo-root to pick one",
        )
    return None


def pr_preflight(
    repo_root: Path,
    *,
    base: str = "origin/main",
    test_command: str | None = None,
    max_subject: int = DEFAULT_MAX_SUBJECT,
    cargo_root: str = ".",
    gates: Sequence[str] = (),
) -> dict[str, Any]:
    cargo_dir = (repo_root / cargo_root).resolve()
    if not (cargo_dir / "Cargo.toml").is_file():
        detected = _detect_cargo_root(repo_root.resolve()) if cargo_root == "." else None
        if detected is None:
            raise IssueFixError(
                "cargo-root-invalid",
                f"no Cargo.toml under cargo root: {cargo_dir}; "
                "pass --cargo-root pointing at the cargo workspace",
            )
        cargo_dir = detected
    refresh_remote_base(repo_root, base)
    fmt = _check_step(["cargo", "fmt", "--check"], cargo_dir)
    clippy = _check_step(
        ["cargo", "clippy", "--workspace", "--all-targets", "--", "-D", "warnings"],
        cargo_dir,
    )
    if test_command:
        tests = _check_step(["cargo", *test_command.split()], cargo_dir)
    else:
        tests = {
            "command": None,
            "ok": None,
            "detail": "not-run; ok does not cover tests, run planned scopes separately",
        }
    # Deterministic repo CI gates (layout/inventory scripts and friends) run
    # from the cargo root so gate failures surface before the first CI round.
    gate_results = [
        _check_step(["bash", "-c", gate], cargo_dir) for gate in gates
    ]
    commit_lint = _commit_lint(repo_root, base, max_subject)
    merge_base = run_tool(
        ["git", "merge-base", base, "HEAD"], cwd=repo_root
    ).stdout.strip()
    changed = run_tool(
        ["git", "diff", "--name-only", f"{merge_base}..HEAD"], cwd=repo_root
    ).stdout.strip().splitlines()
    # Uncommitted work must join the drift scope: preflight often runs before
    # the first commit, and an empty committed diff silently skipped the
    # same-file overlap check against in-flight upstream commits.
    status = run_tool(["git", "status", "--porcelain"], cwd=repo_root, check=False)
    for line in status.stdout.splitlines():
        if len(line) <= 3:
            continue
        path = line[3:].strip().strip('"')
        if " -> " in path:
            path = path.split(" -> ", 1)[1].strip().strip('"')
        changed.append(path)
    changed = sorted({path for path in changed if path})
    drift_lines: list[str] = []
    if changed:
        drift = run_tool(
            ["git", "log", "--oneline", f"HEAD..{base}", "--", *changed],
            cwd=repo_root,
            check=False,
        )
        drift_lines = drift.stdout.strip().splitlines()
    ok = (
        fmt["ok"]
        and clippy["ok"]
        and tests["ok"] is not False
        and all(gate["ok"] for gate in gate_results)
        and not commit_lint
        and not drift_lines
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "cargo_root": str(cargo_dir.relative_to(repo_root.resolve()) or "."),
        "fmt": fmt,
        "clippy": clippy,
        "tests": tests,
        "gates": gate_results,
        "commit_lint": commit_lint,
        "upstream_drift": drift_lines,
        "ok": ok,
    }


def pr_assets_push(
    *,
    directory: Path,
    num: int,
    fork: str,
    expected_commit: str | None = None,
) -> dict[str, Any]:
    if not directory.is_dir():
        raise IssueFixError("assets-missing", f"asset directory not found: {directory}")
    files = sorted(
        entry for entry in directory.iterdir() if entry.is_file()
    )
    if not files:
        raise IssueFixError("assets-empty", f"no files to publish in: {directory}")
    if "://" in fork or fork.startswith("file:"):
        remote = fork
        raw_owner_repo = None
    else:
        owner, name = parse_repo(fork)
        remote = f"https://github.com/{owner}/{name}.git"
        raw_owner_repo = f"{owner}/{name}"
    branch = f"pr-{num}-assets"
    remote_ref = f"refs/heads/{branch}"
    remote_listing = run_tool(
        ["git", "ls-remote", remote, remote_ref], check=False
    )
    if remote_listing.returncode != 0:
        detail = (remote_listing.stderr or remote_listing.stdout).strip()
        raise IssueFixError(
            "git-failed",
            f"git ls-remote {remote_ref} exited {remote_listing.returncode}: {detail}",
        )
    previous_commit = None
    if remote_listing.stdout.strip():
        previous_commit = remote_listing.stdout.split()[0]
    if previous_commit and expected_commit is None:
        raise IssueFixError(
            "assets-expected-commit-required",
            f"asset branch {branch} exists; pass the SHA returned by the previous push",
        )
    if expected_commit != previous_commit and expected_commit is not None:
        raise IssueFixError(
            "assets-lease-mismatch",
            f"asset branch {branch} is {previous_commit or 'absent'}, not {expected_commit}",
        )
    with tempfile.TemporaryDirectory(prefix="cosh-lab-assets-") as staging:
        staging_path = Path(staging)
        for entry in files:
            shutil.copy2(entry, staging_path / entry.name)
        run_tool(["git", "init", "-q"], cwd=staging_path)
        run_tool(["git", "add", "-A"], cwd=staging_path)
        run_tool(
            [
                "git",
                "-c",
                "user.name=cosh-lab",
                "-c",
                "user.email=cosh-lab@localhost",
                "commit",
                "-q",
                "-m",
                f"assets: PR #{num} evidence",
            ],
            cwd=staging_path,
        )
        commit_sha = run_tool(
            ["git", "rev-parse", "HEAD"], cwd=staging_path
        ).stdout.strip()
        push = ["git", "push"]
        if previous_commit:
            push.append(f"--force-with-lease={remote_ref}:{expected_commit}")
        push.extend([remote, f"HEAD:{remote_ref}"])
        run_tool(push, cwd=staging_path)
    raw_url_prefix = (
        f"https://raw.githubusercontent.com/{raw_owner_repo}/{commit_sha}"
        if raw_owner_repo
        else None
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "branch": branch,
        "commit_sha": commit_sha,
        "previous_commit_sha": previous_commit,
        "files": [entry.name for entry in files],
        "raw_url_prefix": raw_url_prefix,
    }


def _paginated_comments(endpoint: str, kind: str) -> list[dict[str, Any]]:
    result = run_tool(["gh", "api", endpoint, "--paginate"])
    return [
        {
            "kind": kind,
            "author": (item.get("user") or {}).get("login"),
            "created_at": item.get("created_at"),
            "path": item.get("path"),
            "body": (item.get("body") or "")[:4000],
            "url": item.get("html_url"),
        }
        for item in _json_lines(result.stdout)
    ]


def _paginated_reviews(endpoint: str) -> list[dict[str, Any]]:
    result = run_tool(["gh", "api", endpoint, "--paginate"])
    return [
        {
            "kind": "review",
            "author": (item.get("user") or {}).get("login"),
            "created_at": item.get("submitted_at"),
            "path": None,
            "body": (item.get("body") or "")[:4000],
            "url": item.get("html_url"),
            "state": item.get("state"),
            "commit_id": item.get("commit_id"),
        }
        for item in _json_lines(result.stdout)
    ]


PENDING_CHECK_STATUSES = {"IN_PROGRESS", "QUEUED", "PENDING", "WAITING", "REQUESTED"}


def _parse_check_time(raw: str | None) -> datetime | None:
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None


def _check_is_pending(entry: dict[str, Any]) -> bool:
    return (entry.get("status") or "").upper() in PENDING_CHECK_STATUSES


def _pr_watch_snapshot(repo: str, num: int) -> dict[str, Any]:
    view = run_tool(
        [
            "gh",
            "pr",
            "view",
            str(num),
            "--repo",
            repo,
            "--json",
            "state,mergeable,reviewDecision,statusCheckRollup,url",
        ]
    )
    pull = json.loads(view.stdout)
    checks = []
    failed_jobs = []
    now = datetime.now(timezone.utc)
    for check in pull.get("statusCheckRollup") or []:
        started_at = check.get("startedAt")
        completed_at = check.get("completedAt")
        entry = {
            "name": check.get("name") or check.get("context"),
            "status": check.get("status") or check.get("state"),
            "conclusion": check.get("conclusion"),
            "url": check.get("detailsUrl") or check.get("targetUrl"),
            "started_at": started_at,
            "completed_at": completed_at,
        }
        # Elapsed time for in-progress jobs so callers can size their next
        # poll interval instead of guessing sleep durations.
        started = _parse_check_time(started_at)
        if started and not completed_at and _check_is_pending(entry):
            entry["elapsed_seconds"] = max(
                0, int((now - started).total_seconds())
            )
        checks.append(entry)
        if (entry["conclusion"] or "").upper() == "FAILURE":
            failed_jobs.append(entry)
    rerun_history = []
    for job in failed_jobs:
        match = re.search(r"/runs/(\d+)", job.get("url") or "")
        if not match:
            continue
        run_view = run_tool(
            [
                "gh",
                "run",
                "view",
                match.group(1),
                "--repo",
                repo,
                "--json",
                "databaseId,status,conclusion,attempt",
            ],
            check=False,
        )
        if run_view.returncode == 0:
            rerun_history.append(json.loads(run_view.stdout))
    return {
        "schema_version": SCHEMA_VERSION,
        "repo": repo,
        "number": num,
        "state": pull.get("state"),
        "mergeable": pull.get("mergeable"),
        "review_decision": pull.get("reviewDecision"),
        "url": pull.get("url"),
        "reviews": _paginated_comments(
            f"repos/{repo}/issues/{num}/comments", "issue-comment"
        )
        + _paginated_comments(
            f"repos/{repo}/pulls/{num}/comments", "review-comment"
        )
        + _paginated_reviews(f"repos/{repo}/pulls/{num}/reviews"),
        "checks": checks,
        "failed_jobs": failed_jobs,
        "rerun_history": rerun_history,
    }


def _review_activity_fingerprint(snapshot: dict[str, Any]) -> str:
    """Stable digest of review-visible activity: comment identity, PR
    state/mergeability/decision. Check progress is deliberately excluded so
    routine CI transitions do not count as review activity."""
    digest = hashlib.sha256()
    for comment in snapshot["reviews"]:
        digest.update(
            f"{comment.get('kind')}\n{comment.get('author')}\n"
            f"{comment.get('created_at')}\n{comment.get('url')}\n"
            f"{comment.get('state')}\n{comment.get('commit_id')}\n"
            f"{comment.get('body')}\n".encode()
        )
    digest.update(
        f"{snapshot.get('state')}\n{snapshot.get('mergeable')}\n"
        f"{snapshot.get('review_decision')}\n".encode()
    )
    return digest.hexdigest()


def _load_watch_cursor(path: Path, repo: str, num: int) -> str | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as error:
        raise IssueFixError("cursor-invalid", f"cannot read watch cursor {path}: {error}")
    if data.get("repo") != repo or data.get("number") != num:
        raise IssueFixError("cursor-invalid", f"watch cursor does not match {repo}#{num}")
    fingerprint = data.get("fingerprint")
    if not isinstance(fingerprint, str) or not fingerprint:
        raise IssueFixError("cursor-invalid", f"watch cursor has no fingerprint: {path}")
    return fingerprint


def _write_watch_cursor(path: Path, repo: str, num: int, fingerprint: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    try:
        temporary.write_text(
            json.dumps(
                {"repo": repo, "number": num, "fingerprint": fingerprint},
                sort_keys=True,
            )
            + "\n"
        )
        temporary.replace(path)
    except OSError as error:
        raise IssueFixError("cursor-write-failed", f"cannot write watch cursor {path}: {error}")


def pr_watch(
    repo: str,
    num: int,
    *,
    until_checks_complete: bool = False,
    until_review_activity: bool = False,
    timeout_seconds: int = 1800,
    interval_seconds: int = 60,
    max_polls: int = 0,
    classify_failures: bool = False,
    sleep_fn: Callable[[float], None] = time.sleep,
    cursor_file: Path | None = None,
) -> dict[str, Any]:
    parse_repo(repo)
    deadline = time.monotonic() + timeout_seconds
    polls = 0
    timed_out = False
    polls_exhausted = False
    baseline_fingerprint = (
        _load_watch_cursor(cursor_file, repo, num) if cursor_file else None
    )
    current_fingerprint: str | None = None
    review_activity = False
    while True:
        polls += 1
        snapshot = _pr_watch_snapshot(repo, num)
        checks_complete = not any(
            _check_is_pending(entry) for entry in snapshot["checks"]
        )
        if until_review_activity:
            fingerprint = _review_activity_fingerprint(snapshot)
            current_fingerprint = fingerprint
            if baseline_fingerprint is None:
                baseline_fingerprint = fingerprint
                if cursor_file:
                    _write_watch_cursor(cursor_file, repo, num, fingerprint)
            elif fingerprint != baseline_fingerprint:
                review_activity = True
            # Merged/closed PRs never produce further review activity.
            if review_activity or snapshot.get("state") in ("MERGED", "CLOSED"):
                break
        elif not until_checks_complete or checks_complete:
            break
        if max_polls and polls >= max_polls:
            # Segmented polling: callers with an outer wall-clock budget
            # (agent tool timeouts) re-invoke instead of blocking; the
            # checks mode is idempotent and the review mode resumes via
            # the cursor file.
            polls_exhausted = True
            break
        if time.monotonic() >= deadline:
            timed_out = True
            break
        sleep_fn(interval_seconds)
    if until_review_activity and cursor_file and current_fingerprint:
        _write_watch_cursor(cursor_file, repo, num, current_fingerprint)
    snapshot["wait"] = {
        "enabled": until_checks_complete or until_review_activity,
        "mode": (
            "review-activity"
            if until_review_activity
            else "checks-complete"
            if until_checks_complete
            else "single-shot"
        ),
        "polls": polls,
        "checks_complete": checks_complete,
        "review_activity": review_activity,
        "timed_out": timed_out,
        "polls_exhausted": polls_exhausted,
        "fingerprint": current_fingerprint,
    }
    if classify_failures:
        snapshot["failure_triage"] = _classify_check_failures(
            repo, snapshot["checks"]
        )
    return snapshot


_FAILED_TEST_RE = re.compile(r"test (\S+) \.\.\. FAILED")
_PANIC_RE = re.compile(r"panicked at ([^\n]+)")
_TIMEOUT_MARKER_RE = re.compile(r"timed out before marker: ([^\n]+)")
_JOB_URL_RE = re.compile(r"/job/(\d+)")


def _classify_check_failures(
    repo: str, checks: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Extract failing test names and panic evidence from failed CI jobs.

    Facts only: the skill layer combines these with the PR diff and
    main-branch history before calling anything flaky.
    """
    triage: list[dict[str, Any]] = []
    for entry in checks:
        if entry.get("conclusion") not in ("FAILURE", "failure"):
            continue
        record: dict[str, Any] = {
            "check": entry.get("name"),
            "job_id": None,
            "log_available": False,
            "failed_tests": [],
            "panics": [],
            "timeout_markers": [],
        }
        match = _JOB_URL_RE.search(entry.get("url") or "")
        if match:
            record["job_id"] = match.group(1)
            log = run_tool(
                [
                    "gh",
                    "run",
                    "view",
                    "--repo",
                    repo,
                    "--job",
                    record["job_id"],
                    "--log-failed",
                ],
                check=False,
            )
            if log.returncode == 0 and log.stdout:
                record["log_available"] = True
                record["failed_tests"] = sorted(
                    set(_FAILED_TEST_RE.findall(log.stdout))
                )
                record["panics"] = sorted(set(_PANIC_RE.findall(log.stdout)))[:10]
                record["timeout_markers"] = sorted(
                    set(_TIMEOUT_MARKER_RE.findall(log.stdout))
                )[:10]
        triage.append(record)
    return triage


def close_out(
    repo_root: Path,
    *,
    pr: int,
    repo: str,
    issue: int | None = None,
    slug: str | None = None,
    artifact_dirs: tuple[str, ...] = ("artifacts", "outputs"),
    extra_artifact_roots: tuple[Path, ...] = (),
) -> dict[str, Any]:
    probe = run_tool(
        ["git", "rev-parse", "--show-toplevel"], cwd=repo_root, check=False
    )
    if probe.returncode != 0:
        raise IssueFixError(
            "target-root-not-git",
            f"{repo_root} is not a git repository; --target-root must point "
            f"at the local clone of {repo} (the directory containing .git), "
            "not an outer workspace",
        )
    view = run_tool(
        ["gh", "pr", "view", str(pr), "--repo", repo, "--json", "state,headRefName"],
        check=False,
    )
    merged = False
    head_ref = None
    if view.returncode == 0:
        pull = json.loads(view.stdout)
        merged = pull.get("state") == "MERGED"
        head_ref = pull.get("headRefName")
    keywords = [str(pr)]
    if issue is not None:
        keywords.append(str(issue))
    if slug:
        keywords.append(slug)
    worktree_residue = [
        entry["path"]
        for entry in ws_status(repo_root)["worktrees"]
        if any(keyword in Path(entry["path"]).name for keyword in keywords)
    ]
    branches = run_tool(
        ["git", "branch", "--list", "--format=%(refname:short)"], cwd=repo_root
    ).stdout.strip().splitlines()
    branch_residue = [
        branch
        for branch in branches
        if branch == head_ref
        or any(keyword in branch for keyword in keywords if keyword != str(pr))
        or f"-{pr}-" in branch
    ]
    artifacts_residue = []
    scan_roots = [repo_root / base_name for base_name in artifact_dirs]
    scan_roots.extend(Path(root).expanduser().resolve() for root in extra_artifact_roots)
    for base_dir in scan_roots:
        if not base_dir.is_dir():
            continue
        for entry in sorted(base_dir.iterdir()):
            if any(keyword in entry.name for keyword in keywords):
                artifacts_residue.append(str(entry))
    assets_branch = f"pr-{pr}-assets"
    assets = _assets_branch_lookup(repo_root, assets_branch)
    cleaned = (
        merged
        and not worktree_residue
        and not branch_residue
        and not artifacts_residue
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "pr": pr,
        "merged": merged,
        "worktree_clean": not worktree_residue,
        "worktree_residue": worktree_residue,
        "branch_clean": not branch_residue,
        "branch_residue": branch_residue,
        "artifacts_residue": artifacts_residue,
        "assets": assets,
        "status": "cleaned" if cleaned else "cleanup-failed",
    }


def _assets_branch_lookup(repo_root: Path, branch: str) -> dict[str, Any]:
    """Probe every remote for the assets branch instead of guessing.

    Keeps the retention decision real: no branch found means there is
    nothing to decide, and a lookup failure is reported as unknown
    rather than silently assumed either way.
    """
    remotes_probe = run_tool(["git", "remote"], cwd=repo_root, check=False)
    remotes = (
        remotes_probe.stdout.strip().splitlines()
        if remotes_probe.returncode == 0
        else []
    )
    lookup_failed = False
    for remote in remotes:
        probe = run_tool(
            ["git", "ls-remote", "--heads", remote, f"refs/heads/{branch}"],
            cwd=repo_root,
            check=False,
        )
        if probe.returncode != 0:
            lookup_failed = True
            continue
        if probe.stdout.strip():
            return {
                "branch": branch,
                "exists": True,
                "remote": remote,
                "note": "keep while referenced by the merged PR body",
            }
    if lookup_failed:
        return {
            "branch": branch,
            "exists": None,
            "remote": None,
            "note": "remote lookup failed; verify manually before deciding",
        }
    return {
        "branch": branch,
        "exists": False,
        "remote": None,
        "note": "not found on any remote; no retention decision needed",
    }
