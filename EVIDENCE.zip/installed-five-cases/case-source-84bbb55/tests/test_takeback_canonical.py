import json
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]
PATH=ROOT/'historical/worker-and-takeback-ca52/cases/ui-takeback-production-installed.yaml'

class TakebackCanonicalTests(unittest.TestCase):
    def cases(self):
        self.assertTrue(PATH.exists(),'public Ctrl+] production canonical is missing')
        return json.loads(PATH.read_text())['cases']

    def test_all_four_public_scenarios_are_installed_and_start_after_native_screen_proof(self):
        cases=self.cases();self.assertEqual(len(cases),4)
        self.assertEqual({c['command'][-1] for c in cases},{'pending','core-loss','managed-read','ordinary-byte'})
        for case in cases:
            self.assertEqual(case['input'][0]['text'],'TB_NATIVE_START_READY')
            self.assertIn('/var/lib/cosh-production-accept/tools/fixtures/production_takeback.py',case['command'])
            self.assertFalse(case.get('real_provider',False));self.assertNotIn('COSH_UI_',json.dumps(case))
            events=case['input'];fresh=next(i for i,e in enumerate(events) if '>> fresh-effect' in e.get('text',''))
            self.assertTrue(any(e.get('text')=='TB_NATIVE_RESTORED' for e in events[:fresh]))
            self.assertTrue(case['evidence']['points'])
            self.assertIn('"status": "PASS"',case['expect']['contains'])

    def test_fixture_reserves_cleanup_time_inside_the_outer_deadline(self):
        for case in self.cases():
            command=case['command'];self.assertIn('--timeout-seconds',command)
            self.assertLessEqual(int(command[command.index('--timeout-seconds')+1]),150)

    def test_public_byte_is_one_driver_packet_and_native_case_is_not_a_ui_request(self):
        for case in self.cases():
            scenario=case['command'][-1];packets=[bytes.fromhex(e['hex']) for e in case['input'] if e['type']=='bytes']
            self.assertEqual(len(packets),1);self.assertEqual(packets[0].count(b'\x1d'),1)
            if scenario=='ordinary-byte':
                self.assertEqual(packets[0],b'\x1d')
                self.assertFalse(any(e.get('text','').startswith('??') for e in case['input']))
            elif scenario!='managed-read':
                prefix,suffix=packets[0].split(b'\x1d');self.assertIn(b'old-prefix',prefix);self.assertIn(b'old-suffix',suffix)
                self.assertFalse(any(e.get('name')=='enter' for e in case['input']))

    def test_foreground_fresh_answer_waits_for_ack_without_fake_prompt(self):
        case=next(c for c in self.cases() if c['command'][-1]=='managed-read');events=case['input']
        answer=next(i for i,e in enumerate(events) if e.get('text')=='TB_NEW_ANSWER')
        self.assertTrue(any(e.get('text')=='TB_FOREGROUND_RETURNED' for e in events[:answer]))
        self.assertFalse(any(e.get('text')=='TB_NATIVE_RESTORED' for e in events[:answer]))

if __name__=='__main__':unittest.main()
