独立复核结论：Go，限这两条正式owned canonical CI case及其八个视觉证据点。模型端是loopback fixture，不扩称真实provider或RPM安装验收。

RESIZE `20261013T173942Z-2d7da9a3` 与 FAULT `20261013T174100Z-3963ee8e` 均实际exit0、failures为空、case HEAD `02e70598f4dd3ebedbe30f06580a4dcab5bef208`。修正ownerRuntime的标准 `evidence verify` 两次均verified:true。

逐八点独立核对：

- 原始cast SHA、source HEAD、point ID、时间、PNG/WebM/provenance哈希全部匹配。
- provenance事件时间与实际cast一致，事件PTS为向上取整毫秒；选取最后PTS≤point的实际视频帧，无后续帧提前。
- 实际cast resize与provenance viewport一致，47x20点PNG为470x470，80x30点为787x694；视频保留统一画布，比较时按实际viewport图片尺寸裁切。
- 八份解码帧与原PNG逐RGB像素比较全部通过，最大差2；独立解码命令、PTS、裁切尺寸、关键帧文件记录在review.json。
- 逐八PNG目检确认CJK字形可读、卡底完整、Deny确实选中、resize后唯一当前卡与Bashready。对应八个视频帧已解码并与PNG像素配准。
- provenance logical_history保存完整左右sentinel之间16次CJK长行；screen_text确认唯一完整卡、Deny及普通Bashready。

正式两份sidecar的三ELF SHA精确保持bb749/9c73/d512；两Host都记录80x30→47x20、effect1、requests2、Host tool result、稳定Bash、termios复原及remaining_pids为空。FAULT同worker的Allow→Deny→Allow帧身份一致、日志段SHA重算一致，三次不同worker的真实Kill完整。

owned环境 `20261013T173325Z-4fd39a56` 已按标准down cleaned，独立readback记录在review.json；borrowed原容器按父会话边界保留。本次仅读取正式产物与源码，在此outputs目录保存独立复核证据，未修改产物、未运行env/cargo。
