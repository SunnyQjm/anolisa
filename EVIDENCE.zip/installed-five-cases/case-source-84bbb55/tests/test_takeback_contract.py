from copy import deepcopy
import importlib.util
from pathlib import Path
import unittest
import sys

ROOT=Path(__file__).resolve().parents[1]
CONTRACT=ROOT/'fixtures/takeback_contract.py'
sys.path.insert(0,str(ROOT/'fixtures'))

def sample(scenario='pending'):
    bash={'pid':31,'start':44,'cwd':'/owned/home','tty':'/dev/pts/7','pgrp':31}
    prompt={'line':'owner@host:~$','x':14,'cursor_visible':True,'first_cell_green':True,'physical_offset':7000}
    return {'scenario':scenario,'evidence_class':'installed-release-loopback-takeback','identity_verified':True,'shell_exit':0,'bash_before':bash,'bash_after':dict(bash),'original_prompt':{**prompt,'physical_offset':1000},'restored_prompt':dict(prompt),'native_restored_ns':20,'native_consumer':{'pid':31,'start':44,'tty':'/dev/pts/7','foreground_pgrp':31,'pgrp':31},'fresh_observed_ns':30,'fresh_lines':['TB_FRESH'],'old_prefix_exists':False,'old_suffix_exists':False,'effect_lines':[],'requests':2,'tool_results':[{'tool_call_id':'takeback-tool-1','content':'Tool call denied: User cancelled'}],'remaining_pids':[],'termios_restored':True,'replay_cleaned':True,'workers_after_takeback':[],'workers_at_sticky':[],'workers':[],'implicit_agent_reentry':False,'ack_observed':True,'cutover_observed_ns':10,'answer_observed_ns':15,'core_before':[{'pid':80,'start':81}],'core_after':[{'pid':80,'start':81}],'core_loss':None,'raw_byte_hex':None,'consumer_before':None,'consumer_after':None,'foreground_prompt_drawn':False,'answer_lines':[]}

class TakebackContractTests(unittest.TestCase):
    def contract(self):
        self.assertTrue(CONTRACT.exists(),'public takeback contract is missing')
        spec=importlib.util.spec_from_file_location('takeback_contract',CONTRACT)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        return module

    def test_pending_positive_control(self):
        self.contract().verify_takeback(sample())

    def test_rejects_native_prompt_without_actual_bash_foreground_ownership(self):
        row=sample();row['native_consumer']['foreground_pgrp']=99
        with self.assertRaises(ValueError):self.contract().verify_takeback(row)

    def test_rejects_bash_identity_or_cwd_change(self):
        verify=self.contract().verify_takeback
        for key,value in [('pid',32),('start',45),('cwd','/wrong'),('tty','/dev/pts/8')]:
            row=sample();row['bash_after'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):verify(row)

    def test_rejects_historical_prompt_hidden_caret_and_wrong_color(self):
        verify=self.contract().verify_takeback
        for key,value in [('line','old owner@host:~$ '),('x',0),('cursor_visible',False),('first_cell_green',False),('physical_offset',0),('physical_offset',1000)]:
            row=sample();row['restored_prompt'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):verify(row)

    def test_rejects_input_before_prompt_and_replayed_input(self):
        verify=self.contract().verify_takeback
        for change in [{'fresh_observed_ns':19},{'old_prefix_exists':True},{'old_suffix_exists':True},{'fresh_lines':['TB_FRESH','TB_FRESH']},{'effect_lines':['PW_EFFECT']}]:
            row=sample();row.update(change)
            with self.subTest(change=change),self.assertRaises(ValueError):verify(row)

    def test_rejects_missing_or_unrelated_denial_and_new_agent(self):
        verify=self.contract().verify_takeback
        for change in [{'requests':3},{'core_after':[{'pid':82,'start':83}]},{'tool_results':[]},{'tool_results':[{'tool_call_id':'wrong','content':'denied'}]},{'tool_results':[{'tool_call_id':'takeback-tool-1','content':'success'}]},{'implicit_agent_reentry':True},{'workers_after_takeback':[33]}]:
            row=sample();row.update(change)
            with self.subTest(change=change),self.assertRaises(ValueError):verify(row)

    def test_rejects_incomplete_cleanup_or_noninstalled_result(self):
        verify=self.contract().verify_takeback
        for change in [{'identity_verified':False},{'evidence_class':'debug'},{'shell_exit':137},{'remaining_pids':[31]},{'termios_restored':False},{'replay_cleaned':False},{'ack_observed':False}]:
            row=sample();row.update(change)
            with self.subTest(change=change),self.assertRaises(ValueError):verify(row)

    def test_core_loss_requires_actual_success_retirement_no_replacement(self):
        verify=self.contract().verify_takeback;row=sample('core-loss');row.update(requests=1,tool_results=[],core_loss={'signal':'SIGKILL','pid':90,'start':91,'signal_success':True,'old_absent':True,'replacement_cores':[]})
        verify(row)
        for key,value in [('signal_success',False),('old_absent',False),('replacement_cores',[92]),('start',0)]:
            bad=deepcopy(row);bad['core_loss'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):verify(bad)

    def test_managed_read_requires_same_actual_consumer_and_only_fresh_answer(self):
        verify=self.contract().verify_takeback;row=sample('managed-read');consumer={'pid':31,'start':44,'tty':'/dev/pts/7','foreground_pgrp':31,'pgrp':31};row.update(consumer_before=consumer,consumer_after=dict(consumer),answer_lines=['TB_NEW_ANSWER'],effect_lines=['PW_EFFECT'],tool_results=[{'tool_call_id':'takeback-tool-1','content':'ShellCommandCompleted evidence\nstatus: completed\nexit_code: 0'}])
        verify(row)
        for change in [{'consumer_after':{**consumer,'pid':32}},{'answer_lines':['TB_OLD_ANSWER']},{'foreground_prompt_drawn':True},{'effect_lines':['PW_EFFECT','PW_EFFECT']}]:
            bad=deepcopy(row);bad.update(change)
            with self.subTest(change=change),self.assertRaises(ValueError):verify(bad)

    def test_managed_reader_must_own_the_actual_foreground_group(self):
        row=sample('managed-read');row.update(consumer_before={'pid':31,'start':44,'tty':'/dev/pts/7','foreground_pgrp':99},consumer_after={'pid':31,'start':44,'tty':'/dev/pts/7','foreground_pgrp':99},answer_lines=['TB_NEW_ANSWER'],effect_lines=['PW_EFFECT'],tool_results=[{'tool_call_id':'takeback-tool-1','content':'ShellCommandCompleted evidence\nstatus: completed\nexit_code: 0'}])
        with self.assertRaises(ValueError):self.contract().verify_takeback(row)

    def test_ordinary_raw_byte_is_not_a_takeback(self):
        verify=self.contract().verify_takeback;row=sample('ordinary-byte');row.update(requests=0,tool_results=[],raw_byte_hex='1d',ack_observed=False,cutover_observed_ns=None,consumer_before={'pid':80,'start':81,'tty':'/dev/pts/7','foreground_pgrp':80,'pgrp':80})
        verify(row)
        for change in [{'raw_byte_hex':'03'},{'workers':[{'pid':20,'start':21}]},{'consumer_before':{'pid':80,'start':81,'tty':'/dev/pts/99','foreground_pgrp':80,'pgrp':80}},{'ack_observed':True},{'requests':1},{'cutover_observed_ns':10}]:
            bad=deepcopy(row);bad.update(change)
            with self.subTest(change=change),self.assertRaises(ValueError):verify(bad)

if __name__=='__main__':unittest.main()
