# Renderer budget exhaustion correction

This corrects the earlier inference in the preserved 9053 and 3c9 DESIGN.md, HANDOFF-NEEDS.json and CASE-MATRIX.json. Those immutable trees and all failed executions remain unchanged.

Renderer-only failure budget exhaustion with a healthy physical terminal intentionally falls back to a new inline approval. The pending operation may execute once only after fresh explicit approval on that inline card. That behavior is expected, and does not establish an unstarted-operation revocation defect.

Persistent physical-TTY write/flush failure is a different U02b scenario. It requires the original unstarted/committed/RunningUnknown contract and separate actual fault evidence. An installed worker kill, a replacement PID or the exhausted renderer case cannot substitute for that evidence. No expectation or original failed run is weakened or erased.

Authority: ui/issue-7891-production/u02b-contract-disposition.md and u02b-worker-vs-physical-review.md; Root explicitly requested this correction. Product source was not changed by this disposition.
