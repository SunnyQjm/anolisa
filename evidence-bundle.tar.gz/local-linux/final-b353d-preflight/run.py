import subprocess,pathlib,os,json
p=pathlib.Path(__file__).resolve().parent
wt='/Users/quejianming/vscode/cosh-shell-dev/anolisa/.worktrees/cosh-7891-ui-worker-production'
e=os.environ.copy();e['PATH']=str(p/'tools')+':'+e['PATH'];e['PYTHONPATH']='/Users/quejianming/vscode/cosh-shell-dev/.agents/skills/cosh-issue-fix/scripts/cosh-lab/src'
a=['python3.12','-m','cosh_lab','pr','preflight','--base','585d71fd3f6a95a9d3fb5fec50ab721fcf767306','--target-root',wt,'--cargo-root','src/cosh-ng','--gate','crates/cosh-shell/scripts/check-layout.sh','--gate','scripts/check-test-inventory.sh','--output','json']
(p/'command.json').write_text(json.dumps(a,indent=2))
r=subprocess.run(a,cwd=wt,env=e,capture_output=True,text=True);(p/'preflight.json').write_text(r.stdout);(p/'preflight.stderr').write_text(r.stderr);print(r.returncode,r.stdout,r.stderr,flush=True)
raise SystemExit(r.returncode)
