from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import time
from typing import Any


class BackendError(RuntimeError):
    pass


def target_cache_key(
    repo_root: Path,
    source_root: str,
    architecture: str,
    features: tuple[str, ...],
) -> str:
    toolchain_path = repo_root / source_root / "rust-toolchain.toml"
    toolchain = (
        hashlib.sha256(toolchain_path.read_bytes()).hexdigest()
        if toolchain_path.is_file()
        else "ambient"
    )
    identity = {
        "worktree": str(repo_root.resolve()),
        "architecture": architecture,
        "toolchain": toolchain,
        "features": sorted(features),
    }
    return hashlib.sha256(
        json.dumps(identity, sort_keys=True).encode()
    ).hexdigest()[:20]


def prepare_private_auth(
    profile: dict[str, Any],
    artifact_root: Path,
    run_id: str,
) -> tuple[Path | None, dict[str, str]]:
    auth = profile.get("auth", {})
    mode = auth.get("mode")
    if mode is None:
        return None, {}
    if mode != "private_copy":
        raise BackendError(f"unsupported auth mode for legacy bridge: {mode}")

    source_value = auth.get("source_path")
    files = auth.get("files")
    if not source_value or not isinstance(files, list) or not files:
        raise BackendError("private_copy auth requires source_path and non-empty files")

    source_root = Path(source_value).expanduser().resolve()
    private_auth = (
        artifact_root.expanduser().resolve()
        / ".runtime"
        / run_id
        / "private-home"
        / ".copilot-shell"
    )
    private_auth.mkdir(parents=True, mode=0o700)
    hashes: dict[str, str] = {}
    for relative_value in files:
        relative = Path(relative_value)
        if relative.is_absolute() or ".." in relative.parts:
            raise BackendError(
                f"auth file must be relative and contained: {relative_value}"
            )
        source = source_root / relative
        if not source.is_file() or source.is_symlink():
            raise BackendError(
                f"auth source file is unavailable or unsafe: {relative_value}"
            )
        destination = private_auth / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        destination.chmod(0o600)
        hashes[str(relative)] = hashlib.sha256(source.read_bytes()).hexdigest()
    return private_auth, hashes


def bridge_environment(
    backend: str,
    profile: dict[str, Any],
    private_auth: Path | None,
    repo_root: Path,
) -> dict[str, str]:
    section = profile[backend]
    name = str(section["name"])
    environment = os.environ.copy()
    environment["COSH_LAB_BACKEND"] = backend
    environment["COSH_LAB_SOURCE_ROOT"] = str(
        (repo_root / profile["source_root"]).resolve()
    )
    environment["COSH_LAB_REPO_ROOT"] = str(repo_root.resolve())
    environment["COSH_LAB_TARGET_CACHE_KEY"] = target_cache_key(
        repo_root,
        profile["source_root"],
        profile["arch"],
        ("default",),
    )
    environment["COSH_LAB_PROVISION_TIMEOUT"] = str(
        section.get("provision_timeout_seconds", 300)
    )
    if section.get("cargo_registry_index"):
        environment["COSH_LAB_CARGO_REGISTRY_INDEX"] = str(
            section["cargo_registry_index"]
        )
    if private_auth:
        environment["COSH_LAB_PRIVATE_AUTH"] = str(private_auth)
    if backend == "container":
        environment["COSH_ANOLIS_WORKSPACE"] = str(repo_root)
        environment["COSH_ANOLIS_CONTAINER"] = name
        environment["COSH_ANOLIS_ARCH"] = {
            "aarch64": "arm64",
            "x86_64": "amd64",
        }.get(profile["arch"], profile["arch"])
        if section.get("runtime"):
            environment["COSH_LAB_CONTAINER_RUNTIME"] = str(section["runtime"])
        for key, variable in (
            ("image", "COSH_ANOLIS_IMAGE"),
            ("cache_path", "COSH_ANOLIS_CACHE"),
            ("cpus", "COSH_ANOLIS_CPUS"),
            ("memory", "COSH_ANOLIS_MEMORY"),
        ):
            if section.get(key) is not None:
                environment[variable] = str(section[key])
        if private_auth:
            environment["COSH_ANOLIS_COPILOT_DIR"] = str(private_auth)
    elif backend == "vm":
        environment["COSH_LIMA_INSTANCE"] = name
        for key, variable in (
            ("image", "COSH_LIMA_IMAGE"),
            ("image_digest", "COSH_LIMA_IMAGE_DIGEST"),
            ("cache_path", "COSH_LIMA_CACHE"),
            ("cpus", "COSH_LIMA_CPUS"),
            ("memory", "COSH_LIMA_MEMORY"),
            ("disk", "COSH_LIMA_DISK"),
        ):
            if section.get(key) is not None:
                environment[variable] = str(section[key])
        if private_auth:
            environment["COSH_LIMA_COPILOT_DIR"] = str(private_auth)
    return environment


def run_bridge(
    bridge_path: Path,
    action: str,
    environment: dict[str, str],
    command: list[str] | None = None,
    timeout_seconds: int | None = None,
) -> dict[str, Any]:
    argv = [str(bridge_path), action]
    if command:
        argv.append(shlex.join(command))
    started = time.monotonic()
    try:
        result = subprocess.run(
            argv,
            env=environment,
            text=True,
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
        )
        exit_code = result.returncode
        stdout = result.stdout
        stderr = result.stderr
    except subprocess.TimeoutExpired as error:
        exit_code = 124
        stdout = error.stdout or ""
        stderr = error.stderr or f"backend {action} timed out"
        if isinstance(stdout, bytes):
            stdout = stdout.decode(errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
    except KeyboardInterrupt as error:
        error.commands = [
            {
                "argv": argv,
                "exit_code": 130,
                "duration_seconds": round(time.monotonic() - started, 6),
                "stdout": "",
                "stderr": f"backend {action} interrupted",
            }
        ]
        raise
    return {
        "argv": argv,
        "exit_code": exit_code,
        "duration_seconds": round(time.monotonic() - started, 6),
        "stdout": stdout,
        "stderr": stderr,
    }


def run_bridge_interactive(
    bridge_path: Path,
    environment: dict[str, str],
) -> dict[str, Any]:
    argv = [str(bridge_path), "shell"]
    started = time.monotonic()
    interactive = os.isatty(0)
    result = subprocess.run(
        argv,
        env=environment,
        text=True,
        capture_output=not interactive,
        check=False,
    )
    return {
        "argv": argv,
        "exit_code": result.returncode,
        "duration_seconds": round(time.monotonic() - started, 6),
        "stdout": result.stdout or "",
        "stderr": result.stderr or "",
    }


def remove_runtime(runtime_dir: Path, artifact_root: Path, run_id: str) -> None:
    expected = artifact_root.expanduser().resolve() / ".runtime" / run_id
    if runtime_dir.resolve() != expected:
        raise BackendError(f"refusing to remove unexpected runtime path: {runtime_dir}")
    if runtime_dir.exists():
        shutil.rmtree(runtime_dir)
