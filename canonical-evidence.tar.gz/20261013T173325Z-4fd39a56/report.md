# cosh-lab env-up

- Run: `20261013T173325Z-4fd39a56`
- Status: `PASS`
- Cleanup: `retained-by-policy`
- Environment: `host`
