from __future__ import annotations

from pathlib import Path
import tomllib
from typing import Any


class ProfileError(ValueError):
    pass


TOP_LEVEL_KEYS = {
    "schema_version",
    "name",
    "backend",
    "arch",
    "source_root",
    "artifact_root",
    "full_gate",
    "auth",
    "container",
    "vm",
    "ecs",
    "release",
}

REQUIRED_KEYS = {
    "schema_version",
    "name",
    "backend",
    "arch",
    "source_root",
    "artifact_root",
}

SECTION_KEYS = {
    "auth": {
        "mode",
        "source_path",
        "files",
        "allow_host_write",
        "ram_role_name",
    },
    "container": {
        "script_path",
        "name",
        "retain",
        "runtime",
        "image",
        "cache_path",
        "cpus",
        "memory",
        "provision_timeout_seconds",
        "cargo_registry_index",
    },
    "vm": {
        "script_path",
        "name",
        "retain",
        "image",
        "image_digest",
        "cache_path",
        "cpus",
        "memory",
        "disk",
        "provision_timeout_seconds",
        "cargo_registry_index",
    },
    "ecs": {
        "region",
        "image_id",
        "instance_type",
        "instance_type_allowlist",
        "vpc_id",
        "vswitch_id",
        "security_group_id",
        "internet_max_bandwidth_out",
        "max_lifetime_minutes",
        "max_parallel_instances",
        "metadata_mode",
        "system_disk_category",
        "cost",
        "transport",
    },
    "release": {
        "required_scopes",
        "required_backends",
        "required_arches",
        "required_cases",
        "require_real_provider",
    },
}


def load_profile(path: Path) -> dict[str, Any]:
    try:
        profile = tomllib.loads(path.read_text())
    except (OSError, tomllib.TOMLDecodeError) as error:
        raise ProfileError(f"cannot load profile {path}: {error}") from error

    unknown = sorted(set(profile) - TOP_LEVEL_KEYS)
    if unknown:
        raise ProfileError(f"unknown profile keys: {', '.join(unknown)}")

    missing = sorted(REQUIRED_KEYS - set(profile))
    if missing:
        raise ProfileError(f"missing profile keys: {', '.join(missing)}")

    if type(profile["schema_version"]) is not int or profile["schema_version"] != 1:
        raise ProfileError("schema_version must be 1")
    for key in ("name", "backend", "arch", "source_root", "artifact_root"):
        if not isinstance(profile[key], str) or not profile[key]:
            raise ProfileError(f"{key} must be a non-empty string")
    if profile["backend"] not in {"container", "vm", "ecs"}:
        raise ProfileError(f"unsupported backend: {profile['backend']}")
    if profile["arch"] not in {"arm64", "aarch64", "amd64", "x86_64"}:
        raise ProfileError(f"unsupported arch: {profile['arch']}")
    if "full_gate" in profile and (
        not isinstance(profile["full_gate"], str)
        or profile["full_gate"] not in {"crate", "workspace"}
    ):
        raise ProfileError("full_gate must be crate or workspace")
    source_root = Path(profile["source_root"])
    if source_root.is_absolute() or ".." in source_root.parts:
        raise ProfileError(
            "source_root must be relative and contained in the repository"
        )

    for section, allowed_keys in SECTION_KEYS.items():
        value = profile.get(section)
        if value is None:
            continue
        if not isinstance(value, dict):
            raise ProfileError(f"{section} must be a table")
        nested_unknown = sorted(set(value) - allowed_keys)
        if nested_unknown:
            dotted = ", ".join(f"{section}.{key}" for key in nested_unknown)
            raise ProfileError(f"unknown profile keys: {dotted}")

    if profile["backend"] in {"container", "vm"}:
        section = profile.get(profile["backend"])
        if (
            not isinstance(section, dict)
            or not isinstance(section.get("name"), str)
            or not section["name"]
        ):
            raise ProfileError(f"{profile['backend']} profile requires a name")
        for key in ("script_path", "image", "image_digest", "cache_path", "memory", "disk"):
            if key in section and (
                not isinstance(section[key], str) or not section[key]
            ):
                raise ProfileError(
                    f"{profile['backend']}.{key} must be a non-empty string"
                )
        if "retain" in section and not isinstance(section["retain"], bool):
            raise ProfileError(f"{profile['backend']}.retain must be a boolean")
        if section.get("runtime") is not None and section["runtime"] not in {
            "container",
            "docker",
            "podman",
        }:
            raise ProfileError(
                "container.runtime must be one of container, docker, podman"
            )
        if "cpus" in section and (
            type(section["cpus"]) is not int or section["cpus"] < 1
        ):
            raise ProfileError(
                f"{profile['backend']}.cpus must be a positive integer"
            )
        if (
            profile["backend"] == "vm"
            and not section.get("script_path")
            and not section.get("image")
        ):
            raise ProfileError("repository VM bridge requires vm.image")
        if (
            profile["backend"] == "vm"
            and not section.get("script_path")
            and profile["arch"] not in {"arm64", "aarch64"}
        ):
            raise ProfileError("repository VM bridge supports only arm64")
        provision_timeout = section.get("provision_timeout_seconds", 300)
        if (
            not isinstance(provision_timeout, int)
            or not 30 <= provision_timeout <= 1800
        ):
            raise ProfileError("provision_timeout_seconds must be between 30 and 1800")
        cargo_registry_index = section.get("cargo_registry_index")
        if cargo_registry_index is not None and (
            not isinstance(cargo_registry_index, str)
            or not cargo_registry_index.startswith("sparse+https://")
            or not cargo_registry_index.endswith("/")
            or any(character in cargo_registry_index for character in '"\r\n\t ')
        ):
            raise ProfileError(
                "cargo_registry_index must be a sparse+https URL ending in /"
            )
        auth = profile.get("auth", {})
        if auth.get("allow_host_write") is True:
            raise ProfileError("writable host auth is disabled")
        if auth and auth.get("mode") != "private_copy":
            raise ProfileError("container and vm auth mode must be private_copy")
        if auth:
            files = auth.get("files")
            if (
                not isinstance(auth.get("source_path"), str)
                or not auth["source_path"]
                or not isinstance(files, list)
                or not files
                or not all(isinstance(item, str) and item for item in files)
            ):
                raise ProfileError(
                    "private_copy auth requires source_path and non-empty files"
                )

    if profile["backend"] == "ecs":
        ecs = profile.get("ecs")
        auth = profile.get("auth")
        if not isinstance(ecs, dict) or not isinstance(auth, dict):
            raise ProfileError("ecs profile requires auth and ecs tables")
        required_ecs = {
            "region",
            "image_id",
            "instance_type",
            "instance_type_allowlist",
            "vpc_id",
            "vswitch_id",
            "security_group_id",
            "max_lifetime_minutes",
            "max_parallel_instances",
            "metadata_mode",
            "system_disk_category",
            "cost",
        }
        missing_ecs = sorted(required_ecs - set(ecs))
        if missing_ecs:
            raise ProfileError(f"missing ecs keys: {', '.join(missing_ecs)}")
        if (
            auth.get("mode") != "ecs_ram_role"
            or not isinstance(auth.get("ram_role_name"), str)
            or not auth["ram_role_name"]
        ):
            raise ProfileError("ecs auth requires ecs_ram_role and ram_role_name")
        for key in (
            "region",
            "image_id",
            "instance_type",
            "vpc_id",
            "vswitch_id",
            "security_group_id",
            "metadata_mode",
            "system_disk_category",
        ):
            if not isinstance(ecs[key], str) or not ecs[key]:
                raise ProfileError(f"ecs.{key} must be a non-empty string")
        allowlist = ecs["instance_type_allowlist"]
        if (
            not isinstance(allowlist, list)
            or not all(isinstance(item, str) and item for item in allowlist)
            or ecs["instance_type"] not in allowlist
        ):
            raise ProfileError(
                f"instance type {ecs['instance_type']} is outside instance_type_allowlist"
            )
        if type(ecs["max_lifetime_minutes"]) is not int:
            raise ProfileError("max_lifetime_minutes must be an integer")
        if not 30 <= ecs["max_lifetime_minutes"] <= 1440:
            raise ProfileError("max_lifetime_minutes must be between 30 and 1440")
        if type(ecs["max_parallel_instances"]) is not int:
            raise ProfileError("max_parallel_instances must be an integer")
        if not 1 <= ecs["max_parallel_instances"] <= 10:
            raise ProfileError("max_parallel_instances must be between 1 and 10")
        if ecs["metadata_mode"] != "required":
            raise ProfileError("metadata_mode must be required")
        bandwidth = ecs.setdefault("internet_max_bandwidth_out", 0)
        if type(bandwidth) is not int or bandwidth not in (0, 1):
            raise ProfileError("internet_max_bandwidth_out must be 0 or 1")
        cost = ecs["cost"]
        if not isinstance(cost, dict):
            raise ProfileError("ecs.cost must be a table")
        unknown_cost = sorted(set(cost) - {"currency", "max_estimated_run"})
        if unknown_cost:
            dotted = ", ".join(f"ecs.cost.{key}" for key in unknown_cost)
            raise ProfileError(f"unknown profile keys: {dotted}")
        if set(cost) != {"currency", "max_estimated_run"}:
            raise ProfileError("ecs.cost requires currency and max_estimated_run")
        if not isinstance(cost["currency"], str) or not cost["currency"]:
            raise ProfileError("ecs.cost.currency must be a non-empty string")
        if (
            isinstance(cost["max_estimated_run"], bool)
            or not isinstance(cost["max_estimated_run"], (int, float))
            or cost["max_estimated_run"] < 0
        ):
            raise ProfileError("ecs.cost.max_estimated_run must be non-negative")
        transport = ecs.get("transport", {})
        if not isinstance(transport, dict):
            raise ProfileError("ecs.transport must be a table")
        allowed_transport = {
            "workbench_profile",
            "ssh_user",
            "public_host",
            "private_host",
            "proxy_jump",
            "identity_file",
            "known_hosts_file",
            "connect_timeout_seconds",
        }
        unknown_transport = sorted(set(transport) - allowed_transport)
        if unknown_transport:
            dotted = ", ".join(
                f"ecs.transport.{key}" for key in unknown_transport
            )
            raise ProfileError(f"unknown profile keys: {dotted}")
        for key in (
            "workbench_profile",
            "ssh_user",
            "public_host",
            "private_host",
            "proxy_jump",
            "identity_file",
            "known_hosts_file",
        ):
            if key in transport and (
                not isinstance(transport[key], str) or not transport[key]
            ):
                raise ProfileError(
                    f"ecs.transport.{key} must be a non-empty string"
                )
        timeout = transport.get("connect_timeout_seconds", 5)
        if type(timeout) is not int or not 1 <= timeout <= 30:
            raise ProfileError(
                "ecs.transport.connect_timeout_seconds must be between 1 and 30"
            )

    release = profile.get("release")
    if release is not None:
        if "full_gate" not in profile:
            raise ProfileError("release profile requires full_gate")
        for key in (
            "required_scopes",
            "required_backends",
            "required_arches",
            "required_cases",
        ):
            values = release.get(key)
            if not isinstance(values, list) or not values or not all(
                isinstance(item, str) and item for item in values
            ):
                raise ProfileError(f"release.{key} must be a non-empty string array")
        if not set(release["required_scopes"]) <= {"crate", "workspace"}:
            raise ProfileError("release.required_scopes must contain crate or workspace")
        if profile["full_gate"] not in release["required_scopes"]:
            raise ProfileError("release.required_scopes must include full_gate")
        if not set(release["required_backends"]) <= {"container", "vm", "ecs"}:
            raise ProfileError("release.required_backends contains an unsupported backend")
        if not set(release["required_arches"]) <= {
            "arm64",
            "aarch64",
            "amd64",
            "x86_64",
        }:
            raise ProfileError("release.required_arches contains an unsupported arch")
        if release.get("require_real_provider") is not True:
            raise ProfileError("release.require_real_provider must be true")
    return profile
