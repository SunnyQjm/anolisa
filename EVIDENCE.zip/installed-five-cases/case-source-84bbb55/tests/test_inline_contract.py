import copy
import unittest

from fixtures.inline_contract import PREFIX, REQUIRED, validate_manifest, validate_release_binding, verify_outcome, validate_tool_result


class InlineContractTests(unittest.TestCase):
    def manifest(self):
        return {'delivery_mode':'inline-first','candidate_kind':'frozen','source':{'commit':'a'*40,'tree':'b'*40,'dirty':False},'architectures':{'aarch64':{'rpm_sha256':'c'*64,'nevra':'cosh-ng-1-1.aarch64','payload_sha256':dict.fromkeys(REQUIRED,'d'*64)}}}

    def outcome(self):
        return {'evidence_class':'installed-inline-loopback','identity_verified':True,'scenario':'allow','requests':3,'host_tool_result':True,'tool_results':[{'role':'tool','tool_call_id':'inline-tool-1','content':'INL_TOOL_DONE\n'}],'effect_lines':['INL_EFFECT'],'workers':[],'worker_monitor_complete':True,'remaining_pids':[],'termios_restored':True,'shell_exit':0,'bash_before':{'pid':7,'start':2,'cwd':'/tmp/test'},'bash_after':{'pid':7,'start':2,'cwd':'/tmp/test'},'ps1_before_hex':'616263','ps1_after_hex':'616263','ps1_expected_hex':'616263','fresh_effect_lines':['INL_FRESH'],'physical_prompt_before_fresh':True,'agent_reply_observed':True,'followup_reply_observed':True}

    def test_manifest_accepts_only_explicit_five_payload_inline_input(self):
        validate_manifest(self.manifest(),'aarch64')
        for change in ['mode','worker','missing','dirty','source','arch']:
            value=self.manifest()
            if change=='mode':value.pop('delivery_mode')
            if change=='worker':value['architectures']['aarch64']['payload_sha256'][PREFIX+'cosh-ui-worker']='e'*64
            if change=='missing':value['architectures']['aarch64']['payload_sha256'].pop('/usr/bin/cosh-switch')
            if change=='dirty':value['source']['dirty']=True
            if change=='source':value['source']['tree']='pending'
            if change=='arch':value['architectures']['aarch64']['nevra']='cosh-ng-1-1.x86_64'
            with self.assertRaises(ValueError,msg=change):validate_manifest(value,'aarch64')

    def test_binding_requires_explicit_mode_and_frozen_release_provenance(self):
        value={'delivery_mode':'inline-first','build_profile':'release','build_attestation_sha256':'a'*64}
        validate_release_binding(value)
        for field in value:
            wrong=dict(value);wrong.pop(field)
            with self.assertRaises(ValueError,msg=field):validate_release_binding(wrong)

    def test_loopback_requires_physical_prompt_first_command_followup_and_no_worker(self):
        verify_outcome(self.outcome())
        bad=[('workers',[{'pid':1}]),('worker_monitor_complete',False),('physical_prompt_before_fresh',False),('ps1_after_hex','6162'),('ps1_before_hex','6162'),('fresh_effect_lines',[]),('fresh_effect_lines',['INL_FRESH']*2),('effect_lines',['INL_EFFECT']*2),('agent_reply_observed',False),('followup_reply_observed',False),('requests',2),('remaining_pids',[1]),('bash_after',None),('shell_exit',1),('termios_restored',False),('identity_verified',False),('evidence_class','installed-release-loopback')]
        for field,value in bad:
            wrong=copy.deepcopy(self.outcome());wrong[field]=value
            with self.assertRaises(ValueError,msg=field):verify_outcome(wrong)

    def test_denial_and_cancel_cannot_create_an_effect(self):
        for scenario in ['deny','cancel']:
            value=self.outcome();value.update(scenario=scenario,effect_lines=[],tool_results=[{'role':'tool','tool_call_id':'inline-tool-1','content':'Tool call denied: User '+('denied' if scenario=='deny' else 'cancelled')+' this operation'}]);verify_outcome(value)
            value['effect_lines']=['INL_EFFECT']
            with self.assertRaises(ValueError):verify_outcome(value)

    def test_legacy_fault_scenarios_are_not_inline_passes(self):
        for scenario in ['kill','stall','takeback','exhausted','fallback-small']:
            value=self.outcome();value['scenario']=scenario
            with self.assertRaises(ValueError):verify_outcome(value)

    def test_tool_result_must_be_unique_and_semantically_match_the_decision(self):
        success={'role':'tool','tool_call_id':'inline-tool-1','content':'INL_TOOL_DONE\n'}
        validate_tool_result([success],'allow')
        for wrong in [[success,success],[],[{**success,'content':''}],[{**success,'content':'error'}],[{**success,'tool_call_id':'other'}]]:
            with self.assertRaises(ValueError):validate_tool_result(wrong,'allow')
        for scenario in ['deny','cancel']:
            with self.assertRaises(ValueError):validate_tool_result([success],scenario)
        with self.assertRaises(ValueError):validate_tool_result([{'role':'tool','tool_call_id':'inline-tool-1','content':'Tool call denied: User denied this operation'}],'cancel')

    def test_shift_tab_inside_card_does_not_switch_assistance_or_authorize(self):
        value=self.outcome();value.update(scenario='route-card',effect_lines=[],tool_results=[{'role':'tool','tool_call_id':'inline-tool-1','content':'Tool call denied: User denied this operation'}],card_shift_observed=True,routing_before=True,routing_after=True)
        verify_outcome(value)
        for key,bad in [('card_shift_observed',False),('routing_before',False),('routing_after',False),('effect_lines',['INL_EFFECT'])]:
            wrong=copy.deepcopy(value);wrong[key]=bad
            with self.assertRaises(ValueError,msg=key):verify_outcome(wrong)

    def test_known_host_receipt_needs_exact_command_status_exit_and_output_section(self):
        command="printf '%s\\n' INL_EFFECT >> /owned/effect; printf '%s\\n' INL_TOOL_DONE"
        receipt='ShellCommandCompleted evidence\ncommand: '+command+'\ncwd: /owned\nend_cwd: /owned\nstatus: completed\nexit_code: 0\nduration_ms: 1\noutput_id: terminal-output://owned/cmd-1\nredaction_status: none\nbounded_output_summary:\nINL_TOOL_DONE\n'
        item={'role':'tool','tool_call_id':'inline-tool-1','content':receipt}
        validate_tool_result([item],'allow',command,'/owned')
        for before,after in [('status: completed','status: unknown'),('exit_code: 0','exit_code: 1'),('bounded_output_summary:\nINL_TOOL_DONE\n','bounded_output_summary:\n'),('command: '+command,'command: changed'),('cwd: /owned','cwd: /other')]:
            wrong={**item,'content':receipt.replace(before,after)}
            with self.assertRaises(ValueError,msg=before):validate_tool_result([wrong],'allow',command,'/owned')
        with self.assertRaises(ValueError):validate_tool_result([item],'allow')
