import unittest

from fixtures.inline_identity import validate_payload_bytes, validate_package_inventory
from fixtures.inline_contract import PREFIX, REQUIRED


class InlineIdentityTests(unittest.TestCase):
    def test_native_elf_checks_class_endian_machine_and_switch_script(self):
        for arch,machine in [('aarch64',183),('x86_64',62)]:
            data=bytearray(64);data[:6]=b'\x7fELF\x02\x01';data[18:20]=machine.to_bytes(2,'little')
            validate_payload_bytes(bytes(data),PREFIX+'cosh-shell',arch)
            for pos,value in [(4,1),(5,2),(18,0)]:
                wrong=bytearray(data);wrong[pos]=value
                with self.assertRaises(ValueError):validate_payload_bytes(bytes(wrong),PREFIX+'cosh-shell',arch)
        validate_payload_bytes(b'#!/bin/bash\necho ok\n','/usr/bin/cosh-switch','aarch64')
        with self.assertRaises(ValueError):validate_payload_bytes(b'plain','/usr/bin/cosh-switch','aarch64')
        with self.assertRaises(ValueError):validate_payload_bytes(b'#!/bin/sh','/usr/bin/cosh-cli','aarch64')

    def test_package_inventory_rejects_worker_in_any_package_path(self):
        good=sorted(REQUIRED)
        validate_package_inventory(good)
        for worker in [PREFIX+'cosh-ui-worker','/usr/bin/cosh-ui-worker','/usr/lib/systemd/system/cosh-ui-worker.service']:
            with self.assertRaises(ValueError):validate_package_inventory(good+[worker])
        with self.assertRaises(ValueError):validate_package_inventory(good[:-1])
