from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]
STAGE='/var/lib/cosh-production-accept'
cases=[]


def wait(text, identity=None):
    event={'type':'wait_for','text':text,'timeout_ms':60000}
    if identity:event['id']=identity
    return event


for scenario in ['pending','core-loss','managed-read','ordinary-byte']:
    events=[wait('TB_NATIVE_START_READY','startup-ready')]
    if scenario=='ordinary-byte':
        events += [{'type':'line','text':"saved=$(stty -g); stty -echo -icanon; printf '%s%s\\n' TB_RAW_ READY; dd bs=1 count=1 of=raw-byte 2>/dev/null; stty \"$saved\"; printf '%s%s\\n' TB_RAW_ DONE"},wait('TB_RAW_VERIFIED','ordinary-consumer'),{'type':'bytes','hex':'1d'}]
    else:
        events += [{'type':'line','text':'?? request the controlled takeback operation'},wait('TB_CARD_VERIFIED','approval-card')]
        if scenario=='core-loss':events += [wait('TB_CORE_LOSS_READY','core-lost')]
        if scenario=='managed-read':
            events += [{'type':'key','name':'enter'},wait('TB_READ_VERIFIED','managed-consumer'),{'type':'bytes','hex':b'\x1dTB_OLD_ANSWER\r'.hex()},wait('TB_FOREGROUND_RETURNED','foreground-returned'),{'type':'line','text':'TB_NEW_ANSWER'}]
        else:
            events += [{'type':'bytes','hex':b'printf TB_OLD_PREFIX > old-prefix\x1dprintf TB_OLD_SUFFIX > old-suffix\r'.hex()}]
    events += [wait('TB_NATIVE_RESTORED','native-before-fresh'),{'type':'line','text':"printf '%s\\n' TB_FRESH >> fresh-effect; printf '%s%s\\n' TB_FRESH_ READY"},wait('TB_FRESH_READY','fresh-input')]
    if scenario!='ordinary-byte':events += [{'type':'line','text':'?? takeback must remain native'}]
    events += [{'type':'line','text':"printf '%s%s\\n' TB_STICKY_ OK"},wait('TB_STICKY_OK','native-sticky'),{'type':'wait_quiet','quiet_ms':2000,'timeout_ms':10000},{'type':'line','text':'exit 0'}]
    points=[{'id':e['id'],'trigger_event':e['id'],'layout_sensitive':True,'required_types':['screenshot']} for e in events if e.get('id') not in {None,'startup-ready'}]
    cases.append({'id':'PW-PROD-TAKEBACK-'+scenario.upper()+'-001','title':'Installed public Ctrl+] '+scenario+' input ownership','tags':['installed-rpm','loopback-not-real-provider','public-control-0x1d',scenario],'command':['python3',STAGE+'/tools/fixtures/production_takeback.py','--candidate',STAGE+'/candidate.json','--binding',STAGE+'/binding.json','--timeout-seconds','150','--scenario',scenario],'input':events,'expect':{'status':0,'contains':['TB_RESULT','"status": "PASS"','"cleanup": 0','TB_FRESH_READY'],'not_contains':['invalid approval mode','Traceback (most recent call last)']},'evidence':{'points':points}})
suite={'version':1,'suite':'production-installed-public-takeback','defaults':{'execution':'ci','adapter':'cosh-core','shell':'bash','shell_mode':'isolated','approval_mode':'auto','analysis_mode':'smart','real_provider':False,'terminal_cols':80,'terminal_rows':30,'timeout_ms':180000},'cases':cases}
(ROOT/'specs/shell-e2e-validation/cases/ui-takeback-production-installed.yaml').write_text(json.dumps(suite,indent=2)+'\n')
print('prepared four unexecuted installed public Ctrl+] cases; source/installed evidence remain separate')
