from pathlib import Path
import json
import py_compile
import shutil
import subprocess
import sys
import tempfile

root=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=True,parents=True)
suite='test_inline_consumer_lifecycle.'
mutations=[
    ('fake-foreground','fixtures/inline_support.py',"'foreground_pgrp':after['foreground_pgrp']","'foreground_pgrp':after['pgrp']",suite+'ControlledLifecycleTests.test_actual_final_foreground_is_returned'),
    ('reused-death-proof','fixtures/inline_support.py',"if current['start']!=row['start']:","if False:",suite+'ControlledLifecycleTests.test_reused_pid_after_missing_fd_is_rejected_even_when_zombie'),
    ('swallow-all-os-errors','fixtures/inline_support.py',"if error.errno in {errno.ENOENT,errno.ESRCH} and consumer_retired(row):return None","if True:return None",suite+'ControlledLifecycleTests.test_own_errors_are_not_swallowed_even_if_process_also_exits'),
    ('skip-controlling-device','fixtures/inline_support.py',"if not stat.S_ISCHR(device.st_mode) or not stat.S_ISCHR(current_device.st_mode) or number==0 or (os.major(device.st_rdev),os.minor(device.st_rdev))!=(major,minor) or current_device.st_rdev!=device.st_rdev:","if False:",suite+'ControlledLifecycleTests.test_live_identity_or_device_changes_fail_closed'),
    ('unconditional-ready','fixtures/inline_support.py',"return who is not None and who['foreground_pgrp']==who['pgrp']","return True",suite+'FixtureCompositionTests.test_no_consumer_or_background_cannot_emit_any_new_stage'),
    ('cached-inline-identity','fixtures/inline_fixture.py',"value={key:who[key] for key in ['pid','start','cwd']}","value={key:bash[0][key] for key in ['pid','start','cwd']}",suite+'FixtureCompositionTests.test_current_identity_records_use_only_the_verified_sample'),
    ('cached-native-identity','fixtures/inline_native_fixture.py',"value={key:who[key] for key in ['pid','start','cwd','exe','sha256']}","value={key:bash[key] for key in ['pid','start','cwd','exe','sha256']}",suite+'FixtureCompositionTests.test_current_identity_records_use_only_the_verified_sample'),
]
results=[]
for name,relative,old,new,target in mutations:
    with tempfile.TemporaryDirectory(prefix='inline-lifecycle-mutant-') as temporary:
        clone=Path(temporary)/'tree';shutil.copytree(root,clone,ignore=shutil.ignore_patterns('.git','__pycache__'))
        path=clone/relative;source=path.read_text();assert source.count(old)==1,(name,source.count(old))
        path.write_text(source.replace(old,new));py_compile.compile(str(path),doraise=True)
        result=subprocess.run([sys.executable,'-B','-m','unittest',target,'-v'],cwd=clone/'tests',capture_output=True,text=True,timeout=20)
        (out/(name+'.stdout')).write_text(result.stdout);(out/(name+'.stderr')).write_text(result.stderr)
        detected=result.returncode==1 and 'AssertionError' in result.stderr and 'ERROR:' not in result.stderr
        results.append({'name':name,'compiled':True,'detected_by_assertion':detected,'exit_code':result.returncode,'target':target})
        assert detected,(name,result.stdout,result.stderr)
(out/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
