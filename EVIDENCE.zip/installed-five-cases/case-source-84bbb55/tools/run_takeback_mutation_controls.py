from pathlib import Path
import json
import os
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(sys.argv[1]).resolve()
OUT.mkdir(parents=True,exist_ok=False)
source=(ROOT/'fixtures/takeback_contract.py').read_text()
lines=source.splitlines()
needles={
    'bash-identity':'original Bash PID/start/cwd/TTY changed',
    'caret-color':'original prompt color or editable caret missing',
    'current-prompt':'original PS1 is not on the current cursor line',
    'new-physical-frame':'historical prompt reused as restoration',
    'fresh-order':'new input preceded native prompt restoration',
    'old-packet-replay':'old packet input was executed',
    'fresh-once':'first new native command missing or duplicated',
    'native-sticky':'implicit Agent/UI reentry observed',
    'core-identity':'original Core PID/start changed',
    'core-signal':'verified Core loss was not injected',
    'core-retirement':'Core remained alive or implicitly restarted',
    'foreground-identity':'managed foreground consumer changed',
    'foreground-binding':'foreground read is not the original Bash consumer',
    'native-foreground':'original Bash did not own the TTY foreground before fresh input',
    'ordinary-tty':'ordinary reader was not on the original foreground TTY',
    'ordinary-worker':'ordinary foreground unexpectedly created a UI worker',
    'foreground-answer':'old read input or synthetic foreground PS1 observed',
    'ordinary-control-byte':'ordinary foreground did not receive unchanged 0x1d',
    'tool-owner':'tool response belongs to a different request',
    'owned-cleanup':'owned processes or terminal were not restored',
}
results=[]
for name,needle in needles.items():
    matching=[line for line in lines if needle in line]
    assert len(matching)==1,(name,matching)
    original=matching[0];replacement=original[:len(original)-len(original.lstrip())]+'pass'
    mutated=source.replace(original,replacement,1)
    compile(mutated,name,'exec')
    target=OUT/name;(target/'fixtures').mkdir(parents=True);(target/'tests').mkdir()
    (target/'fixtures/takeback_contract.py').write_text(mutated)
    shutil.copyfile(ROOT/'fixtures/production_contract.py',target/'fixtures/production_contract.py')
    shutil.copyfile(ROOT/'tests/test_takeback_contract.py',target/'tests/test_takeback_contract.py')
    result=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests'],cwd=target,env={**os.environ,'PYTHONPATH':str(target/'fixtures')},capture_output=True,text=True)
    (target/'stdout.txt').write_text(result.stdout);(target/'stderr.txt').write_text(result.stderr)
    assert result.returncode and 'FAIL:' in result.stderr and not any(token in result.stderr for token in ['SyntaxError','ImportError','ModuleNotFoundError']),result.stderr
    results.append({'mutation':name,'language':'Python tool contract; not native product mutation','compiles':True,'test_exit':result.returncode,'failures':[line for line in result.stderr.splitlines() if line.startswith('FAIL:')]})
observation=(ROOT/'fixtures/production_takeback.py').read_text()
observation_mutants={
    'unbounded-tmux-observation':('timeout=min(2,remaining)','timeout=60'),
    'unbounded-tmux-cleanup':('timeout=min(1,remaining)','timeout=60'),
    'forget-transient-worker':("result['workers_after_takeback'].append(record)","pass"),
    'forget-transient-core':("loss['replacement_cores'].append(record)","pass"),
}
for name,(before,after) in observation_mutants.items():
    assert observation.count(before)==1
    mutated=observation.replace(before,after);compile(mutated,name,'exec')
    target=OUT/name;shutil.copytree(ROOT/'fixtures',target/'fixtures');shutil.copytree(ROOT/'runtime/src',target/'runtime/src');(target/'tests').mkdir()
    (target/'fixtures/production_takeback.py').write_text(mutated)
    shutil.copyfile(ROOT/'tests/test_takeback_observation.py',target/'tests/test_takeback_observation.py')
    result=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests'],cwd=target,env={**os.environ,'PYTHONPATH':str(target/'fixtures')},capture_output=True,text=True)
    (target/'stdout.txt').write_text(result.stdout);(target/'stderr.txt').write_text(result.stderr)
    assert result.returncode and 'FAIL:' in result.stderr and not any(token in result.stderr for token in ['SyntaxError','ImportError','ModuleNotFoundError']),result.stderr
    results.append({'mutation':name,'language':'Python observer; synthetic only, no product','compiles':True,'test_exit':result.returncode,'failures':[line for line in result.stderr.splitlines() if line.startswith('FAIL:')]})
(OUT/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'compiled_contract_mutations_caught':len(needles),'compiled_observation_mutations_caught':len(observation_mutants),'native_product_mutations':0}))
