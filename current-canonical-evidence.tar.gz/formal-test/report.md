# cosh-lab test

- Run: `20261013T210105Z-1fd32b3c`
- Status: `PASS`
- Cleanup: `not-applicable`
- Scope: `raw-cli`
- Environment: `20261013T184512Z-5a9038a5`
