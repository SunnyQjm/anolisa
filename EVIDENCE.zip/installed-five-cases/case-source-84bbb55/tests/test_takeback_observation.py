import importlib.util
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'fixtures'))

class TakebackObservationTests(unittest.TestCase):
    def module(self):
        path=ROOT/'fixtures/production_takeback.py'
        self.assertTrue(path.exists(),'installed public takeback fixture is missing')
        spec=importlib.util.spec_from_file_location('production_takeback',path)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        return module

    def test_current_cursor_line_and_color_are_observed(self):
        snapshot={'plain':'old prompt\nowner@host:~$\n','grid':'old prompt\n\x1b[32mowner@host:~$\x1b[0m\n','y':1,'x':14,'cursor_visible':True}
        row=self.module().prompt_observation(snapshot,7000)
        self.assertEqual(row,{'line':'owner@host:~$','x':14,'cursor_visible':True,'first_cell_green':True,'physical_offset':7000})

    def test_history_token_and_later_green_are_not_current_green_prompt(self):
        snapshot={'plain':'owner@host:~$\nforeground read','grid':'\x1b[32mowner@host:~$\n\x1b[31mforeground\x1b[32m read','y':1,'x':15,'cursor_visible':True}
        row=self.module().prompt_observation(snapshot,7000)
        self.assertEqual(row['line'],'foreground read');self.assertFalse(row['first_cell_green'])

    def test_foreground_green_control_requires_first_cell(self):
        module=self.module()
        for line in ['owner\x1b[32m','\x1b[31mowner','\x1b[32m\x1b[0mowner']:
            self.assertFalse(module.first_cell_green(line),line)
        self.assertTrue(module.first_cell_green('\x1b[38;5;2mowner'))

    def test_transient_worker_and_core_reentry_are_latched(self):
        module=self.module();self.assertTrue(hasattr(module,'latch_reentry'),'transient UI/Core observations must survive to the final verdict')
        initial={(10,11)};row={'ack_observed':True,'workers_after_takeback':[],'core_loss':{'pid':30,'start':31,'replacement_cores':[]}}
        module.latch_reentry(row,{(10,11):{'pid':10,'start':11},(20,21):{'pid':20,'start':21}},[{'pid':40,'start':41}],initial)
        module.latch_reentry(row,{},[],initial)
        self.assertEqual(row['workers_after_takeback'],[{'pid':20,'start':21}])
        self.assertEqual(row['core_loss']['replacement_cores'],[{'pid':40,'start':41}])

    def test_tmux_timeout_uses_remaining_observation_budget_and_keeps_finally_evidence(self):
        module=self.module();self.assertTrue(hasattr(module,'TakebackReplay'),'takeback replay calls need a bounded observation deadline')
        import json
        import tempfile
        from unittest.mock import patch
        replay=module.TakebackReplay.__new__(module.TakebackReplay);replay.socket=Path('/owned/tmux.sock');replay.observation_deadline=150
        def blocked(argv,**kwargs):
            self.assertLessEqual(kwargs['timeout'],0.25)
            raise module.subprocess.TimeoutExpired(argv,kwargs['timeout'])
        with tempfile.TemporaryDirectory() as temporary,patch.object(module.time,'monotonic',return_value=149.75),patch.object(module.subprocess,'run',side_effect=blocked):
            with self.assertRaises(module.subprocess.TimeoutExpired):
                try:replay.tmux('capture-pane','-p')
                finally:module.journal_event(Path(temporary),'cleanup_started')
            self.assertEqual(json.loads((Path(temporary)/'events.jsonl').read_text())['event'],'cleanup_started')

    def test_replay_cleanup_subprocesses_have_short_independent_bounds(self):
        module=self.module();self.assertTrue(hasattr(module,'TakebackReplay'),'takeback cleanup must not inherit expired observation budget')
        from unittest.mock import patch
        replay=module.TakebackReplay.__new__(module.TakebackReplay);replay.socket=Path('/owned/tmux.sock');replay.pid=None;replay.closed=False
        def completed(argv,**kwargs):
            self.assertGreater(kwargs['timeout'],0);self.assertLessEqual(kwargs['timeout'],1)
            return module.subprocess.CompletedProcess(argv,1,b'',b'no server')
        with patch.object(module.subprocess,'run',side_effect=completed):replay.close()
        self.assertTrue(replay.closed)

    def test_stage_signal_does_not_advance_terminal_caret(self):
        module=self.module()
        self.assertTrue(hasattr(module,'stage_bytes'),'observer stage signals must preserve the product screen')
        import tempfile
        with tempfile.TemporaryDirectory() as temporary:
            replay=module.TakebackReplay(Path(temporary),80,30,module.time.monotonic()+10)
            try:
                replay.feed('o','\x1b[32mowner@host:~$ \x1b[0m')
                before=replay.snapshot()
                replay.feed('o',module.stage_bytes('TB_NATIVE_RESTORED').decode())
                after=replay.snapshot()
                self.assertEqual(before,after)
            finally:replay.close()

if __name__=='__main__':unittest.main()
