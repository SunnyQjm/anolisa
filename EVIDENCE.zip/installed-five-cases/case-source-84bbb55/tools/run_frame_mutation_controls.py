from pathlib import Path
import json
import os
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1]).resolve()
out.mkdir(parents=True,exist_ok=True)
original=(root/'fixtures/production_worker.py').read_text()
mutations={
 'unicode-quantifier-applied-to-last-byte':("re.search('╰─+╯',frame[actions[-1].end():])", "re.search('╰─+╯'.encode(),frame[actions[-1].end():].encode())"),
 'accept-partial-utf8':("text=data.decode('utf-8')", "text=data.decode('utf-8',errors='replace')"),
 'accept-old-frame-before-new-header':("start=max(text.rfind('╭'),text.rfind('┌'))", "start=0"),
 'ignore-current-focus':("actions[-1][1]==selected", "True"),
}
rows=[]
for name,(before,after) in mutations.items():
    assert original.count(before)==1
    mutated=original.replace(before,after)
    compile(mutated,name,'exec')
    target=out/name
    shutil.copytree(root/'fixtures',target/'fixtures',dirs_exist_ok=True)
    (target/'tests').mkdir(exist_ok=True)
    shutil.copyfile(root/'tests/test_worker_observation.py',target/'tests/test_worker_observation.py')
    shutil.copytree(root/'tests/data',target/'tests/data',dirs_exist_ok=True)
    (target/'fixtures/production_worker.py').write_text(mutated)
    p=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s',str(target/'tests')],cwd=target,env={**os.environ,'PYTHONPATH':str(target)},capture_output=True,text=True)
    (target/'stdout.txt').write_text(p.stdout);(target/'stderr.txt').write_text(p.stderr)
    assert p.returncode and 'FAIL:' in p.stderr and 'SyntaxError' not in p.stderr and 'ImportError' not in p.stderr,p.stderr
    rows.append({'mutation':name,'compiles':True,'test_exit':p.returncode,'failures':[line for line in p.stderr.splitlines() if line.startswith('FAIL:')]})
(out/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
