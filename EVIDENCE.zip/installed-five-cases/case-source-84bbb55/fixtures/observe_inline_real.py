import argparse
from datetime import datetime, timezone
import json
import hashlib
from pathlib import Path
import time

from inline_identity import digest, identity
from inline_contract import PREFIX, require
from inline_fixture import RAW_PS1
from inline_support import TOOL, descendants, process_info, process_start


def observe(args):
    bound=identity(args.candidate,args.binding)
    for relative,key in [('fixtures/observe_inline_real.py','real_observer_sha256'),('fixtures/inline_real_contract.py','real_contract_sha256'),('fixtures/inline_support.py','support_sha256'),('fixtures/inline_fixture.py','fixture_sha256')]:
        require(digest(TOOL/relative)==bound['tool_binding'].get(key),'unfrozen real observer dependency: '+relative)
    target=Path(args.workspace).resolve();output=Path(args.out)
    require(target.is_dir() and not output.exists(),'private workspace must exist and observer output must be new')
    require(not list(target.glob('effect-*.txt')) and not any((target/name).exists() for name in ['real-fresh','ps1-before','ps1-after','observer-stop']),'real workspace contains prior evidence')
    expected_rc="PS1='"+RAW_PS1.decode()+"'\n"
    require(digest(target/'.bashrc')==bound['tool_binding'].get('real_bashrc_sha256')==hashlib.sha256(expected_rc.encode()).hexdigest(),'Root native real-provider bashrc differs from plain original PS1 fixture')
    hosts={};cores={};workers={};error=None;completed=False
    started=datetime.now(timezone.utc).isoformat();deadline=time.monotonic()+args.timeout_seconds
    (target/'observer-ready').write_text('ready\n')
    try:
        while not (target/'observer-stop').exists():
            require(time.monotonic()<deadline,'observer deadline; no production verdict')
            for path in Path('/proc').iterdir():
                if not path.name.isdigit():continue
                host=process_info(int(path.name))
                if not host or host['exe']!=PREFIX+'cosh-shell' or Path(host['cwd']).resolve()!=target:continue
                require(process_start(host['pid'])==host['start'] and digest(path/'exe')==bound['payload_sha256'][PREFIX+'cosh-shell'] and process_start(host['pid'])==host['start'],'Host differs from installed payload')
                hosts[(host['pid'],host['start'])]={**host,'sha256':bound['payload_sha256'][PREFIX+'cosh-shell']}
                for row in descendants(host['pid']):
                    if Path(row['exe']).name=='cosh-ui-worker':workers[(row['pid'],row['start'])]=row
                    if row['exe']==PREFIX+'cosh-core':
                        require(process_start(row['pid'])==row['start'] and digest(Path('/proc')/str(row['pid'])/'exe')==bound['payload_sha256'][PREFIX+'cosh-core'] and process_start(row['pid'])==row['start'],'Core differs from installed payload')
                        cores[(row['pid'],row['start'])]={**row,'sha256':bound['payload_sha256'][PREFIX+'cosh-core']}
            time.sleep(0.01)
        require(hosts and cores and not workers,'Host/Core observation missing or worker activated')
        completed=True
    except BaseException as failure:
        error=failure
    finally:
        def hex_file(name):
            path=target/name
            return path.read_bytes().hex() if path.exists() else None
        result={'evidence_class':'installed-inline-real-provider-observer','delivery_mode':'inline-first','completed':completed,'error':str(error) if error else None,'source':bound['source'],'rpm_sha256':bound['rpm_sha256'],'candidate_sha256':bound['candidate_sha256'],'workspace':str(target),'started_at':started,'finished_at':datetime.now(timezone.utc).isoformat(),'hosts':list(hosts.values()),'cores':list(cores.values()),'workers':list(workers.values()),'effects':{str(p):p.read_text().splitlines() for p in target.glob('effect-*.txt')},'fresh_effect':(target/'real-fresh').read_text().splitlines() if (target/'real-fresh').exists() else [],'ps1_expected_hex':RAW_PS1.hex(),'ps1_before_hex':hex_file('ps1-before'),'ps1_after_hex':hex_file('ps1-after'),'limit':'sampled process observations; no claim about unobserved short-lived workers or physical prompt readiness'}
        output.write_text(json.dumps(result,indent=2)+'\n')
    if error:raise error


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--candidate',required=True);parser.add_argument('--binding',required=True)
    parser.add_argument('--workspace',required=True);parser.add_argument('--out',required=True)
    parser.add_argument('--timeout-seconds',type=int,required=True)
    observe(parser.parse_args())
