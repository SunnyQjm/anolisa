from pathlib import Path
import json
import os
import subprocess
import sys

out=Path(__file__).resolve().parent
root=out.parent.parent/'tool-inline-lifecycle-8028'
case_root=out/'case-source-84bbb55'
received=Path('/Users/quejianming/vscode/cosh-shell-dev/outputs/codex-takeover-20261013/inline-first-release-implementation-20261017/pr-rpm-84db0a6/received')
case_id=sys.argv[1]
assert case_id in {'INL-PROD-ALLOW-001','INL-PROD-DENY-001','INL-PROD-CANCEL-001','INL-PROD-DETAILS-001','INL-PROD-ROUTE-CARD-001'}
argv=['python3.12','-B','-m','cosh_lab','accept','run','--on','20261017T112139Z-2edc4099','--transport','native','--case',str(case_root/'specs/shell-e2e-validation/cases/inline-production-installed.yaml'),'--case-source','canonical','--id',case_id,'--gate','feature-acceptance','--artifact-root','/Users/quejianming/vscode/cosh-shell-dev/outputs/codex-takeover-20261013/ui/issue-8028-inline-first-release/validation/runs','--output','json']
env={k:v for k,v in os.environ.items() if not k.startswith('COSH_E2E_') and not k.startswith('COSH_LAB_')}
env.update(PYTHONPATH=str(root/'runtime/src'),COSH_LAB_TARGET_ROOT=str(case_root),COSH_LAB_INSTALLED_CANDIDATE_JSON=str(received/'candidate.json'),COSH_LAB_INSTALLED_BINDING_JSON=str(Path(sys.argv[2]).resolve()),PYTHONDONTWRITEBYTECODE='1')
with (out/(case_id+'.command.json')).open('x') as stream:stream.write(json.dumps(argv,indent=2)+'\n')
with (out/(case_id+'.stdout')).open('x') as stdout,(out/(case_id+'.stderr')).open('x') as stderr:
    result=subprocess.run(argv,cwd=case_root,env=env,stdout=stdout,stderr=stderr)
try:
    data=json.loads((out/(case_id+'.stdout')).read_text())
    summary={'case_id':case_id,'exit_code':result.returncode,'ok':data.get('ok'),'error':data.get('error'),'run_dir':data.get('meta',{}).get('run_dir')}
except ValueError:
    summary={'case_id':case_id,'exit_code':result.returncode,'invalid_json':True}
(out/(case_id+'.summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
raise SystemExit(result.returncode)
