from pathlib import Path
import json
import signal
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'fixtures'))
from production_worker import journal_event, inject_fault

class DurableEventsTests(unittest.TestCase):
    def test_event_is_fsynced_before_return(self):
        with tempfile.TemporaryDirectory() as temporary, patch('production_worker.os.fsync') as sync:
            output=Path(temporary)
            journal_event(output,'worker',pid=12,start=34)
            row=json.loads((output/'events.jsonl').read_text())
            self.assertEqual((row['event'],row['pid'],row['start']),('worker',12,34))
            sync.assert_called_once()

    def test_signal_success_has_preceding_attempt_and_success(self):
        with tempfile.TemporaryDirectory() as temporary, patch('production_worker.os.kill') as kill:
            output=Path(temporary)
            kill.side_effect=lambda *args:self.assertEqual(json.loads((output/'events.jsonl').read_text())['event'],'signal_attempt')
            fault=inject_fault(output,12,34,signal.SIGKILL,2669)
            rows=[json.loads(line) for line in (output/'events.jsonl').read_text().splitlines()]
            self.assertEqual([row['event'] for row in rows],['signal_attempt','signal_success'])
            self.assertEqual(fault['physical_offset'],2669)
            kill.assert_called_once_with(12,signal.SIGKILL)

    def test_event_survives_ungraceful_process_exit(self):
        with tempfile.TemporaryDirectory() as temporary:
            code="from pathlib import Path;import os;from production_worker import journal_event;journal_event(Path(%r),'before_exit',pid=12);os._exit(137)" % temporary
            result=subprocess.run([sys.executable,'-B','-c',code],env={**__import__('os').environ,'PYTHONPATH':str(Path(__file__).resolve().parents[1]/'fixtures')})
            self.assertEqual(result.returncode,137)
            self.assertEqual(json.loads((Path(temporary)/'events.jsonl').read_text())['event'],'before_exit')

    def test_signal_failure_is_durable_and_propagates(self):
        with tempfile.TemporaryDirectory() as temporary, patch('production_worker.os.kill',side_effect=ProcessLookupError(3,'gone')):
            output=Path(temporary)
            with self.assertRaises(ProcessLookupError):inject_fault(output,12,34,signal.SIGKILL,2669)
            rows=[json.loads(line) for line in (output/'events.jsonl').read_text().splitlines()]
            self.assertEqual([row['event'] for row in rows],['signal_attempt','signal_error'])
            self.assertEqual(rows[-1]['errno'],3)

if __name__=='__main__':unittest.main()
