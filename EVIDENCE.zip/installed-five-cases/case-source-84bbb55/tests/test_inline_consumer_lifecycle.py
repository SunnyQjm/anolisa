import contextlib
import ast
import errno
import hashlib
import io
import os
from pathlib import Path
import stat
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'fixtures'))
import inline_support as support


class ProcBoundary:
    def __init__(self,phase=None,change='gone'):
        self.phase=phase;self.change=change;self.changed=False;self.phase_seen=False
        self.row={'pid':42,'start':7,'sid':42,'pgrp':42,'tty_nr':34817,'foreground_pgrp':42,'state':'S'}
        self.opened=set();self.closed=[];self.next_fd=10;self.stat_count=0;self.cwd_count=0;self.tty_count=0
        self.device=SimpleNamespace(st_mode=stat.S_IFCHR|0o600,st_rdev=os.makedev(136,1))

    def boundary(self,name):
        if name==self.phase and not self.changed:
            self.changed=True;self.phase_seen=True
            if self.change=='permission':raise PermissionError(errno.EACCES,'permission denied')
            if self.change=='bad-fd':raise OSError(errno.EBADF,'bad descriptor')
            if self.change=='parse':raise ValueError('invalid proc stat')
            if self.change=='io':raise OSError(errno.EIO,'read failure')

    def snapshot(self,pid,directory=None):
        self.stat_count+=directory is not None
        self.boundary('initial-stat' if directory is not None and self.stat_count==1 else 'final-stat' if directory is not None else 'classify-stat')
        if self.changed and self.change=='gone':raise FileNotFoundError(errno.ENOENT,'gone')
        row=dict(self.row)
        if self.changed:
            if self.change=='reused':row['start']+=1
            if self.change=='zombie':row['state']='Z'
            if self.change=='session':row['sid']+=1
            if self.change=='group':row['pgrp']+=1
            if self.change=='tty':row['tty_nr']+=1
            if self.change=='background':row['foreground_pgrp']+=1
        return row

    def open(self,path,flags,dir_fd=None):
        self.boundary('directory-open' if dir_fd is None else 'fd-open' if path=='fd/0' else 'exe-open')
        if self.changed and self.change=='gone':raise FileNotFoundError(errno.ENOENT,'gone')
        descriptor=self.next_fd;self.next_fd+=1;self.opened.add(descriptor);return descriptor

    def close(self,descriptor):
        if descriptor not in self.opened:raise AssertionError('unexpected/double close')
        self.opened.remove(descriptor);self.closed.append(descriptor)

    def fstat(self,descriptor):
        self.boundary('fstat');return self.device

    def path_stat(self,path,dir_fd=None):
        self.boundary('path-stat')
        if self.changed and self.change=='gone':raise FileNotFoundError(errno.ENOENT,'gone')
        if self.changed and self.change=='device':return SimpleNamespace(st_mode=self.device.st_mode,st_rdev=os.makedev(136,2))
        return self.device

    def readlink(self,path,dir_fd=None):
        name=('tty-link' if self.tty_count==0 else 'tty-link-after') if path=='fd/0' else 'exe-link' if path=='exe' else 'cwd-before' if self.cwd_count==0 else 'cwd-after'
        if path=='fd/0':self.tty_count+=1
        if path=='cwd':self.cwd_count+=1
        self.boundary(name)
        if self.changed and self.change=='gone':raise FileNotFoundError(errno.ENOENT,'gone')
        return ('/dev/pts/alias' if self.changed and self.change=='path' else '/dev/pts/1') if path=='fd/0' else '/bin/native' if path=='exe' else '/owned'

    def fdopen(self,descriptor,mode):
        self.boundary('exe-hash')
        owner=self
        class Stream(io.BytesIO):
            def close(self):
                if not self.closed:owner.close(descriptor)
                super().close()
        return Stream(b'native bytes')

    @contextlib.contextmanager
    def installed(self):
        with contextlib.ExitStack() as stack:
            for name,method in [('consumer_stat',self.snapshot),('os.open',self.open),('os.close',self.close),('os.fstat',self.fstat),('os.stat',self.path_stat),('os.readlink',self.readlink),('os.fdopen',self.fdopen)]:
                stack.enter_context(patch('inline_support.'+name,method,create=True))
            yield
        if self.opened:raise AssertionError(f'leaked descriptors: {self.opened}')


class ControlledLifecycleTests(unittest.TestCase):
    phases=['directory-open','initial-stat','fd-open','fstat','tty-link','cwd-before','exe-link','exe-open','exe-hash','path-stat','tty-link-after','cwd-after','final-stat']

    def observe(self,probe):
        expected=('/bin/native',hashlib.sha256(b'native bytes').hexdigest())
        with probe.installed():return support.consumer(probe.row,expected_exe=expected)

    def test_each_phase_proven_disappearance_is_no_consumer(self):
        for phase in self.phases:
            with self.subTest(phase=phase):
                probe=ProcBoundary(phase)
                try:actual=self.observe(probe)
                except (TypeError,OSError,ValueError) as error:self.fail(f'{phase}: proven disappearance is no evidence: {error}')
                self.assertTrue(probe.phase_seen,phase)
                self.assertIsNone(actual)

    def test_each_phase_zombie_is_no_consumer(self):
        for phase in self.phases:
            with self.subTest(phase=phase):
                probe=ProcBoundary(phase,'zombie')
                self.assertIsNone(self.observe(probe));self.assertTrue(probe.phase_seen)

    def test_each_phase_observed_pid_reuse_fails_closed(self):
        for phase in self.phases:
            with self.subTest(phase=phase):
                probe=ProcBoundary(phase,'reused')
                with self.assertRaisesRegex(ValueError,'identity'):self.observe(probe)
                self.assertTrue(probe.phase_seen)

    def test_live_identity_or_device_changes_fail_closed(self):
        for change in ['session','group','tty','device','path']:
            with self.subTest(change=change):
                probe=ProcBoundary('path-stat',change)
                with self.assertRaises(ValueError):self.observe(probe)

    def test_live_errors_are_not_classified_as_exit(self):
        for change,error in [('permission',PermissionError),('bad-fd',OSError),('parse',ValueError),('io',OSError)]:
            with self.subTest(change=change):
                probe=ProcBoundary('fstat',change)
                with self.assertRaises(error):self.observe(probe)

    def test_actual_final_foreground_is_returned(self):
        probe=ProcBoundary('final-stat','background');observed=self.observe(probe)
        self.assertEqual(observed['foreground_pgrp'],43);self.assertEqual(observed['pgrp'],42)

    def test_native_sample_has_current_executable_digest_and_cwd(self):
        observed=self.observe(ProcBoundary())
        self.assertEqual(observed['exe'],'/bin/native');self.assertEqual(observed['cwd'],'/owned')
        self.assertEqual(observed['sha256'],hashlib.sha256(b'native bytes').hexdigest())

    def test_own_errors_are_not_swallowed_even_if_process_also_exits(self):
        for error in [OSError(errno.EBADF,'bad fd'),PermissionError(errno.EACCES,'denied'),ValueError('parse')]:
            with self.subTest(error=repr(error)):
                probe=ProcBoundary()
                with probe.installed(),patch.object(support.os,'fstat',side_effect=error),patch.object(support,'consumer_retired',return_value=True) as retired:
                    with self.assertRaises(type(error)):support.consumer(probe.row)
                    retired.assert_not_called()

    def test_missing_live_fd_is_not_process_termination(self):
        probe=ProcBoundary()
        with probe.installed(),patch.object(support.os,'readlink',side_effect=FileNotFoundError(errno.ENOENT,'fd closed')):
            with self.assertRaises(FileNotFoundError):support.consumer(probe.row)

    def test_reused_pid_after_missing_fd_is_rejected_even_when_zombie(self):
        for zombie in [True]:
            probe=ProcBoundary();original=probe.snapshot
            def snapshot(pid,directory=None):
                value=original(pid,directory)
                if directory is None:value={**value,'start':8,'state':'Z' if zombie else 'S'}
                return value
            with probe.installed(),patch.object(support,'consumer_stat',side_effect=snapshot),patch.object(support.os,'readlink',side_effect=FileNotFoundError(errno.ENOENT,'disappeared')):
                with self.assertRaisesRegex(ValueError,'identity'):support.consumer(probe.row)

    def test_failed_death_proof_is_not_absence(self):
        for error in [PermissionError(errno.EACCES,'denied'),ValueError('short stat'),OSError(errno.EIO,'io')]:
            probe=ProcBoundary();original=probe.snapshot
            def snapshot(pid,directory=None):
                if directory is None:raise error
                return original(pid,directory)
            with probe.installed(),patch.object(support,'consumer_stat',side_effect=snapshot),patch.object(support.os,'readlink',side_effect=FileNotFoundError(errno.ENOENT,'disappeared')):
                with self.assertRaises(type(error)):support.consumer(probe.row)


class StrictStatTests(unittest.TestCase):
    def text(self):return '42 (a name with ) parentheses) '+' '.join(['S','1','42','42','34817','42']+['0']*13+['7'])

    def test_strict_stat_parses_kernel_fields_and_closes_stream(self):
        stream=io.StringIO(self.text())
        with patch.object(support.os,'open',return_value=99),patch.object(support.os,'fdopen',return_value=stream):observed=support.consumer_stat(42,10)
        self.assertEqual(observed,{'pid':42,'state':'S','start':7,'sid':42,'pgrp':42,'tty_nr':34817,'foreground_pgrp':42})
        self.assertTrue(stream.closed)

    def test_malformed_or_wrong_pid_stat_never_means_absent(self):
        for text in ['','42 (name) S','43'+self.text()[2:],self.text()[:-1]+'bad']:
            with self.subTest(text=text):
                stream=io.StringIO(text)
                with patch.object(support.os,'open',return_value=99),patch.object(support.os,'fdopen',return_value=stream):
                    with self.assertRaises(ValueError):support.consumer_stat(42,10)
                self.assertTrue(stream.closed)

    def test_fdopen_error_closes_owned_descriptor(self):
        with patch.object(support.os,'open',return_value=99),patch.object(support.os,'fdopen',side_effect=OSError(errno.EBADF,'bad fd')),patch.object(support.os,'close') as close:
            with self.assertRaises(OSError):support.consumer_stat(42,10)
            close.assert_called_once_with(99)


class FixtureCompositionTests(unittest.TestCase):
    def fragments(self,name):
        source=Path(support.TOOL/'fixtures'/name).read_text();tree=ast.parse(source)
        stage=next(node for node in ast.walk(tree) if isinstance(node,ast.FunctionDef) and node.name=='stage')
        record=next(node for node in ast.walk(tree) if isinstance(node,ast.If) and any(isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='value' for t in x.targets) for x in node.body) and 'bash_before' in ast.unparse(node))
        return stage,record

    def environment(self,who):
        events=[]
        return {'who':who,'flags':set(),'current_consumer':support.current_consumer,'output':None,'offset':12,'snapshot':{},'home':None,'routing':lambda home:True,'journal_event':lambda *a,**k:events.append((a,k)),'emit_stage':lambda name:events.append(name),'events':events,'result':{'bash_before':None,'bash_after':None},'bash':[{'pid':999,'start':999,'cwd':'stale'}]}

    def test_no_consumer_or_background_cannot_emit_any_new_stage(self):
        for name in ['inline_fixture.py','inline_native_fixture.py']:
            stage,unused=self.fragments(name)
            for who in [None,{'pgrp':42,'foreground_pgrp':43}]:
                with self.subTest(fixture=name,who=who):
                    env=self.environment(who);exec(compile(ast.Module(body=[stage],type_ignores=[]),name,'exec'),env)
                    for marker in ['startup-ready','details-ready','card-deny-ready','card-shift-ready','exit-ready']:env['stage'](marker)
                    self.assertEqual(env['events'],[]);self.assertEqual(env['flags'],set())

    def test_current_identity_records_use_only_the_verified_sample(self):
        sample={'pid':42,'start':7,'cwd':'/actual','exe':'/bin/native','sha256':'a'*64,'pgrp':42,'foreground_pgrp':42}
        for name in ['inline_fixture.py','inline_native_fixture.py']:
            unused,record=self.fragments(name)
            for who in [None,sample]:
                with self.subTest(fixture=name,who=who):
                    env=self.environment(who)
                    if name=='inline_native_fixture.py':env['bash']={'pid':999,'start':999,'cwd':'/stale','exe':'/wrong','sha256':'f'*64}
                    try:exec(compile(ast.Module(body=[record],type_ignores=[]),name,'exec'),env)
                    except (TypeError,KeyError,ValueError) as error:self.fail(f'sample ownership composition failed: {error}')
                    actual=env['result']['bash_after']
                    if who is None:self.assertIsNone(actual)
                    else:
                        self.assertEqual(actual['pid'],sample['pid']);self.assertEqual(actual['cwd'],sample['cwd'])
                        if name=='inline_native_fixture.py':self.assertEqual(actual['sha256'],sample['sha256']);self.assertEqual(actual['exe'],sample['exe'])


if __name__=='__main__':unittest.main()
