import os
import errno
import hashlib
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time
import json

TOOL=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(TOOL/'runtime/src'))
from cosh_lab.resize_render import Replay

class InlineReplay(Replay):
    def __init__(self, root, cols, rows, observation_deadline):
        self.observation_deadline=observation_deadline
        super().__init__(root,cols,rows)

    def tmux(self, *args):
        remaining=self.observation_deadline-time.monotonic()
        if remaining<=0:raise TimeoutError('inline replay observation deadline elapsed')
        result=subprocess.run(['tmux','-S',str(self.socket),*args],capture_output=True,timeout=min(2,remaining))
        if result.returncode:raise RuntimeError(result.stderr.decode(errors='replace'))
        return result.stdout.decode('utf-8')

    def close(self):
        if self.closed:return
        if hasattr(self,'stream'):self.stream.close()
        deadline=time.monotonic()+5
        def bounded(argv):
            remaining=deadline-time.monotonic()
            if remaining<=0:raise TimeoutError('owned inline replay cleanup deadline elapsed')
            return subprocess.run(argv,capture_output=True,timeout=min(1,remaining))
        bounded(['tmux','-S',str(self.socket),'kill-server'])
        while True:
            probe=bounded(['tmux','-S',str(self.socket),'list-sessions'])
            writer=bounded(['ps','-p',str(self.pid),'-o','stat=']) if self.pid else None
            if probe.returncode and (writer is None or not writer.stdout.strip() or writer.stdout.strip().startswith(b'Z')):
                self.closed=True;return
            time.sleep(0.01)

def stage_bytes(name):
    return ('\x1b]9999;COSH_LAB_STAGE='+name+'\x07').encode()

def emit_stage(name):
    sys.stdout.buffer.write(stage_bytes(name));sys.stdout.buffer.flush()

def first_cell_green(line):
    green=False
    while line.startswith('\x1b['):
        match=re.match(r'\x1b\[([0-9;]*)m',line)
        if not match:return False
        codes=[int(x or 0) for x in match[1].split(';')]
        index=0
        while index<len(codes):
            code=codes[index]
            if code==38 and codes[index+1:index+2]==[5]:
                green=codes[index+2:index+3]==[2];index+=2
            elif code in {0,39} or 30<=code<=37 or 90<=code<=97:
                green=code==32
            index+=1
        line=line[match.end():]
    return bool(line) and green

def prompt_observation(snapshot, physical_offset):
    plain=snapshot['plain'].splitlines();colored=snapshot['grid'].splitlines();row=snapshot['y']
    return {'line':plain[row].rstrip() if row<len(plain) else '', 'x':snapshot['x'],'cursor_visible':snapshot['cursor_visible'],'first_cell_green':first_cell_green(colored[row]) if row<len(colored) else False,'physical_offset':physical_offset}

def consumer_stat(pid, directory=None):
    path=f'/proc/{pid}/stat' if directory is None else 'stat'
    descriptor=os.open(path,os.O_RDONLY|os.O_CLOEXEC,dir_fd=directory)
    try:stream=os.fdopen(descriptor)
    except BaseException:
        os.close(descriptor);raise
    with stream:text=stream.read()
    prefix,tail=text.rsplit(') ',1)
    fields=tail.split()
    if prefix.split('(',1)[0].strip()!=str(pid) or len(fields)<20 or len(fields[0])!=1:raise ValueError('invalid consumer proc stat')
    return {'pid':pid,'state':fields[0],'start':int(fields[19]),'pgrp':int(fields[2]),'sid':int(fields[3]),'tty_nr':int(fields[4]),'foreground_pgrp':int(fields[5])}


def consumer_retired(row):
    try:
        current=consumer_stat(row['pid'])
    except OSError as error:
        if error.errno in {errno.ENOENT,errno.ESRCH}:return True
        raise
    if current['start']!=row['start']:raise ValueError('consumer process identity changed')
    return current['state'] in {'Z','X','x'}


def current_consumer(who):
    return who is not None and who['foreground_pgrp']==who['pgrp']


def consumer(row, expected_exe=None):
    directory=None;descriptor=None;executable=None
    try:
        directory=os.open(f"/proc/{row['pid']}",os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
        before=consumer_stat(row['pid'],directory)
        if before['start']!=row['start']:raise ValueError('consumer process identity changed')
        if before['state'] in {'Z','X','x'}:return None
        keys=['start','sid','pgrp','tty_nr']
        if any(before[key]!=row[key] for key in keys):raise ValueError('consumer process identity changed')
        descriptor=os.open('fd/0',os.O_RDONLY|os.O_NOCTTY|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=directory)
        device=os.fstat(descriptor)
        tty=os.readlink('fd/0',dir_fd=directory)
        cwd=os.readlink('cwd',dir_fd=directory)
        bound={}
        if expected_exe is not None:
            path=os.readlink('exe',dir_fd=directory)
            executable=os.open('exe',os.O_RDONLY|os.O_CLOEXEC,dir_fd=directory)
            stream=os.fdopen(executable,'rb');executable=None
            with stream:actual=hashlib.file_digest(stream,'sha256').hexdigest()
            if (path,actual)!=expected_exe:raise ValueError('consumer executable differs from native binding')
            bound={'exe':path,'sha256':actual}
        current_device=os.stat('fd/0',dir_fd=directory)
        current_tty=os.readlink('fd/0',dir_fd=directory)
        current_cwd=os.readlink('cwd',dir_fd=directory)
        after=consumer_stat(row['pid'],directory)
        if after['start']!=row['start']:raise ValueError('consumer process identity changed')
        if after['state'] in {'Z','X','x'}:return None
        if any(before[key]!=after[key] for key in keys):raise ValueError('consumer process identity changed')
        number=after['tty_nr']&0xffffffff
        major=(number>>8)&0xfff;minor=(number&0xff)|((number>>12)&0xfff00)
        if not stat.S_ISCHR(device.st_mode) or not stat.S_ISCHR(current_device.st_mode) or number==0 or (os.major(device.st_rdev),os.minor(device.st_rdev))!=(major,minor) or current_device.st_rdev!=device.st_rdev:
            raise ValueError('consumer stdin is not its controlling terminal')
        if cwd!=current_cwd:raise ValueError('consumer cwd changed during observation')
        if tty!=current_tty:raise ValueError('consumer terminal path changed during observation')
        return {'pid':row['pid'],'start':after['start'],'tty':tty,'foreground_pgrp':after['foreground_pgrp'],'pgrp':after['pgrp'],'cwd':cwd,**bound}
    except OSError as error:
        if error.errno in {errno.ENOENT,errno.ESRCH} and consumer_retired(row):return None
        raise
    finally:
        for owned in [executable,descriptor,directory]:
            if owned is not None:os.close(owned)

def cleanup_processes(output, owned):
    for pid,record in owned.items():
        if record is None or process_start(pid)!=record['start']:continue
        try:descriptor=os.pidfd_open(pid)
        except ProcessLookupError:continue
        try:
            if process_start(pid)==record['start']:
                signal.pidfd_send_signal(descriptor,signal.SIGKILL)
        except ProcessLookupError:
            pass
        finally:
            os.close(descriptor)
    deadline=time.monotonic()+2
    while time.monotonic()<deadline and any(record and process_start(pid)==record['start'] for pid,record in owned.items()):time.sleep(0.01)
    remaining=[pid for pid,record in owned.items() if record and process_start(pid)==record['start']]
    journal_event(output,'owned_cleanup_checked',remaining_pids=remaining)
    return remaining

def process_info(pid):
    try:
        root=Path('/proc')/str(pid)
        tail=(root/'stat').read_text().rsplit(') ',1)[1].split()
        return {'pid':pid,'start':int(tail[19]),'ppid':int(tail[1]),'pgrp':int(tail[2]),'sid':int(tail[3]),'tty_nr':int(tail[4]),'foreground_pgrp':int(tail[5]),'state':tail[0],'exe':os.readlink(root/'exe'),'cwd':os.readlink(root/'cwd')}
    except (OSError,ValueError,IndexError):
        return None

def process_start(pid):
    try:
        tail=(Path('/proc')/str(pid)/'stat').read_text().rsplit(') ',1)[1].split()
        return int(tail[19])
    except FileNotFoundError:
        return None

def descendants(parent):
    rows=[p for path in Path('/proc').iterdir() if path.name.isdigit() and (p:=process_info(int(path.name)))]
    selected={parent}
    while True:
        expanded=selected|{p['pid'] for p in rows if p['ppid'] in selected}
        if expanded==selected:
            return [p for p in rows if p['pid'] in selected and p['pid']!=parent]
        selected=expanded

def journal_event(output, event, **fields):
    row={'event':event,'monotonic_ns':time.monotonic_ns(),**fields}
    with (output/'events.jsonl').open('a') as stream:
        stream.write(json.dumps(row,sort_keys=True)+'\n')
        stream.flush()
        os.fsync(stream.fileno())


def assistance_enabled(home):
    path=home/'assistance-path'
    if not path.exists():return None
    value=path.read_text()
    return Path(value).is_file() if value.startswith('/') else None
