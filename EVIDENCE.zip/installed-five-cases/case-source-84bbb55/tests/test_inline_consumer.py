import errno
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import signal
import sys
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'fixtures'))
from inline_support import consumer, process_info


@unittest.skipUnless(sys.platform=='linux','requires Linux procfs and PTY sessions')
class ConsumerTests(unittest.TestCase):
    def setUp(self):
        self.reaped=False
        self.pid,self.master=pty.fork()
        if self.pid==0:
            background=os.fork()
            if background==0:
                os.setpgid(0,0);signal.pause();os._exit(0)
            os.setpgid(background,background)
            def stop(unused_signal,unused_frame):
                os.kill(background,signal.SIGKILL);os.waitpid(background,0);os._exit(0)
            signal.signal(signal.SIGTERM,stop)
            print(json.dumps({'foreground_pgrp':os.tcgetpgrp(0),'tty':os.ttyname(0),'background_pid':background}),flush=True)
            signal.pause()
            os._exit(0)
        self.addCleanup(self.stop_child)
        self.assertTrue(select.select([self.master],[],[],3)[0],'child readiness timeout')
        self.actual=json.loads(os.read(self.master,4096).decode().strip())
        self.row=process_info(self.pid)

    def stop_child(self):
        if self.reaped:return
        os.kill(self.pid,signal.SIGTERM)
        os.waitpid(self.pid,0)
        os.close(self.master)
        self.reaped=True

    def test_foreground_from_another_session_matches_in_session_ioctl(self):
        self.assertNotEqual(os.getsid(0),self.row['sid'])
        descriptor=os.open(f'/proc/{self.pid}/fd/0',os.O_RDONLY|os.O_NOCTTY|os.O_NONBLOCK)
        try:
            with self.assertRaises(OSError) as raised:os.tcgetpgrp(descriptor)
            self.assertEqual(raised.exception.errno,errno.ENOTTY)
        finally:os.close(descriptor)
        try:observed=consumer(self.row)
        except OSError as error:self.fail(f'external observer must read actual foreground without ioctl: {error}')
        self.assertEqual(observed['foreground_pgrp'],self.actual['foreground_pgrp'])
        self.assertEqual(observed['tty'],self.actual['tty'])
        self.assertEqual(observed['pgrp'],self.row['pgrp'])

    def test_stale_process_identity_is_rejected(self):
        stale={**self.row,'start':self.row['start']+1}
        with self.assertRaisesRegex(ValueError,'identity'):consumer(stale)

    def test_normal_exit_is_no_consumer_evidence(self):
        self.stop_child()
        try:observed=consumer(self.row)
        except (OSError,ValueError) as error:self.fail(f'proven exit must return no evidence: {error}')
        self.assertIsNone(observed)

    def test_zombie_is_no_consumer_evidence_but_stale_start_still_fails(self):
        os.kill(self.pid,signal.SIGTERM)
        os.waitid(os.P_PID,self.pid,os.WEXITED|os.WNOWAIT)
        try:observed=consumer(self.row)
        except (OSError,ValueError) as error:self.fail(f'proven zombie must return no evidence: {error}')
        self.assertIsNone(observed)
        with self.assertRaisesRegex(ValueError,'identity'):consumer({**self.row,'start':self.row['start']+1})

    def test_native_executable_and_cwd_come_from_the_same_sample(self):
        expected=hashlib.sha256(Path(self.row['exe']).read_bytes()).hexdigest()
        try:observed=consumer(self.row,expected_exe=(self.row['exe'],expected))
        except TypeError as error:self.fail(f'bound native observation must be supported: {error}')
        self.assertEqual(observed['exe'],self.row['exe'])
        self.assertEqual(observed['sha256'],expected)
        self.assertEqual(observed['cwd'],self.row['cwd'])
        with self.assertRaisesRegex(ValueError,'executable'):consumer(self.row,expected_exe=(self.row['exe'],'f'*64))

    def test_background_process_does_not_inherit_a_foreground_verdict(self):
        row=process_info(self.actual['background_pid'])
        observed=consumer(row)
        self.assertEqual(observed['foreground_pgrp'],self.actual['foreground_pgrp'])
        self.assertNotEqual(observed['foreground_pgrp'],observed['pgrp'])

    def test_nonterminal_stdin_is_rejected(self):
        descriptor=os.open('/dev/null',os.O_RDONLY)
        saved=os.dup(0)
        try:
            os.dup2(descriptor,0)
            with self.assertRaisesRegex(ValueError,'terminal'):consumer(process_info(os.getpid()))
        finally:
            os.dup2(saved,0);os.close(saved);os.close(descriptor)


if __name__=='__main__':unittest.main()
