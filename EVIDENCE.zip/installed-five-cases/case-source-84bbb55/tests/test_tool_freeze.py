import hashlib
import json
from pathlib import Path
import re
import unittest

ROOT=Path(__file__).resolve().parents[1]

class ToolFreezeTests(unittest.TestCase):
    def test_old_debug_bytes_preserved(self):
        baseline=json.loads((ROOT/'provenance/DEBUG-BASELINE.json').read_text())
        for row in baseline['preserved_bytes']:
            self.assertEqual(hashlib.sha256((ROOT/row['historical_copy']).read_bytes()).hexdigest(),row['sha256'])

    def test_all_nine_new_cases_have_commands_and_no_debug_environment(self):
        cases=[]
        for path in (ROOT/'historical/worker-and-takeback-ca52/cases').glob('ui-worker-production-*.yaml'):
            cases.extend(json.loads(path.read_text())['cases'])
        self.assertEqual(len(cases),9)
        self.assertEqual(len({case['id'] for case in cases}),9)
        for case in cases:
            self.assertTrue(case['command'])
            self.assertEqual(case['input'][0]['type'],'wait_for')
            self.assertEqual(case['input'][0]['text'],'cosh-osc$')
            self.assertFalse(any(key.startswith('COSH_UI_') for key in case.get('env',{})))
            self.assertNotIn('COSH_UI_',json.dumps(case))
        for case in cases:
            if case['id'] in {'PW-PROD-KILL-001','PW-PROD-STALL-001','PW-PROD-FOCUS-001'}:
                self.assertNotIn('fallback-notice',json.dumps(case))
                selected='Deny' if case['id']=='PW-PROD-FOCUS-001' else 'Allow once'
                rebuilt=next(event for event in case['input'] if event.get('id')=='rebuilt-current-card')
                self.assertEqual(rebuilt['text'],'> [ '+selected+' ]')
                self.assertEqual(rebuilt['occurrence'],2)
                before=case['input'][:case['input'].index(rebuilt)]
                rights=[event for event in before if event.get('type')=='key' and event.get('name')=='right']
                self.assertEqual(len(rights),1 if selected=='Deny' else 0)
                self.assertFalse(any(event.get('type')=='key' and event.get('name')=='enter' for event in before))
        real=next(case for case in cases if case['id']=='PW-PROD-REAL-APPROVAL-001')
        self.assertEqual(real['command'][:2],['env','-i'])

    def test_cases_require_supported_control_auto_and_never_trust(self):
        for path in (ROOT/'historical/worker-and-takeback-ca52/cases').glob('*.yaml'):
            document=json.loads(path.read_text())
            for item in document['cases']:
                case={**document['defaults'],**item}
                self.assertEqual(case['approval_mode'],'auto')
                for key in ['COSH_SHELL_APPROVAL_MODE','COSH_APPROVAL_MODE']:
                    if key in case.get('env',{}):self.assertEqual(case['env'][key],'auto')
                    for argument in case['command']:
                        if argument.startswith(key+'='):self.assertEqual(argument,key+'=auto')
                self.assertIn('invalid approval mode',case['expect'].get('not_contains',[]))

    def test_legacy_runtime_verifier_hashes_remain_pinned(self):
        source=(ROOT/'runtime/src/cosh_lab/cli.py').read_text()
        for name in ['installed_identity.py','production_contract.py']:
            self.assertIn(hashlib.sha256((ROOT/'fixtures'/name).read_bytes()).hexdigest(),source)

if __name__=='__main__':unittest.main()
