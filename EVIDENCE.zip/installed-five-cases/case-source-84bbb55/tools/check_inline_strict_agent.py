import argparse
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[1]


def check(out):
    out.mkdir(parents=True,exist_ok=False)
    runner=ROOT/'runtime/scripts/e2e/cosh-shell-run-case'
    rows=[]
    for event_id in ['provider-response','real-followup']:
        for kind,text,expected in [('echo-only','INL_ACK',False),('actual-agent-row','│ INL_ACK',True)]:
            name=event_id+'-'+kind
            case={'version':1,'suite':'inline-synthetic-strict-agent-control','cases':[{'id':'CONTROL','real_provider':True,'command':['/usr/bin/printf',text+'\n'],'timeout_ms':2000,'input':[{'id':event_id,'type':'wait_for','text':'INL_ACK','timeout_ms':300}], 'evidence':{'points':[{'id':'agent','trigger_event':event_id,'required_types':['screenshot'],'layout_sensitive':False}]}}]}
            case_path=out/(name+'.json');case_path.write_text(json.dumps(case))
            result=subprocess.run(['ruby',str(runner),'--case',str(case_path),'--id','CONTROL','--out',str(out/name),'--quarantine-root',str(out/'quarantine')],capture_output=True,text=True,timeout=10)
            (out/(name+'.stdout')).write_text(result.stdout);(out/(name+'.stderr')).write_text(result.stderr)
            if (result.returncode==0)!=expected:raise RuntimeError('strict Agent control failed: '+name)
            rows.append({'event':event_id,'control':kind,'exit_code':result.returncode,'expected_acceptance':expected,'product_evidence':False})
    source=runner.read_text();guard='if case_config["real_provider"] && ["provider-response", "real-followup"].include?(event["id"])'
    if source.count(guard)!=1:raise RuntimeError('strict guard target changed')
    mutation=out/'echo-accepting-runner.rb';mutation.write_text(source.replace(guard,'if false',1))
    syntax=subprocess.run(['ruby','-c',str(mutation)],capture_output=True,text=True,timeout=10)
    if syntax.returncode:raise RuntimeError('strict guard mutation does not compile')
    case_path=out/'real-followup-echo-only.json'
    result=subprocess.run(['ruby',str(mutation),'--case',str(case_path),'--id','CONTROL','--out',str(out/'mutant'),'--quarantine-root',str(out/'quarantine')],capture_output=True,text=True,timeout=10)
    (out/'mutation.stdout').write_text(result.stdout);(out/'mutation.stderr').write_text(result.stderr)
    if result.returncode:raise RuntimeError('compiled strict guard mutation failed to reproduce echo false success')
    report={'runner_sha256':hashlib.sha256(runner.read_bytes()).hexdigest(),'controls':rows,'compiled_guard_mutation_detected':True,'mutant_echo_accepted':True,'product_tests':0}
    (out/'RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True)
    check(parser.parse_args().out)
