from __future__ import annotations

import hashlib
from pathlib import Path, PurePosixPath
import re
import tarfile
import tempfile


class TransferError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_remote_path(value: str) -> str:
    if any(character in value for character in "\0\r\n\t"):
        raise TransferError("remote path contains control characters")
    path = PurePosixPath(value)
    if not path.is_absolute() or ".." in path.parts or str(path) == "/":
        raise TransferError("remote path must be an absolute contained file path")
    return str(path)


def parse_remote_sha256(stdout: str) -> str:
    lines = [line.strip() for line in stdout.splitlines() if line.strip()]
    value = lines[-1] if lines else ""
    if re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise TransferError("remote SHA-256 output is invalid")
    return value


def create_directory_archive(source: Path, destination: Path) -> None:
    for path in source.rglob("*"):
        if path.is_symlink() or not (path.is_file() or path.is_dir()):
            raise TransferError(
                "directory transfer accepts only regular files and directories"
            )

    def normalize(info: tarfile.TarInfo) -> tarfile.TarInfo:
        info.uid = 0
        info.gid = 0
        info.uname = ""
        info.gname = ""
        info.mtime = 0
        return info

    with tarfile.open(destination, "w") as archive:
        archive.add(source, arcname=".", recursive=True, filter=normalize)


def extract_directory_archive(archive_path: Path, destination: Path) -> None:
    if destination.exists() or destination.is_symlink():
        raise TransferError("directory download destination must not exist")
    staging_root = Path(
        tempfile.mkdtemp(
            prefix=".cosh-lab-directory-",
            dir=destination.parent,
        )
    )
    staging_root.chmod(0o700)
    staging = staging_root / "payload"
    staging.mkdir()
    publish_started = False
    published = False
    try:
        with tarfile.open(archive_path, "r") as archive:
            for member in archive.getmembers():
                path = PurePosixPath(member.name)
                if (
                    path.is_absolute()
                    or ".." in path.parts
                    or member.issym()
                    or member.islnk()
                    or not (member.isfile() or member.isdir())
                ):
                    raise TransferError("directory archive contains unsafe entries")
            archive.extractall(staging)
        publish_started = True
        staging.replace(destination)
        published = True
        staging_root.rmdir()
    except KeyboardInterrupt as error:
        import shutil

        inferred_published = published or (
            publish_started and destination.exists() and not staging.exists()
        )
        shutil.rmtree(staging_root, ignore_errors=True)
        error.publish_started = publish_started
        error.published = inferred_published
        raise
    except (OSError, tarfile.TarError, TransferError) as cause:
        import shutil

        shutil.rmtree(staging_root, ignore_errors=True)
        if published:
            error = TransferError(
                f"directory download published but local staging cleanup failed: {cause}"
            )
            error.publish_started = True
            error.published = True
            raise error from cause
        if publish_started:
            cause.publish_started = True
        raise
