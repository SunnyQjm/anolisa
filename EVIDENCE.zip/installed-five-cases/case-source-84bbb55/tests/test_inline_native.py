import copy
import hashlib
import json
import unittest

from fixtures.inline_native_contract import verify_native, verify_pair as verify_bound_pair, input_protocol_sha256


class InlineNativeTests(unittest.TestCase):
    def result(self, scenario='native-read', baseline=False):
        expected={'native-read':b'?? native read\n','native-read-e':b'?? native read-e\n','native-ps2':b'\n?? native ps2\n','native-heredoc':b'?? native heredoc\n','route-draft':b'INL_DRAFT\n','route-foreground':b'\x1b[Z?? native foreground\n'}
        return {'environment_run_id':'new-root-bound-environment','host_boot_sha256':'e'*64,'mount_namespace':'mnt:[42]','fixture_run_token':('b' if baseline else 'a')*32,'input_protocol_sha256':input_protocol_sha256(),'scenario':scenario,'evidence_class':'native-bash-control' if baseline else 'installed-inline-native','identity_verified':True,'candidate_sha256':'a'*64,'rpm_sha256':'b'*64,'architecture':'aarch64','native_bash_sha256':'c'*64,'native_bash_path':'/usr/bin/bash','native_baseline':baseline,'requests':0,'workers':[],'monitor_complete':True,'shell_exit':0,'remaining_pids':[],'termios_restored':True,'bash_before':{'pid':7,'start':1,'cwd':'/owned','exe':'/usr/bin/bash','sha256':'c'*64},'bash_after':{'pid':7,'start':1,'cwd':'/owned','exe':'/usr/bin/bash','sha256':'c'*64},'ps1_expected_hex':'616263','ps1_before_hex':'616263','ps1_after_hex':'616263','fresh_effect':['INL_FRESH'],'physical_prompt_before_fresh':True,'consumer_observed':True,'consumer_result_hex':expected.get(scenario,b'').hex(),'consumer_expected_hex':expected.get(scenario,b'').hex(),'routing_before':None if baseline else True,'routing_after':None if baseline else (False if scenario=='route-idle' else True),'routing_off_observed':scenario=='route-idle','routing_history_count':1 if scenario=='route-idle' else 0}

    def test_native_consumers_require_exact_bytes_no_agent_and_foreground_witness(self):
        for scenario in ['native-read','native-read-e','native-ps2','native-heredoc','route-draft','route-foreground']:
            good=self.result(scenario);verify_native(good)
            for key,value in [('requests',1),('consumer_observed',False),('consumer_result_hex',''),('physical_prompt_before_fresh',False),('fresh_effect',['INL_FRESH']*2),('ps1_after_hex','6162')]:
                wrong=copy.deepcopy(good);wrong[key]=value
                with self.assertRaises(ValueError,msg=(scenario,key)):verify_native(wrong)

    def test_route_off_stays_off_and_native_history_records_probe_once(self):
        good=self.result('route-idle');verify_native(good)
        for key,value in [('routing_after',True),('routing_before',False),('routing_off_observed',False),('routing_history_count',0),('routing_history_count',2)]:
            wrong=copy.deepcopy(good);wrong[key]=value
            with self.assertRaises(ValueError,msg=key):verify_native(wrong)
        for scenario in ['route-draft','route-foreground']:
            wrong=self.result(scenario);wrong['routing_after']=False
            with self.assertRaises(ValueError):verify_native(wrong)

    def pair(self, a, b, c, d):
        return verify_bound_pair(a,b,c,d,(json.dumps(a,indent=2)+'\n').encode(),(json.dumps(b,indent=2)+'\n').encode())

    def cast(self, result):
        marker='\x1b]9999;COSH_LAB_STAGE=INL_NATIVE_RUN='+result['fixture_run_token']+';scenario='+result['scenario']+';baseline='+str(int(result['native_baseline']))+';protocol='+result['input_protocol_sha256']+'\x07'
        digest=hashlib.sha256((json.dumps(result,indent=2)+'\n').encode()).hexdigest()
        output='INL_NATIVE_RESULT '+json.dumps({'fixture_run_token':result['fixture_run_token'],'input_protocol_sha256':result['input_protocol_sha256'],'scenario':result['scenario'],'native_baseline':result['native_baseline'],'result_sha256':digest,'status':'PASS'})+'\n'
        inputs=["printf '%s' \"$PS1\" > ps1-before; printf '%s' \"${COSH_ASSISTANCE_STATE_FILE-}\" > assistance-path\r","printf ready > consumer-ready; IFS= read -r answer; printf '%s\\n' \"$answer\" > consumer-result\r","?? native read\r","printf '%s' \"$PS1\" > ps1-after; history > routing-history; printf '%s\\n' INL_FRESH >> fresh\r","exit 0\r"]
        return [[0,'o',marker]]+[[i+1,'i',text] for i,text in enumerate(inputs)]+[[len(inputs)+1,'o',output]]

    def test_bash_pair_requires_same_installed_input_same_actual_packets_and_native_binary(self):
        good=self.result();base=self.result(baseline=True)
        self.pair(good,base,self.cast(good),self.cast(base))
        for key,value in [('candidate_sha256','f'*64),('rpm_sha256','f'*64),('architecture','x86_64'),('scenario','native-ps2'),('native_bash_sha256','f'*64),('environment_run_id','different-env'),('host_boot_sha256','f'*64),('mount_namespace','mnt:[43]')]:
            wrong=copy.deepcopy(base);wrong[key]=value
            with self.assertRaises(ValueError,msg=key):self.pair(good,wrong,self.cast(good),self.cast(base))
        wrong=self.cast(base);wrong[-2][2]='different input'
        with self.assertRaises(ValueError):self.pair(good,base,self.cast(good),wrong)
        with self.assertRaises(ValueError):self.pair(good,base,[],[])
        with self.assertRaises(ValueError):self.pair(good,base,self.cast(good),self.cast(good))
        reused=self.result(baseline=True);reused['fixture_run_token']=good['fixture_run_token']
        with self.assertRaises(ValueError):self.pair(good,reused,self.cast(good),self.cast(reused))
        wrong=self.result(baseline=True);wrong['fixture_run_token']='c'*32
        with self.assertRaises(ValueError):self.pair(good,wrong,self.cast(good),self.cast(base))
        a=self.cast(good);b=self.cast(base)
        a[:]=[a[0],[1,'i','a'],a[-1]]
        b[:]=[b[0],[1,'i','a'],b[-1]]
        with self.assertRaises(ValueError):self.pair(good,base,a,b)

    def test_observed_bash_must_be_the_bound_native_binary(self):
        wrong=self.result();wrong['bash_before']['sha256']='f'*64;wrong['bash_after']['sha256']='f'*64
        with self.assertRaises(ValueError):verify_native(wrong)

    def test_pair_provenance_matrix_rejects_missing_duplicate_or_foreign_receipts(self):
        a=self.result();b=self.result(baseline=True)
        for category in ['missing-begin','missing-end','duplicate-begin','duplicate-end','wrong-scenario','wrong-protocol','result-replacement','input-before-begin','input-after-end']:
            left=self.cast(a);right=self.cast(b);changed=copy.deepcopy(a)
            if category=='missing-begin':left=left[1:]
            if category=='missing-end':left=left[:-1]
            if category=='duplicate-begin':left.insert(0,copy.deepcopy(left[0]))
            if category=='duplicate-end':left.append(copy.deepcopy(left[-1]))
            if category=='wrong-scenario':left[0][2]=left[0][2].replace('scenario=native-read','scenario=native-ps2')
            if category=='wrong-protocol':left[0][2]=left[0][2].replace(a['input_protocol_sha256'],'f'*64)
            if category=='result-replacement':changed['unrelated']='replacement'
            if category=='input-before-begin':left[0],left[1]=left[1],left[0]
            if category=='input-after-end':left[-1],left[-2]=left[-2],left[-1]
            with self.subTest(category=category):
                with self.assertRaises(ValueError):self.pair(changed,b,left,right)

    def test_nonvacuous_process_consumer_effect_and_protocol_matrix(self):
        for key,value in [('fixture_run_token',''),('input_protocol_sha256','f'*64),('architecture','unknown'),('consumer_observed',False),('fresh_effect',[]),('fresh_effect',['INL_FRESH']*2),('remaining_pids',[7])]:
            wrong=self.result();wrong[key]=value
            with self.assertRaises(ValueError,msg=key):verify_native(wrong)
        wrong=self.result();wrong['consumer_expected_hex']=wrong['consumer_result_hex']=''
        with self.assertRaises(ValueError):verify_native(wrong)
        for key,value in [('pid',0),('start',0),('exe','/wrong/bash')]:
            wrong=self.result();wrong['bash_before'][key]=wrong['bash_after'][key]=value
            with self.assertRaises(ValueError,msg=key):verify_native(wrong)

    def test_pair_binds_exact_result_file_bytes(self):
        a=self.result();b=self.result(baseline=True)
        with self.assertRaises(ValueError):verify_bound_pair(a,b,self.cast(a),self.cast(b),json.dumps(a).encode(),(json.dumps(b,indent=2)+'\n').encode())
