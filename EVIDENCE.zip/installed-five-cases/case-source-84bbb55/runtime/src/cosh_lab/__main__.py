from cosh_lab.cli import main


raise SystemExit(main())
