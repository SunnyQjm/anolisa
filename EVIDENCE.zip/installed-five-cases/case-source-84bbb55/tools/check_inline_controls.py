import ast
import importlib.util
import io
import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'fixtures'))


def load(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/'tests'/('test_'+name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def check():
    modules=[load(name) for name in ['inline_contract','inline_identity','inline_observation','inline_runtime','inline_native','inline_native_observation','inline_real','inline_catalog']]
    def execute():
        suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(module) for module in modules)
        return unittest.TextTestRunner(stream=io.StringIO()).run(suite)
    positive=execute()
    if not positive.wasSuccessful() or positive.testsRun==0:raise RuntimeError('positive control failed')
    import fixtures.inline_contract as contract
    import inline_fixture as fixture
    import fixtures.inline_native_contract as native
    import fixtures.inline_real_contract as real
    controls=[(contract,'validate_manifest','explicit inline-first delivery mode required'),(contract,'validate_manifest','exactly five inline payloads required; worker forbidden'),(contract,'verify_outcome','complete no-worker monitor required'),(contract,'verify_outcome','raw PS1 changed'),(contract,'verify_outcome','first fresh ordinary command must execute once'),(contract,'verify_outcome','physical Agent replies required'),(contract,'validate_tool_result','one tool result required'),(contract,'validate_tool_result','tool result decision/completion semantics mismatch')]
    controls += [(native,'verify_native',message) for message in [
        'observed Bash differs from bound native binary',
        'nonempty actual Bash PID/start required',
        'actual Bash path differs from bound native path',
        'controlled input protocol differs',
        'actual foreground consumer witness required',
        'native consumer bytes mismatch',
        'current native prompt and one fresh command required',
        'routing boundary changed unexpectedly',
    ]]
    controls += [(native,'verify_pair',message) for message in [
        'paired executions must have distinct nonces',
        'cast begin metadata does not belong to result',
        'cast does not bind these result bytes',
        'actual driver writes differ from controlled native protocol',
        'driver writes must lie between this execution begin and final receipt',
    ]]
    controls += [(real,'verify_real_join',message) for message in [
        'installed real provider required',
        'strict Agent response/followup/recovery points required',
        'effect nonce differs from real request',
        'installed process digest mismatch',
    ]]
    rows=[]
    for module,name,message in controls:
        source=Path(module.__file__).read_text();tree=ast.parse(source);changed=0
        for node in ast.walk(tree):
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='require' and len(node.args)==2 and isinstance(node.args[1],ast.Constant) and node.args[1].value==message:
                node.args[0]=ast.Constant(True);changed+=1
        if changed!=1:raise RuntimeError('control target ambiguous: '+message)
        namespace=dict(module.__dict__)
        exec(compile(ast.fix_missing_locations(tree),'<inline-compiling-control>','exec'),namespace)
        function=getattr(module,name);original=function.__code__
        try:
            function.__code__=namespace[name].__code__
            result=execute()
            detected=bool(result.failures)
            rows.append({'removed_guard':message,'compiled':True,'tests_run':result.testsRun,'detected':detected,'assertion_failures':len(result.failures),'other_errors':len(result.errors)})
            if not detected:raise RuntimeError('undetected control: '+message)
        finally:function.__code__=original
    original=fixture.details_panel_observed.__code__
    try:
        namespace={};exec(compile("def details_panel_observed(plain):\n return '> [ Details ]' in plain\n",'<details-focus-only-control>','exec'),namespace)
        fixture.details_panel_observed.__code__=namespace['details_panel_observed'].__code__
        result=execute();detected=bool(result.failures)
        rows.append({'removed_guard':'details focus-only false success','compiled':True,'tests_run':result.testsRun,'detected':detected,'assertion_failures':len(result.failures),'other_errors':len(result.errors)})
        if not detected:raise RuntimeError('undetected details control')
    finally:fixture.details_panel_observed.__code__=original
    final=execute()
    if not final.wasSuccessful():raise RuntimeError('restoration control failed')
    print(json.dumps({'positive_tests':positive.testsRun,'compiled_controls':rows,'restored_tests':final.testsRun,'product_tests':0},indent=2))


if __name__=='__main__':check()
