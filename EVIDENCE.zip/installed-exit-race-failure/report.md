# cosh-lab accept

- Run: `20261017T133126Z-82e9fdb3`
- Status: `FAIL`
- Cleanup: `not-applicable`
- Execution evidence: `scripted-pty`
- Aggregate gate: `feature-acceptance`
- Environment: `20261017T112139Z-2edc4099`
