"""Cosh development test, debug, and acceptance tooling."""

__version__ = "0.8.0"
