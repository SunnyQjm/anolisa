from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

OUT=Path(__file__).resolve().parent
TOOL=OUT.parent.parent/'tool-inline-lifecycle-8028'
RUNS=Path('/Users/quejianming/vscode/cosh-shell-dev/outputs/codex-takeover-20261013/ui/issue-8028-inline-first-release/validation/runs')
ENVIRONMENT='20261017T112139Z-2edc4099'
scenario=sys.argv[1]
assert scenario in {'deny','cancel','details','route-card'}
case_id='INL-PROD-'+scenario.upper()+'-001'
summary=json.loads((OUT/(case_id+'.summary.json')).read_text())
assert summary['exit_code']==0 and summary['ok'] is True
source=Path(summary['run_dir']);destination=OUT/(scenario+'-evidence');destination.mkdir(exist_ok=False)
environment={k:v for k,v in os.environ.items() if not k.startswith('COSH_LAB_')}
environment.update(PYTHONPATH=str(TOOL/'runtime/src'),COSH_LAB_TARGET_ROOT=str(OUT/'case-source-84bbb55'),PYTHONDONTWRITEBYTECODE='1')
cli=[sys.executable,'-B','-m','cosh_lab']
options=['--run',ENVIRONMENT,'--transport','native','--artifact-root',str(RUNS),'--output','json']


def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def execute(name,arguments):
    argv=cli+arguments
    write(destination/(name+'.command.json'),{'argv':argv,'cwd':str(OUT/'case-source-84bbb55'),'PYTHONPATH':environment['PYTHONPATH']})
    result=subprocess.run(argv,cwd=OUT/'case-source-84bbb55',env=environment,capture_output=True,text=True)
    (destination/(name+'.stdout')).write_text(result.stdout);(destination/(name+'.stderr')).write_text(result.stderr)
    data=json.loads(result.stdout);assert result.returncode==0 and data['ok'] is True,(name,result.returncode,data)
    return data


verified=execute('integrity',['evidence','verify',str(source),'--output','json'])
code='''import json
from pathlib import Path
matches=[]
for p in Path('/var/lib/cosh-production-accept/evidence').iterdir():
 f=p/'result.json'
 if f.exists():
  result=json.loads(f.read_text())
  if result.get('scenario')==SCENARIO and result.get('identity',{}).get('tool_binding',{}).get('new_tool_commit')=='84bbb552ef77805a0f4c56ebee5484d0e0a5309d':matches.append(str(p))
print(json.dumps(matches))
'''.replace('SCENARIO',repr(scenario))
located=execute('locate-guest',['env','exec',*options,'--','python3','-c',code]);matches=json.loads(located['data']['stdout']);assert len(matches)==1,matches
transferred=execute('download-guest',['env','download',*options,'--directory',matches[0],str(destination/'guest')])
result=json.loads((destination/'guest/result.json').read_text())
sys.path.insert(0,str(TOOL/'fixtures'))
from inline_contract import verify_outcome
verify_outcome(result)
binding_path=Path('/Users/quejianming/vscode/cosh-shell-dev/outputs/codex-takeover-20261013/inline-first-release-implementation-20261017/pr-rpm-84db0a6/binding-84bbb55.json')
assert result['identity']['tool_binding']==json.loads(binding_path.read_text())
events=[json.loads(line) for line in (destination/'guest/events.jsonl').read_text().splitlines()]
started=next(row for row in events if row['event']=='fixture_started');owned=next(row['owned'] for row in events if row['event']=='cleanup_started')
identities={row['pid']:row['start'] for row in owned if row is not None}
code='''import json
from pathlib import Path
owned=IDENTITIES
remaining=[]
for pid,start in owned.items():
 try:current=int((Path('/proc')/str(pid)/'stat').read_text().rsplit(') ',1)[1].split()[19])
 except FileNotFoundError:continue
 if current==start:remaining.append(pid)
print(json.dumps({'remaining_owned_pid_start':remaining,'owned_home_exists':Path(HOME_PATH).exists()}))
'''.replace('IDENTITIES',repr(identities)).replace('HOME_PATH',repr(started['owned_home']))
cleanup=execute('cleanup-readback',['env','exec',*options,'--','python3','-c',code]);readback=json.loads(cleanup['data']['stdout']);assert readback=={'remaining_owned_pid_start':[],'owned_home_exists':False},readback
receipt={'case_id':case_id,'scenario':scenario,'canonical_run':str(source),'environment':ENVIRONMENT,'backend':'container/native','architecture':'aarch64','execution':'PASS','integrity':'PASS','frozen_outcome_contract':'PASS','scope':'PR8042 installed Core deterministic HTTP loopback only','real_provider':False,'guest_directory':str(destination/'guest'),'remote_guest_directory':matches[0],'guest_transfer_sha256':transferred['data']['sha256'],'guest_transfer_run':transferred['meta']['run_dir'],'cleanup_readback_run':cleanup['meta']['run_dir'],'cleanup':readback,'binding_sha256':hashlib.sha256(binding_path.read_bytes()).hexdigest(),'raw_guest_outcome_sha256':hashlib.sha256((destination/'guest/result.json').read_bytes()).hexdigest(),'media_semantics':'PENDING_VISUAL_QA','product_rerun':False,'environment_released':False}
write(destination/'RAW-RECEIPT.json',receipt)
write(destination/'GUEST-SHA256.json',{str(p.relative_to(destination/'guest')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (destination/'guest').rglob('*') if p.is_file()})
print(json.dumps(receipt))
