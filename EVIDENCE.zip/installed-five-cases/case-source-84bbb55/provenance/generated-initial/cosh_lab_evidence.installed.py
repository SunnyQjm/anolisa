from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from typing import Any


class EvidenceError(RuntimeError):
    pass


def safe_run_ref(value: Any) -> str | None:
    if isinstance(value, str) and re.fullmatch(
        r"\d{8}T\d{6}Z-[0-9a-f]{8}",
        value,
    ):
        return value
    return None


def last_cast_offset_ms(cast_path: Path) -> int:
    offsets = []
    for line in cast_path.read_text().splitlines()[1:]:
        event = json.loads(line)
        if isinstance(event, list) and event and isinstance(event[0], (int, float)):
            offsets.append(event[0])
    if not offsets:
        raise EvidenceError("cast contains no timed events")
    return max(0, math.ceil(max(offsets) * 1000))


def render_point_screenshots(
    run_dir: Path,
    case_id: str,
    points: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    agg = shutil.which("agg")
    ffmpeg = shutil.which("ffmpeg")
    if agg is None or ffmpeg is None:
        raise EvidenceError("agg and ffmpeg are required for acceptance screenshots")
    cast_path = run_dir / "transcript.cast"
    cast_sha256 = hashlib.sha256(cast_path.read_bytes()).hexdigest()
    last_offset_ms = last_cast_offset_ms(cast_path)
    if any(json.loads(line)[1] == "r" for line in cast_path.read_text().splitlines()[1:] if line):
        from .resize_render import render
        try:
            rows = render(run_dir, case_id, points)
        except (RuntimeError, ValueError, OSError, subprocess.TimeoutExpired) as error:
            raise EvidenceError(str(error)) from error
        _write_visual_index(run_dir, rows)
        return rows
    screenshots = run_dir / "screenshots"
    screenshots.mkdir(exist_ok=True)
    rows = []
    with tempfile.TemporaryDirectory() as temp_dir:
        replay_gif = Path(temp_dir) / "replay.gif"
        if any(point.get("layout_sensitive", False) for point in points):
            replay_render = subprocess.run(
                [
                    agg,
                    "--quiet",
                    "--no-loop",
                    # agg's default fontdue renderer drops whole grid rows
                    # (e.g. box-drawing card borders) at the default font
                    # size; resvg renders them faithfully (issue #1907).
                    "--renderer",
                    "resvg",
                    # agg compresses idle gaps >5s by default, shrinking the
                    # replay timeline below recorded event offsets and making
                    # --select positions unreachable for real-provider cases
                    # (LLM think time). Keep the original timeline.
                    "--idle-time-limit",
                    "3600",
                    str(cast_path),
                    str(replay_gif),
                ],
                text=True,
                capture_output=True,
                check=False,
            )
            if replay_render.returncode != 0:
                raise EvidenceError(
                    replay_render.stderr.strip() or "agg replay render failed"
                )
        for point in points:
            screenshot = screenshots / f"{point['id']}.png"
            gif = Path(temp_dir) / f"{point['id']}.gif"
            requested_offset_ms = max(point["offset_ms"], 0)
            if requested_offset_ms >= last_offset_ms:
                offset_ms = last_offset_ms
                selector = "100%"
            else:
                offset_ms = requested_offset_ms
                selector = f"{offset_ms / 1000:.3f}"
            render = subprocess.run(
                [
                    agg,
                    "--quiet",
                    "--no-loop",
                    "--renderer",
                    "resvg",
                    # Keep the original timeline (see the replay render above).
                    "--idle-time-limit",
                    "3600",
                    "--select",
                    selector,
                    str(cast_path),
                    str(gif),
                ],
                text=True,
                capture_output=True,
                check=False,
            )
            if render.returncode != 0:
                raise EvidenceError(render.stderr.strip() or "agg render failed")
            extract = subprocess.run(
                [
                    ffmpeg,
                    "-loglevel",
                    "error",
                    "-y",
                    "-i",
                    str(gif),
                    "-frames:v",
                    "1",
                    str(screenshot),
                ],
                text=True,
                capture_output=True,
                check=False,
            )
            if extract.returncode != 0:
                raise EvidenceError(
                    extract.stderr.strip() or "ffmpeg frame extraction failed"
                )
            row = {
                "case_id": case_id,
                "acceptance_point_id": point["id"],
                "cast_offset_ms": offset_ms,
                "source_sha256": cast_sha256,
                "screenshot": str(screenshot.relative_to(run_dir)),
                "screenshot_sha256": hashlib.sha256(
                    screenshot.read_bytes()
                ).hexdigest(),
                "layout_sensitive": str(
                    bool(point.get("layout_sensitive", False))
                ).lower(),
                "screen": "",
                "screen_sha256": "",
                "screen_source": "",
            }
            if point.get("layout_sensitive", False):
                screens = run_dir / "screens"
                screens.mkdir(exist_ok=True)
                screen = screens / f"{point['id']}.webm"
                screen_extract = subprocess.run(
                    [
                        ffmpeg,
                        "-loglevel",
                        "error",
                        "-y",
                        "-i",
                        str(replay_gif),
                        "-c:v",
                        "libvpx-vp9",
                        "-pix_fmt",
                        "yuv420p",
                        str(screen),
                    ],
                    text=True,
                    capture_output=True,
                    check=False,
                )
                if screen_extract.returncode != 0:
                    raise EvidenceError(
                        screen_extract.stderr.strip()
                        or "ffmpeg layout frame extraction failed"
                    )
                row["screen"] = str(screen.relative_to(run_dir))
                row["screen_sha256"] = hashlib.sha256(screen.read_bytes()).hexdigest()
                row["screen_source"] = "cast-replay"
            rows.append(row)

    _write_visual_index(run_dir, rows)
    return rows


def _write_visual_index(run_dir, rows):
    index = run_dir / "visual-evidence-index.tsv"
    headers = (
        list(rows[0])
        if rows
        else [
            "case_id",
            "acceptance_point_id",
            "cast_offset_ms",
            "source_sha256",
            "screenshot",
            "screenshot_sha256",
            "layout_sensitive",
            "screen",
            "screen_sha256",
            "screen_source",
        ]
    )
    lines = ["\t".join(headers)]
    lines.extend("\t".join(str(row[header]) for header in headers) for row in rows)
    index.write_text("\n".join(lines) + "\n")


def verify_run(run_dir: Path) -> list[str]:
    errors = []
    required = {
        "run.json",
        "commands.log",
        "result.json",
        "report.md",
        "checksums.sha256",
    }
    missing = sorted(name for name in required if not (run_dir / name).is_file())
    errors.extend(f"missing required artifact: {name}" for name in missing)
    if missing:
        return errors

    manifest = json.loads((run_dir / "run.json").read_text())
    result_document = json.loads((run_dir / "result.json").read_text())
    result_data = result_document.get("data") or {}
    if manifest.get("schema_version") != 1:
        errors.append("run manifest schema_version must be 1")
    capabilities = set(manifest.get("capabilities", []))
    if "environment" in capabilities and not (run_dir / "environment.json").is_file():
        errors.append("missing environment artifact: environment.json")
    if "cleanup" in capabilities and not (run_dir / "cleanup.json").is_file():
        errors.append("missing cleanup artifact: cleanup.json")
    if "pty" in capabilities:
        for name in (
            "transcript.cast",
            "transcript.ansi",
            "transcript.txt",
            "events.jsonl",
        ):
            if not (run_dir / name).is_file():
                errors.append(f"missing PTY artifact: {name}")
    else:
        for name in (
            "transcript.cast",
            "transcript.ansi",
            "transcript.txt",
            "events.jsonl",
        ):
            if (run_dir / name).exists():
                errors.append(f"unexpected PTY artifact without capability: {name}")
    if "acceptance" in capabilities:
        if "pty" not in capabilities:
            errors.append("acceptance capability requires PTY capability")
        if not (run_dir / "visual-evidence-index.tsv").is_file():
            errors.append("missing acceptance artifact: visual-evidence-index.tsv")
        if not (run_dir / "screenshots").is_dir():
            errors.append("missing acceptance screenshots")
        points = result_data.get("points", [])
        if not isinstance(points, list) or not points:
            errors.append("acceptance points are empty")
            points = []
        point_definitions: dict[str, dict[str, Any]] = {}
        point_path = run_dir / "acceptance-points.json"
        if not point_path.is_file():
            errors.append("missing acceptance artifact: acceptance-points.json")
        else:
            try:
                definitions = json.loads(point_path.read_text())
            except json.JSONDecodeError:
                definitions = None
            if not isinstance(definitions, list):
                errors.append("acceptance point definitions are invalid")
            else:
                for definition in definitions:
                    point_id = definition.get("id") if isinstance(definition, dict) else None
                    if not point_id or point_id in point_definitions:
                        errors.append("acceptance point definitions contain invalid ids")
                        continue
                    point_definitions[point_id] = definition
        indexed: dict[str, dict[str, str]] = {}
        index_path = run_dir / "visual-evidence-index.tsv"
        if index_path.is_file():
            lines = index_path.read_text().splitlines()
            if lines:
                headers = lines[0].split("\t")
                for line in lines[1:]:
                    values = line.split("\t")
                    if len(values) == len(headers):
                        row = dict(zip(headers, values))
                        indexed[row.get("acceptance_point_id", "")] = row
        result_ids = [
            point.get("acceptance_point_id")
            for point in points
            if isinstance(point, dict)
        ]
        definition_ids = set(point_definitions)
        index_ids = set(indexed)
        if (
            len(result_ids) != len(set(result_ids))
            or set(result_ids) != definition_ids
            or index_ids != definition_ids
        ):
            errors.append("acceptance point id sets do not match")
        for point in points:
            point_id = point.get("acceptance_point_id")
            row = indexed.get(point_id)
            if row is None:
                errors.append(f"acceptance point is not indexed: {point_id}")
                continue
            definition = point_definitions.get(point_id)
            expected_layout = bool(
                definition and definition.get("layout_sensitive", False)
            )
            actual_layout = row.get("layout_sensitive") == "true"
            if expected_layout != actual_layout:
                errors.append(f"acceptance point layout classification mismatch: {point_id}")
            screenshot = (run_dir / row["screenshot"]).resolve()
            if not screenshot.is_relative_to(run_dir.resolve()):
                errors.append(f"acceptance screenshot escapes run directory: {point_id}")
            elif not screenshot.is_file():
                errors.append(f"acceptance screenshot missing: {point_id}")
            elif not screenshot.read_bytes().startswith(b"\x89PNG\r\n\x1a\n"):
                errors.append(f"acceptance screenshot is not PNG: {point_id}")
            elif (
                row.get("screenshot_sha256")
                != hashlib.sha256(screenshot.read_bytes()).hexdigest()
            ):
                errors.append(f"acceptance screenshot hash mismatch: {point_id}")
            cast_path = run_dir / "transcript.cast"
            if cast_path.is_file():
                source_sha256 = hashlib.sha256(cast_path.read_bytes()).hexdigest()
                if row.get("source_sha256") != source_sha256:
                    errors.append(f"acceptance source hash mismatch: {point_id}")
            if cast_path.is_file() and any(json.loads(line)[1] == "r" for line in cast_path.read_text().splitlines()[1:] if line):
                from .resize_render import validate_provenance
                try:
                    validate_provenance(run_dir, row, manifest)
                except (ValueError, OSError, KeyError, TypeError) as error:
                    errors.append(f"resize replay provenance invalid: {point_id}: {error}")
            if expected_layout:
                screen_value = row.get("screen", "")
                screen = (run_dir / screen_value).resolve() if screen_value else None
                if screen is None or not screen.is_file():
                    errors.append(
                        f"layout-sensitive screen evidence missing: {point_id}"
                    )
                elif (
                    row.get("screen_sha256")
                    != hashlib.sha256(screen.read_bytes()).hexdigest()
                ):
                    errors.append(f"layout-sensitive screen hash mismatch: {point_id}")
                elif not screen.is_relative_to(run_dir.resolve()):
                    errors.append(
                        f"layout-sensitive screen escapes run directory: {point_id}"
                    )
                if row.get("screen_source") not in {"cast-replay", "independent"}:
                    errors.append(
                        f"layout-sensitive screen source is invalid: {point_id}"
                    )
        if result_data.get("quarantine_deleted") is not True:
            errors.append("raw quarantine deletion is not proven")
        quarantine = run_dir.parent / ".quarantine" / run_dir.name
        if quarantine.exists():
            errors.append("raw quarantine still exists")
    else:
        for name in (
            "acceptance-points.json",
            "visual-evidence-index.tsv",
            "screenshots",
            "screens",
        ):
            if (run_dir / name).exists():
                errors.append(
                    f"unexpected acceptance artifact without capability: {name}"
                )
    execution_evidence = result_data.get("execution_evidence")
    if execution_evidence is not None and execution_evidence not in {
        "deterministic",
        "scripted-pty",
        "manual-tty",
        "real-provider",
    }:
        errors.append(f"invalid execution evidence: {execution_evidence}")
    if execution_evidence == "real-provider" and "real-provider" not in capabilities:
        errors.append("real-provider execution evidence lacks capability")
    if "real-provider" in capabilities:
        provider_index = run_dir / "provider-parity-evidence-index.tsv"
        if not provider_index.is_file():
            errors.append(
                "missing real-provider artifact: provider-parity-evidence-index.tsv"
            )
        if result_data.get("execution_evidence") != "real-provider":
            errors.append("real-provider capability does not match execution evidence")
        provider_evidence = result_data.get("provider_evidence")
        if not isinstance(provider_evidence, dict) or not provider_evidence:
            errors.append("real-provider proof chain is missing")
            provider_evidence = {}
        indexed_provider: dict[str, Any] = {}
        if provider_index.is_file():
            lines = provider_index.read_text().splitlines()
            if len(lines) != 2:
                errors.append("provider evidence index must contain one row")
            else:
                headers = lines[0].split("\t")
                values = lines[1].split("\t")
                if len(headers) != len(values) or len(set(headers)) != len(headers):
                    errors.append("provider evidence index schema is invalid")
                else:
                    try:
                        indexed_provider = {
                            key: json.loads(value)
                            for key, value in zip(headers, values)
                        }
                    except json.JSONDecodeError:
                        errors.append("provider evidence index values are invalid")
        if indexed_provider != provider_evidence:
            errors.append("provider evidence index mismatch")
        required_provider_fields = {
            "resolved_provider",
            "model",
            "effective_auth_required",
            "binary_sha256",
            "isolated_build",
            "build_attestation_sha256",
            "argv",
            "adapter_type",
            "auth_source",
            "adapter_version",
            "mock_enabled",
            "request_started_at",
            "first_stream_event_at",
            "request_finished_at",
            "request_count",
            "provider_started_observed",
            "semantic_checkpoint_observed",
            "prompt_recovered",
            "upstream_response_observed",
            "request_nonce_sha256",
            "response_sha256",
            "response_summary",
            "auth_preflight_run_id",
        }
        if required_provider_fields - set(provider_evidence):
            errors.append("real-provider proof fields are incomplete")
        timestamps = (
            provider_evidence.get("request_started_at"),
            provider_evidence.get("first_stream_event_at"),
            provider_evidence.get("request_finished_at"),
        )
        argv = provider_evidence.get("argv")
        if (
            provider_evidence.get("effective_auth_required") is not False
            or not (
                provider_evidence.get("isolated_build") is True
                or (
                    provider_evidence.get("binary_origin") == "installed-rpm"
                    and provider_evidence.get("core_path") == "/usr/libexec/anolisa/cosh-ng/cosh-core"
                    and isinstance(argv, list) and argv and argv[0] == "/usr/libexec/anolisa/cosh-ng/cosh-shell"
                    and re.fullmatch(r"[0-9a-f]{64}", str(provider_evidence.get("installed_manifest_sha256", "")))
                    and re.fullmatch(r"[0-9a-f]{64}", str(provider_evidence.get("rpm_sha256", "")))
                    and provider_evidence.get("payload_sha256", {}).get(argv[0]) == provider_evidence.get("binary_sha256")
                    and re.fullmatch(r"[0-9a-f]{64}", str(provider_evidence.get("payload_sha256", {}).get(provider_evidence.get("core_path"), "")))
                )
            )
            or provider_evidence.get("mock_enabled") is not False
            or provider_evidence.get("provider_started_observed") is not True
            or provider_evidence.get("semantic_checkpoint_observed") is not True
            or provider_evidence.get("prompt_recovered") is not True
            or provider_evidence.get("upstream_response_observed") is not True
            or not isinstance(provider_evidence.get("request_count"), int)
            or provider_evidence.get("request_count", 0) < 1
            or not all(isinstance(value, str) and value for value in timestamps)
            or timestamps != tuple(sorted(timestamps))
            or not isinstance(argv, list)
            or not argv
            or not all(isinstance(item, str) for item in argv)
            or Path(argv[0]).name != "cosh-shell"
            or re.fullmatch(
                r"[0-9a-f]{64}",
                str(provider_evidence.get("binary_sha256", "")),
            )
            is None
            or re.fullmatch(
                r"[0-9a-f]{64}",
                str(provider_evidence.get("build_attestation_sha256", "")),
            )
            is None
            or re.fullmatch(
                r"[0-9a-f]{64}",
                str(provider_evidence.get("request_nonce_sha256", "")),
            )
            is None
            or re.fullmatch(
                r"[0-9a-f]{64}",
                str(provider_evidence.get("response_sha256", "")),
            )
            is None
            or not isinstance(provider_evidence.get("response_summary"), str)
            or not provider_evidence.get("response_summary")
        ):
            errors.append("real-provider proof values are invalid")
        transcript_path = run_dir / "transcript.txt"
        if (
            transcript_path.is_file()
            and provider_evidence.get("response_sha256")
            != hashlib.sha256(transcript_path.read_bytes()).hexdigest()
        ):
            errors.append("provider response hash mismatch")
        environment_ref = manifest.get("environment_ref")
        safe_environment_ref = safe_run_ref(environment_ref)
        environment_manifest_path = (
            run_dir.parent / safe_environment_ref / "run.json"
            if safe_environment_ref is not None
            else None
        )
        if (
            environment_manifest_path is not None
            and environment_manifest_path.is_file()
        ):
            environment_manifest = json.loads(environment_manifest_path.read_text())
            auth_preflight = environment_manifest.get("auth_preflight", {})
            expected_auth = {
                "resolved_provider": provider_evidence.get("resolved_provider"),
                "model": provider_evidence.get("model"),
                "adapter_type": provider_evidence.get("adapter_type"),
                "auth_source": provider_evidence.get("auth_source"),
                "effective_auth_required": provider_evidence.get(
                    "effective_auth_required"
                ),
                "source_run_id": provider_evidence.get("auth_preflight_run_id"),
            }
            if any(
                auth_preflight.get(key) != value
                for key, value in expected_auth.items()
            ):
                errors.append("provider evidence does not match auth preflight")
            auth_run_id = provider_evidence.get("auth_preflight_run_id")
            safe_auth_run_id = safe_run_ref(auth_run_id)
            auth_run_dir = (
                run_dir.parent / safe_auth_run_id
                if safe_auth_run_id is not None
                else None
            )
            if auth_run_dir is None or not (auth_run_dir / "result.json").is_file():
                errors.append("auth preflight evidence run is missing")
            else:
                auth_result = json.loads((auth_run_dir / "result.json").read_text())
                auth_manifest = json.loads((auth_run_dir / "run.json").read_text())
                if (
                    auth_result.get("ok") is not True
                    or auth_manifest.get("operation") != "env-auth-check"
                    or auth_manifest.get("environment_ref") != environment_ref
                ):
                    errors.append("auth preflight evidence run is invalid")
        elif environment_ref == "host":
            errors.append("real-provider proof cannot use the host environment")
        else:
            errors.append("real-provider environment_ref is unsafe")
    elif (run_dir / "provider-parity-evidence-index.tsv").exists():
        errors.append("unexpected real-provider artifact without capability")

    expected: dict[str, str] = {}
    for line in (run_dir / "checksums.sha256").read_text().splitlines():
        digest, separator, relative = line.partition("  ")
        if not separator:
            errors.append(f"invalid checksum line: {line}")
            continue
        expected[relative] = digest
    actual_paths = {
        str(path.relative_to(run_dir)): path
        for path in run_dir.rglob("*")
        if path.is_file() and path.name != "checksums.sha256"
    }
    for relative, path in actual_paths.items():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if expected.get(relative) != digest:
            errors.append(f"checksum mismatch: {relative}")
    for relative in sorted(set(expected) - set(actual_paths)):
        errors.append(f"checksummed artifact missing: {relative}")

    sensitive_patterns = (
        re.compile(rb"Authorization:\s*Bearer\s+(?!\[REDACTED\])[^\s\"']+", re.I),
        re.compile(rb"\b(?:LTAI|AKID)[A-Za-z0-9]{12,}\b"),
        re.compile(rb"\bsk-[A-Za-z0-9]{20,}\b"),
        re.compile(rb"\"AccessKeySecret\"\s*:\s*\"(?!\[REDACTED\])[^\"}]+\""),
    )
    for relative, path in actual_paths.items():
        content = path.read_bytes()
        if any(pattern.search(content) for pattern in sensitive_patterns):
            errors.append(f"sensitive content found: {relative}")
    cleanup_status = manifest.get("cleanup", {}).get("status")
    if cleanup_status not in {
        "cleaned",
        "retained-by-policy",
        "not-applicable",
        "cleanup-failed",
    }:
        errors.append(f"unknown cleanup status: {cleanup_status}")
    if cleanup_status == "cleanup-failed":
        errors.append("cleanup status is cleanup-failed")
    environment_ref = manifest.get("environment_ref")
    if environment_ref not in {None, "host"}:
        safe_environment_ref = safe_run_ref(environment_ref)
        environment_manifest = (
            run_dir.parent / safe_environment_ref / "run.json"
            if safe_environment_ref is not None
            else None
        )
        if environment_manifest is None or not environment_manifest.is_file():
            errors.append(f"environment_ref does not resolve: {environment_ref}")
    return errors


def attach_independent_screen(
    run_dir: Path, point_id: str, source: Path
) -> dict[str, str]:
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", point_id) is None:
        raise EvidenceError("acceptance point id is unsafe")
    if not source.is_file():
        raise EvidenceError(f"screen recording not found: {source}")
    header = source.read_bytes()[:12]
    suffix = source.suffix.lower()
    valid_media = (
        (suffix == ".png" and header.startswith(b"\x89PNG\r\n\x1a\n"))
        or (suffix == ".webm" and header.startswith(b"\x1aE\xdf\xa3"))
        or (suffix in {".mp4", ".mov"} and len(header) >= 8 and header[4:8] == b"ftyp")
    )
    if not valid_media:
        raise EvidenceError("screen evidence content does not match its media extension")
    try:
        source.relative_to(run_dir)
    except ValueError:
        pass
    else:
        raise EvidenceError("independent screen recording must originate outside run dir")
    index = run_dir / "visual-evidence-index.tsv"
    if not index.is_file():
        raise EvidenceError("visual evidence index not found")
    lines = index.read_text().splitlines()
    if not lines:
        raise EvidenceError("visual evidence index is empty")
    headers = lines[0].split("\t")
    if "screen_source" not in headers:
        headers.append("screen_source")
    rows = []
    selected = None
    for line in lines[1:]:
        values = line.split("\t")
        row = dict(zip(lines[0].split("\t"), values))
        if row.get("acceptance_point_id") == point_id:
            if row.get("layout_sensitive") != "true":
                raise EvidenceError(f"acceptance point is not layout-sensitive: {point_id}")
            screens = run_dir / "screens"
            screens.mkdir(exist_ok=True)
            destination = screens / f"{point_id}-independent{suffix}"
            if not destination.resolve().is_relative_to(screens.resolve()):
                raise EvidenceError("screen evidence destination escapes run directory")
            shutil.copy2(source, destination)
            row["screen"] = str(destination.relative_to(run_dir))
            row["screen_sha256"] = hashlib.sha256(destination.read_bytes()).hexdigest()
            row["screen_source"] = "independent"
            selected = row
        rows.append(row)
    if selected is None:
        raise EvidenceError(f"acceptance point not found: {point_id}")
    index.write_text(
        "\n".join(
            ["\t".join(headers)]
            + ["\t".join(row.get(header, "") for header in headers) for row in rows]
        )
        + "\n"
    )
    return selected
