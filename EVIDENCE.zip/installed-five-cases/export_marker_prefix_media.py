from pathlib import Path
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys

TOOL=Path('/Users/quejianming/vscode/cosh-shell-dev/outputs/codex-takeover-20261013/production-worker-20261016/acceptance/tool-inline-lifecycle-8028')
STAGES={'native-original':'startup-ready','native-before-fresh':'fresh-ready','fresh-once':'followup-ready','second-request':'exit-ready'}


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();expected=sys.argv[3]
raw=(source/'transcript.cast').read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
original_hashes={str(p.relative_to(source)):digest(p) for p in source.rglob('*') if p.is_file()}
head=subprocess.check_output(['git','-C',str(TOOL),'rev-parse','HEAD'],text=True).strip()
assert head=='84bbb552ef77805a0f4c56ebee5484d0e0a5309d'
assert not subprocess.check_output(['git','-C',str(TOOL),'status','--porcelain']).strip()
result=json.loads((source/'result.json').read_text());assert result['ok'] is True
case_id=result['data']['case']['id'];parent=json.loads((source/'run.json').read_text())
points={p['id']:p for p in json.loads((source/'acceptance-points.json').read_text())}
out.mkdir(exist_ok=False)
environment={k:v for k,v in os.environ.items() if not k.startswith('COSH_LAB_')}
environment.update(PYTHONPATH=str(TOOL/'runtime/src'),PYTHONDONTWRITEBYTECODE='1')
versions={}
for name in ['agg','ffmpeg','ffprobe']:
    executable=shutil.which(name);assert executable
    argv=[executable,'--version' if name=='agg' else '-version']
    probe=subprocess.run(argv,capture_output=True,text=True,check=True)
    versions[name]={'path':executable,'argv':argv,'version':probe.stdout.splitlines()[0]}
entries=[]
for point_id,stage in STAGES.items():
    marker='\x1b]9999;COSH_LAB_STAGE='+stage+'\x07'
    file_offset=0;output_offset=0;matches=[]
    for index,line in enumerate(raw.splitlines(keepends=True)):
        if index:
            timestamp,kind,payload=json.loads(line)
            if kind=='o' and marker in payload:
                assert payload==marker and line.endswith(b'\n')
                matches.append({'source_event_index':index,'source_timestamp_seconds':timestamp,'source_record_start_byte':file_offset,'source_record_end_byte':file_offset+len(line),'source_output_start_byte':output_offset,'source_output_end_byte':output_offset+len(payload.encode())})
            if kind=='o':output_offset+=len(payload.encode())
        file_offset+=len(line)
    assert len(matches)==1,(point_id,matches)
    anchor=matches[0];prefix=raw[:anchor['source_record_end_byte']]
    directory=out/point_id;directory.mkdir()
    cast=directory/'transcript.cast';cast.write_bytes(prefix)
    assert cast.read_bytes()==raw[:anchor['source_record_end_byte']]
    write(directory/'run.json',{'capabilities':['acceptance'],'repo':parent.get('repo',{}),'artifact_kind':'derived-media-only','parent_run_id':source.name,'execution_performed':False})
    write(directory/'result.json',{'ok':False,'data':{'case':{'id':case_id},'derivation_only':True},'error':{'code':'derived-media-only','message':'This directory is replay media, not a new execution or acceptance verdict.'}})
    point={**points[point_id],'offset_ms':math.ceil(anchor['source_timestamp_seconds']*1000)}
    write(directory/'acceptance-points.json',[point])
    argv=[sys.executable,'-B','-m','cosh_lab','evidence','render',str(directory),'--output','json']
    write(directory/'render-command.json',{'argv':argv,'cwd':str(TOOL),'PYTHONPATH':environment['PYTHONPATH'],'script_sha256':digest(Path(__file__))})
    command=subprocess.run(argv,cwd=TOOL,env=environment,capture_output=True,text=True)
    (directory/'render.stdout').write_text(command.stdout);(directory/'render.stderr').write_text(command.stderr)
    assert command.returncode==0,(point_id,command.stderr,command.stdout)
    rendered=json.loads(command.stdout);assert rendered['ok'] is True
    row=rendered['data']['screenshots'][0]
    assert row['source_sha256']==digest(cast)
    for key in ['screenshot','screen']:assert digest(directory/row[key])==row[key+'_sha256']
    assert json.loads((directory/'result.json').read_text())['ok'] is False
    entry={'point_id':point_id,'stage':stage,'original_cast':str(source/'transcript.cast'),'original_cast_sha256':expected,**anchor,'prefix_cast':str(cast),'prefix_sha256':digest(cast),'literal_original_byte_prefix':True,'events_or_timestamps_rewritten':False,'driver_input_events_fabricated':False,'rendered':row,'render_exit_code':command.returncode,'semantic_status':'PENDING_VISUAL_QA','video_meaning':'context replay of literal original prefix; not an exact-time independent recording','new_execution':False,'new_acceptance_pass':False}
    write(directory/'DERIVATION.json',entry);entries.append(entry)
assert {str(p.relative_to(source)):digest(p) for p in source.rglob('*') if p.is_file()}==original_hashes
receipt={'artifact_kind':'derived-media-only','source_run':str(source),'original_artifacts_unchanged':True,'source_cast_sha256':expected,'script':str(Path(__file__).resolve()),'script_sha256':digest(Path(__file__)),'tool_commit':head,'renderer_source_sha256':{name:digest(TOOL/'runtime/src/cosh_lab'/name) for name in ['evidence.py','resize_render.py','cli.py']},'versions':versions,'invocation':sys.argv,'points':entries,'original_approval_card_retained':str(source/'screenshots/approval-card.png'),'original_execution_status':'PASS','original_integrity_status':'PASS','original_point_semantics':'see separate MEDIA-BOUNDARY-ANALYSIS.json; original images are not overwritten','new_execution':False,'new_acceptance_pass':False}
write(out/'EXPORT-RECEIPT.json',receipt)
write(out/'EVIDENCE-SHA256.json',{str(p.relative_to(out)):digest(p) for p in out.rglob('*') if p.is_file() and p.name!='EVIDENCE-SHA256.json'})
print(json.dumps({'out':str(out),'points':len(entries),'script_sha256':receipt['script_sha256'],'original_artifacts_unchanged':True}))
