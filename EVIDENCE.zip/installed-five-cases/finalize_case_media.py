from pathlib import Path
import csv
import hashlib
import json
import sys

out=Path(__file__).resolve().parent;scenario=sys.argv[1];card_source=sys.argv[2]
assert scenario in {'deny','cancel','details','route-card'} and card_source in {'original','derived'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,value:p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
evidence=out/(scenario+'-evidence');raw=json.loads((evidence/'RAW-RECEIPT.json').read_text());source=Path(raw['canonical_run']);parent_cast=(source/'transcript.cast').read_bytes()
original={r['acceptance_point_id']:r for r in csv.DictReader((source/'visual-evidence-index.tsv').open(),delimiter='\t')}
derived=out/(scenario+'-derived-marker-media');export=json.loads((derived/'EXPORT-RECEIPT.json').read_text());mapping=export['canonical_stage_mapping'];selected=[]
for entry in export['points']:
    point=entry['point_id'];assert entry['stage']==mapping[point]
    directory=derived/point;prefix=Path(entry['prefix_cast']);assert prefix.read_bytes()==parent_cast[:entry['source_record_end_byte']]
    row=entry['rendered']
    for key in ['screenshot','screen']:assert sha(directory/row[key])==row[key+'_sha256']
    selected.append({'canonical_point_id':point,'canonical_stage':mapping[point],'selected_evidence':'literal-original-marker-prefix','screenshot':str(directory/row['screenshot']),'context_video':str(directory/row['screen']),'source_record_end_byte':entry['source_record_end_byte'],'source_event_index':entry['source_event_index'],'original_cast_sha256':entry['original_cast_sha256'],'prefix_sha256':entry['prefix_sha256'],'original_screenshot_preserved':str(source/original[point]['screenshot']),'visual_qa':'PASS','visual_qa_method':'acceptance owner inspected actual PNG with view_image','new_execution':False})
if card_source=='derived':
    directory=out/(scenario+'-derived-card-media');entry=json.loads((directory/'EXPORT-RECEIPT.json').read_text());assert (directory/'transcript.cast').read_bytes()==parent_cast[:entry['source_record_end_byte']]
    row=entry['rendered'];selected.append({'canonical_point_id':'approval-card','canonical_wait_text':entry['canonical_wait_text'],'selected_evidence':'literal-original-complete-card-prefix','screenshot':str(directory/row['screenshot']),'context_video':str(directory/row['screen']),'source_record_end_byte':entry['source_record_end_byte'],'prefix_sha256':entry['prefix_sha256'],'original_screenshot_preserved':str(source/original['approval-card']['screenshot']),'original_card_semantics':'superseded by precise complete-card evidence; original image retained','visual_qa':'PASS','visual_observation':'complete actual initial card with Allow once selected before subsequent state repaint','new_execution':False})
else:
    row=original['approval-card']
    for key in ['screenshot','screen']:assert sha(source/row[key])==row[key+'_sha256']
    selected.append({'canonical_point_id':'approval-card','selected_evidence':'original-cast-replay','screenshot':str(source/row['screenshot']),'context_video':str(source/row['screen']),'visual_qa':'PASS','visual_observation':'complete actual initial card with Allow once selected','new_execution':False})
assert {row['canonical_point_id'] for row in selected}==set(original)
write(evidence/'SELECTED-MEDIA-INDEX.json',{'case_id':raw['case_id'],'canonical_run':str(source),'canonical_file':export['canonical'],'canonical_sha256':export['canonical_sha256'],'canonical_stage_mapping':mapping,'points':selected,'selected_point_count':len(selected),'original_execution':'PASS','original_integrity':'PASS','original_assets_preserved':True,'video_claim':'context replay of original source prefix; not exact-time independent recording','root_independent_review':'PENDING','new_execution':False,'new_functional_pass':False})
write(evidence/'CASE-RECEIPT.json',{**raw,'media_semantics':'all canonical points mapped and visually checked','selected_media_index':str(evidence/'SELECTED-MEDIA-INDEX.json'),'selected_point_count':len(selected),'selected_media_sha256':sha(evidence/'SELECTED-MEDIA-INDEX.json'),'marker_export_script_sha256':export['script_sha256'],'root_independent_review':'PENDING'})
write(evidence/'EVIDENCE-SHA256.json',{str(p.relative_to(evidence)):sha(p) for p in evidence.rglob('*') if p.is_file() and p.name!='EVIDENCE-SHA256.json'})
print(json.dumps({'case_id':raw['case_id'],'run':source.name,'selected_points':len(selected),'guest_transfer_sha256':raw['guest_transfer_sha256'],'case_receipt':str(evidence/'CASE-RECEIPT.json')}))
