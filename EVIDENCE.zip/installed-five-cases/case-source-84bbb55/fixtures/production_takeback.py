import argparse
import codecs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile
import termios
import threading
import time

from installed_identity import digest, identity
from production_contract import PREFIX, WORKER, production_environment, require
from production_worker import descendants, frame_ready, journal_event, process_info, process_start, worker_record
from takeback_contract import PROMPT, SCENARIOS, validate_prompt, verify_takeback

TOOL=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(TOOL/'runtime/src'))
from cosh_lab.resize_render import Replay


class TakebackReplay(Replay):
    def __init__(self, root, cols, rows, observation_deadline):
        self.observation_deadline=observation_deadline
        super().__init__(root,cols,rows)

    def tmux(self, *args):
        remaining=self.observation_deadline-time.monotonic()
        if remaining<=0:raise TimeoutError('takeback replay observation deadline elapsed')
        result=subprocess.run(['tmux','-S',str(self.socket),*args],capture_output=True,timeout=min(2,remaining))
        if result.returncode:raise RuntimeError(result.stderr.decode(errors='replace'))
        return result.stdout.decode('utf-8')

    def close(self):
        if self.closed:return
        if hasattr(self,'stream'):self.stream.close()
        deadline=time.monotonic()+5
        def bounded(argv):
            remaining=deadline-time.monotonic()
            if remaining<=0:raise TimeoutError('owned takeback replay cleanup deadline elapsed')
            return subprocess.run(argv,capture_output=True,timeout=min(1,remaining))
        bounded(['tmux','-S',str(self.socket),'kill-server'])
        while True:
            probe=bounded(['tmux','-S',str(self.socket),'list-sessions'])
            writer=bounded(['ps','-p',str(self.pid),'-o','stat=']) if self.pid else None
            if probe.returncode and (writer is None or not writer.stdout.strip() or writer.stdout.strip().startswith(b'Z')):
                self.closed=True;return
            time.sleep(0.01)


def stage_bytes(name):
    return ('\x1b]9999;COSH_LAB_STAGE='+name+'\x07').encode()


def emit_stage(name):
    sys.stdout.buffer.write(stage_bytes(name));sys.stdout.buffer.flush()


def first_cell_green(line):
    green=False
    while line.startswith('\x1b['):
        match=re.match(r'\x1b\[([0-9;]*)m',line)
        if not match:return False
        codes=[int(x or 0) for x in match[1].split(';')]
        index=0
        while index<len(codes):
            code=codes[index]
            if code==38 and codes[index+1:index+2]==[5]:
                green=codes[index+2:index+3]==[2];index+=2
            elif code in {0,39} or 30<=code<=37 or 90<=code<=97:
                green=code==32
            index+=1
        line=line[match.end():]
    return bool(line) and green


def prompt_observation(snapshot, physical_offset):
    plain=snapshot['plain'].splitlines();colored=snapshot['grid'].splitlines();row=snapshot['y']
    return {'line':plain[row].rstrip() if row<len(plain) else '', 'x':snapshot['x'],'cursor_visible':snapshot['cursor_visible'],'first_cell_green':first_cell_green(colored[row]) if row<len(colored) else False,'physical_offset':physical_offset}


def consumer(row):
    path=f"/proc/{row['pid']}/fd/0"
    descriptor=os.open(path,os.O_RDONLY|os.O_NOCTTY|os.O_NONBLOCK)
    try:
        return {'pid':row['pid'],'start':row['start'],'tty':os.readlink(path),'foreground_pgrp':os.tcgetpgrp(descriptor),'pgrp':row['pgrp']}
    finally:
        os.close(descriptor)


def lines(path):
    return path.read_text().splitlines() if path.exists() else []


def ack_observed(home):
    logs=home/'.copilot-shell/logs'
    return logs.is_dir() and any(b'terminal input returned to native consumer' in path.read_bytes() for path in logs.rglob('*.log') if path.is_file())


def core_loss(output, row, expected):
    require(digest(f"/proc/{row['pid']}/exe")==expected,'Core ELF mismatch before fault')
    descriptor=os.pidfd_open(row['pid'])
    try:
        require(process_start(row['pid'])==row['start'],'Core PID was reused')
        journal_event(output,'core_signal_attempt',pid=row['pid'],start=row['start'],signal='SIGKILL')
        try:
            signal.pidfd_send_signal(descriptor,signal.SIGKILL)
        except OSError as error:
            journal_event(output,'core_signal_error',pid=row['pid'],start=row['start'],errno=error.errno)
            raise
        journal_event(output,'core_signal_success',pid=row['pid'],start=row['start'])
    finally:
        os.close(descriptor)
    return {'pid':row['pid'],'start':row['start'],'signal':'SIGKILL','signal_success':True,'old_absent':False,'replacement_cores':[]}


def cleanup_processes(output, owned):
    for pid,record in owned.items():
        if record is None or process_start(pid)!=record['start']:continue
        try:descriptor=os.pidfd_open(pid)
        except ProcessLookupError:continue
        try:
            if process_start(pid)==record['start']:
                signal.pidfd_send_signal(descriptor,signal.SIGKILL)
        except ProcessLookupError:
            pass
        finally:
            os.close(descriptor)
    deadline=time.monotonic()+2
    while time.monotonic()<deadline and any(record and process_start(pid)==record['start'] for pid,record in owned.items()):time.sleep(0.01)
    remaining=[pid for pid,record in owned.items() if record and process_start(pid)==record['start']]
    journal_event(output,'owned_cleanup_checked',remaining_pids=remaining)
    return remaining



def latch_reentry(result, workers, cores, initial_workers):
    if result['ack_observed']:
        recorded={(r['pid'],r['start']) for r in result['workers_after_takeback']}
        for key,record in workers.items():
            if key not in initial_workers and key not in recorded:
                result['workers_after_takeback'].append(record)
    loss=result['core_loss']
    if loss:
        recorded={(r['pid'],r['start']) for r in loss['replacement_cores']}
        for record in cores:
            key=(record['pid'],record['start'])
            if key!=(loss['pid'],loss['start']) and key not in recorded:loss['replacement_cores'].append(record)


def run(options):
    bound=identity(options.candidate,options.binding)
    for relative,key in [('fixtures/production_takeback.py','takeback_fixture_sha256'),('fixtures/takeback_contract.py','takeback_contract_sha256'),('fixtures/production_worker.py','fixture_sha256'),('runtime/src/cosh_lab/resize_render.py','takeback_replay_sha256')]:
        require(digest(TOOL/relative)==bound['tool_binding'].get(key),'unbound takeback dependency: '+relative)
    require(shutil.which('tmux') is not None,'existing tmux replay prerequisite is unavailable')
    output=Path(options.out)/f'takeback-{options.scenario}-{os.getpid()}';output.mkdir(parents=True,exist_ok=False)
    journal_event(output,'fixture_started',pid=os.getpid(),scenario=options.scenario,identity=bound)
    outer_termios=termios.tcgetattr(0);requests=[];owned={};workers={};initial_workers=set();flags=set();error=None
    result={'scenario':options.scenario,'evidence_class':'installed-release-loopback-takeback','identity_verified':True,'identity':bound,'original_prompt':None,'restored_prompt':None,'native_restored_ns':None,'fresh_observed_ns':None,'cutover_observed_ns':None,'answer_observed_ns':None,'bash_before':None,'bash_after':None,'consumer_before':None,'consumer_after':None,'foreground_prompt_drawn':False,'native_consumer':None,'core_loss':None,'core_before':[],'core_after':[],'ack_observed':False,'workers_after_takeback':[],'workers_at_sticky':[],'replay_cleaned':False}
    with tempfile.TemporaryDirectory(prefix='cosh-takeback-') as temporary:
        home=Path(temporary);effect=home/'effect.txt';physical=output/'physical-output.bin'
        (home/'.bashrc').write_text("PS1='\\[\\e[32m\\]owner@host:\\w$\\[\\e[0m\\] '\n")
        command=f"printf '%s\\n' PW_EFFECT >> {shlex.quote(str(effect))}"
        if options.scenario=='managed-read':command=f"printf ready > {home}/read-started; IFS= read -r answer; printf '%s\\n' \"$answer\" > {home}/read-answer; "+command
        journal_event(output,'owned_home',path=str(home),inode=home.stat().st_ino)
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*unused):pass
            def do_POST(self):
                body=json.loads(self.rfile.read(int(self.headers['Content-Length'])));requests.append(body)
                (output/'requests.json').write_text(json.dumps(requests,indent=2)+'\n')
                if len(requests)==1:
                    delta={'tool_calls':[{'index':0,'id':'takeback-tool-1','type':'function','function':{'name':'shell','arguments':json.dumps({'command':command})}}]};finish='tool_calls'
                else:delta={'content':'TB_MODEL_DONE'};finish='stop'
                chunks=[{'choices':[{'index':0,'delta':delta}]},{'choices':[{'index':0,'delta':{},'finish_reason':finish}]}]
                payload=(''.join('data: '+json.dumps(chunk)+'\n\n' for chunk in chunks)+'data: [DONE]\n\n').encode()
                self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload);self.wfile.flush()
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
        server_thread=threading.Thread(target=server.serve_forever,daemon=True);server_thread.start()
        environment=production_environment(os.environ,home)
        for key in ['COSH_SHELL_ISOLATED','COSH_SHELL_INTEGRATION']:environment.pop(key,None)
        environment.update(OPENAI_BASE_URL=f'http://127.0.0.1:{server.server_port}/v1',OPENAI_API_KEY='canonical-loopback-only',COSH_AI_PROVIDER='takeback-loopback',COSH_MODEL='takeback-loopback',COSH_LOG='debug',COSH_TELEMETRY_DISABLED_PATH=str(home/'telemetry_disabled'))
        (home/'telemetry_disabled').touch()
        deadline=time.monotonic()+options.timeout_seconds
        replay_root=output/'replay';replay_root.mkdir();replay=TakebackReplay(replay_root,80,30,deadline)
        child=subprocess.Popen(['/usr/bin/script','-q','-e','-f','-E','never','-O',str(physical),'-c','exec '+shlex.join([PREFIX+'cosh-shell','raw','cosh-core'])],cwd=home,env=environment)
        owned[child.pid]=process_info(child.pid);offset=0;decoder=codecs.getincrementaldecoder('utf-8')();last_snapshot=0
        try:
            while child.poll() is None:
                require(time.monotonic()<deadline,'takeback observation deadline elapsed')
                rows=descendants(child.pid)
                for row in rows:owned[row['pid']]=row
                host=next((r for r in rows if r['exe']==PREFIX+'cosh-shell'),None)
                bash=next((r for r in rows if host and r['ppid']==host['pid'] and Path(r['exe']).name=='bash'),None)
                if bash:
                    result['bash_after']={**{k:bash[k] for k in ['pid','start','cwd','pgrp']},'tty':os.readlink(f"/proc/{bash['pid']}/fd/0")}
                    if result['bash_before'] is None:result['bash_before']=result['bash_after']
                for row in rows:
                    if host and row['exe']==WORKER and (row['pid'],row['start']) not in workers:
                        record=worker_record(row,host['pid'],bound['payload_sha256'][WORKER]);workers[(row['pid'],row['start'])]=record;journal_event(output,'worker_verified',**record)
                data=physical.read_bytes() if physical.exists() else b''
                if len(data)>offset:
                    replay.feed('o',decoder.decode(data[offset:]));offset=len(data)
                    journal_event(output,'physical_growth',physical_offset=offset)
                acknowledged=ack_observed(home)
                if acknowledged and not result['ack_observed']:
                    result['ack_observed']=True;result['cutover_observed_ns']=time.monotonic_ns();journal_event(output,'ownership_ack_observed')
                if (home/'read-answer').exists() and result['answer_observed_ns'] is None:result['answer_observed_ns']=time.monotonic_ns()
                if time.monotonic()-last_snapshot>0.1:
                    snapshot=replay.snapshot();observation=prompt_observation(snapshot,offset);last_snapshot=time.monotonic()
                    try:validate_prompt(observation);native=True
                    except ValueError:native=False
                    if native and result['bash_before'] is not None and result['original_prompt'] is None:
                        result['original_prompt']=observation;journal_event(output,'original_prompt',snapshot=snapshot,observation=observation);emit_stage('TB_NATIVE_START_READY')
                    return_expected=acknowledged and (options.scenario!='managed-read' or (home/'read-answer').exists())
                    if options.scenario=='ordinary-byte':return_expected=(home/'raw-byte').exists() and (home/'raw-byte').read_bytes()==b'\x1d'
                    if native and return_expected and result['restored_prompt'] is None:
                        require(bash is not None,'original native Bash missing before fresh input');result['native_consumer']=consumer(bash)
                        require(result['native_consumer']['tty']==result['bash_before']['tty'] and result['native_consumer']['foreground_pgrp']==result['bash_before']['pgrp'],'original native Bash does not own the TTY foreground')
                        result['restored_prompt']=observation;result['native_restored_ns']=time.monotonic_ns();journal_event(output,'native_prompt_restored_before_fresh',snapshot=snapshot,observation=observation);emit_stage('TB_NATIVE_RESTORED')
                    if options.scenario=='managed-read' and acknowledged and 'foreground-returned' not in flags:
                        require(bash is not None,'original managed Bash missing');result['consumer_after']=consumer(bash);result['foreground_prompt_drawn']=observation['line']==PROMPT.rstrip()
                        require(not (home/'read-answer').exists(),'old read answer arrived before fresh input');flags.add('foreground-returned');journal_event(output,'foreground_returned',consumer=result['consumer_after'],snapshot=snapshot);emit_stage('TB_FOREGROUND_RETURNED')
                if frame_ready(data,'Allow once') and 'card' not in flags:
                    require(bool(workers) and result['original_prompt'] is not None,'installed card or original native prompt not verified');flags.add('card');initial_workers=set(workers);emit_stage('TB_CARD_VERIFIED')
                    result['core_before']=[{k:r[k] for k in ['pid','start','exe']} for r in rows if r['exe']==PREFIX+'cosh-core']
                    if options.scenario=='core-loss':
                        cores=[r for r in rows if r['exe']==PREFIX+'cosh-core'];require(len(cores)==1,'one actual Core required');result['core_loss']=core_loss(output,cores[0],bound['payload_sha256'][PREFIX+'cosh-core'])
                loss=result['core_loss']
                if loss and process_start(loss['pid'])!=loss['start'] and not loss['old_absent']:
                    loss['old_absent']=True;journal_event(output,'core_absent',pid=loss['pid'],start=loss['start']);emit_stage('TB_CORE_LOSS_READY')
                if options.scenario=='managed-read' and (home/'read-started').exists() and 'read' not in flags:
                    require(bash is not None,'actual managed Bash missing');result['consumer_before']=consumer(bash);flags.add('read');journal_event(output,'managed_read_started',consumer=result['consumer_before']);emit_stage('TB_READ_VERIFIED')
                if options.scenario=='ordinary-byte' and b'TB_RAW_READY' in data and 'raw' not in flags:
                    raw=next((r for r in rows if Path(r['exe']).name=='dd'),None)
                    if raw:
                        result['consumer_before']=consumer(raw);require(result['consumer_before']['foreground_pgrp']==raw['pgrp'],'ordinary raw reader is not foreground');flags.add('raw');journal_event(output,'ordinary_foreground_verified',consumer=result['consumer_before']);emit_stage('TB_RAW_VERIFIED')
                if (home/'fresh-effect').exists() and result['fresh_observed_ns'] is None:
                    result['fresh_observed_ns']=time.monotonic_ns();journal_event(output,'fresh_effect_observed',lines=lines(home/'fresh-effect'))
                if b'TB_STICKY_OK' in data:
                    result['workers_at_sticky']=[r for r in rows if r['exe']==WORKER]
                    result['core_after']=[{k:r[k] for k in ['pid','start','exe']} for r in rows if r['exe']==PREFIX+'cosh-core']
                latch_reentry(result,workers,[r for r in rows if r['exe']==PREFIX+'cosh-core'],initial_workers)
                time.sleep(0.01)
        except BaseException as caught:
            error=caught;journal_event(output,'fixture_error',error_type=type(caught).__name__,message=str(caught))
        finally:
            journal_event(output,'cleanup_started',owned=list(owned.values()))
            shutdown=threading.Thread(target=server.shutdown,daemon=True);shutdown.start();shutdown.join(timeout=2);server.server_close()
            if child.poll() is None:child.terminate()
            try:child.wait(timeout=2)
            except subprocess.TimeoutExpired:child.kill();child.wait(timeout=2)
            result['remaining_pids']=cleanup_processes(output,owned)
            try:replay.close();result['replay_cleaned']=replay.closed
            except BaseException as caught:
                if error is None:error=caught
                journal_event(output,'replay_cleanup_error',error_type=type(caught).__name__,message=str(caught))
            result.update(shell_exit=child.returncode,termios_restored=termios.tcgetattr(0)==outer_termios,requests=len(requests),fresh_lines=lines(home/'fresh-effect'),effect_lines=lines(effect),answer_lines=lines(home/'read-answer'),old_prefix_exists=(home/'old-prefix').exists(),old_suffix_exists=(home/'old-suffix').exists(),raw_byte_hex=(home/'raw-byte').read_bytes().hex() if (home/'raw-byte').exists() else None)
            result['tool_results']=[{'tool_call_id':m.get('tool_call_id'),'content':m.get('content','')} for m in requests[1].get('messages',[]) if m.get('role')=='tool'] if len(requests)>1 else []
            result['implicit_agent_reentry']=len(requests)>(0 if options.scenario=='ordinary-byte' else 1 if options.scenario=='core-loss' else 2)
            result['workers']=list(workers.values());result['provider_shutdown_complete']=not shutdown.is_alive();result['error']=str(error) if error else None
            (output/'result.json').write_text(json.dumps(result,indent=2)+'\n');journal_event(output,'cleanup_finished',remaining_pids=result['remaining_pids'],replay_cleaned=result['replay_cleaned'])
        if error:raise error
        require(result['provider_shutdown_complete'],'loopback server did not stop')
        verify_takeback(result)
        print('TB_RESULT '+json.dumps({'status':'PASS','scenario':options.scenario,'cleanup':0,'real_provider':False}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--candidate',required=True);parser.add_argument('--binding',required=True);parser.add_argument('--scenario',choices=sorted(SCENARIOS),required=True);parser.add_argument('--out',default='/var/lib/cosh-production-accept/evidence');parser.add_argument('--timeout-seconds',type=int,default=180)
    run(parser.parse_args())
