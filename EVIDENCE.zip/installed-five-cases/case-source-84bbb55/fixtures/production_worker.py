import argparse
import fcntl
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import shlex
import signal
import struct
import subprocess
import tempfile
import termios
import threading
import time

from installed_identity import digest, identity
from production_contract import PREFIX, WORKER, SCENARIOS, production_environment, validate_worker, verify_outcome


def process_info(pid):
    try:
        root=Path('/proc')/str(pid)
        tail=(root/'stat').read_text().rsplit(') ',1)[1].split()
        return {'pid':pid,'start':int(tail[19]),'ppid':int(tail[1]),'pgrp':int(tail[2]),'sid':int(tail[3]),'state':tail[0],'exe':os.readlink(root/'exe'),'cwd':os.readlink(root/'cwd')}
    except (OSError,ValueError,IndexError):
        return None


def process_start(pid):
    try:
        tail=(Path('/proc')/str(pid)/'stat').read_text().rsplit(') ',1)[1].split()
        return int(tail[19])
    except FileNotFoundError:
        return None


def descendants(parent):
    rows=[p for path in Path('/proc').iterdir() if path.name.isdigit() and (p:=process_info(int(path.name)))]
    selected={parent}
    while True:
        expanded=selected|{p['pid'] for p in rows if p['ppid'] in selected}
        if expanded==selected:
            return [p for p in rows if p['pid'] in selected and p['pid']!=parent]
        selected=expanded


def geometry(pid):
    try:
        fd=os.open(f'/proc/{pid}/fd/0',os.O_RDONLY|os.O_NOCTTY)
        try:
            rows,cols,_,_=struct.unpack('HHHH',fcntl.ioctl(fd,termios.TIOCGWINSZ,bytes(8)))
            return [rows,cols]
        finally:
            os.close(fd)
    except OSError:
        return None


def frame_ready(data, selected):
    try:
        text=data.decode('utf-8')
    except UnicodeDecodeError:
        return False
    start=max(text.rfind('╭'),text.rfind('┌'))
    if start<0:return False
    frame=text[start:]
    actions=list(re.finditer(r'> \[ (Allow once|Deny|Details) \]',frame))
    return bool(actions) and actions[-1][1]==selected and re.search('╰─+╯',frame[actions[-1].end():]) is not None


def worker_record(row, host, expected):
    root=Path('/proc')/str(row['pid'])
    record={**row,'sha256':digest(root/'exe'),'fd':{p.name:os.readlink(p) for p in (root/'fd').iterdir()},'environment_keys':sorted(x.split(b'=',1)[0].decode() for x in (root/'environ').read_bytes().split(b'\0') if x)}
    validate_worker(record,host,expected)
    return record


def journal_event(output, event, **fields):
    row={'event':event,'monotonic_ns':time.monotonic_ns(),**fields}
    with (output/'events.jsonl').open('a') as stream:
        stream.write(json.dumps(row,sort_keys=True)+'\n')
        stream.flush()
        os.fsync(stream.fileno())


def inject_fault(output, pid, start, sig, physical_offset):
    fault={'pid':pid,'start':start,'signal':sig.name,'observed_complete_frame':True,'physical_offset':physical_offset,'generation_claim':'physical PID/start retirement only; descendant IPC and late-generation authority require separate evidence'}
    journal_event(output,'signal_attempt',**fault)
    try:
        os.kill(pid,sig)
    except OSError as error:
        journal_event(output,'signal_error',errno=error.errno,**fault)
        raise
    journal_event(output,'signal_success',**fault)
    return fault


def run(options):
    bound=identity(options.candidate,options.binding)
    binding=bound['tool_binding']
    if digest(__file__)!=binding['fixture_sha256']:
        raise ValueError('production fixture differs from frozen binding')
    output=Path(options.out)/f'{options.scenario}-{os.getpid()}'
    output.mkdir(parents=True,exist_ok=False)
    journal_event(output,'fixture_started',pid=os.getpid(),fixture_sha256=digest(__file__),scenario=options.scenario)
    outer_termios=termios.tcgetattr(0)
    requests=[];workers={};owned={};faults=[];recoveries=[];bash_before=None;bash_after=None;host=None;resize=False;exhausted_fallback=False;last_fault_absent=False
    with tempfile.TemporaryDirectory(prefix='cosh-production-worker-') as temporary:
        home=Path(temporary);effect=home/'effect.txt';physical=output/'physical-output.bin'
        journal_event(output,'owned_home',path=str(home),inode=home.stat().st_ino)
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*unused):
                pass

            def do_POST(self):
                body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                index=len(requests);requests.append(body)
                if index==0:
                    arguments=json.dumps({'command':f"printf '%s\\n' PW_EFFECT >> {shlex.quote(str(effect))}"})
                    chunks=[{'choices':[{'index':0,'delta':{'tool_calls':[{'index':0,'id':'production-tool-1','type':'function','function':{'name':'shell','arguments':arguments}}]}}]},{'choices':[{'index':0,'delta':{},'finish_reason':'tool_calls'}]}]
                else:
                    chunks=[{'choices':[{'index':0,'delta':{'content':'PW_MODEL_DONE'}}]},{'choices':[{'index':0,'delta':{},'finish_reason':'stop'}]}]
                payload=(''.join('data: '+json.dumps(chunk)+'\n\n' for chunk in chunks)+'data: [DONE]\n\n').encode()
                self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Content-Length',str(len(payload)));self.send_header('Connection','close');self.end_headers();self.wfile.write(payload);self.wfile.flush()
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        environment=production_environment(os.environ,home)
        environment.update({'OPENAI_BASE_URL':f'http://127.0.0.1:{server.server_port}/v1','OPENAI_API_KEY':'canonical-loopback-only','COSH_AI_PROVIDER':'production-worker-loopback','COSH_MODEL':'production-worker-loopback','COSH_TELEMETRY_DISABLED_PATH':str(home/'telemetry_disabled')})
        (home/'telemetry_disabled').touch()
        command=[PREFIX+'cosh-shell','raw','cosh-core']
        wrapper=['/usr/bin/script','-q','-e','-f','-E','never','-O',str(physical),'-c','exec '+shlex.join(command)]
        child=subprocess.Popen(wrapper,cwd=home,env=environment)
        owned[child.pid]=process_info(child.pid)
        deadline=time.monotonic()+options.timeout_seconds
        observed_size=-1
        retired=set()
        try:
            while child.poll() is None:
                if time.monotonic()>=deadline:
                    raise RuntimeError('fixture observation deadline elapsed; not an SLO verdict')
                rows=descendants(child.pid)
                for row in rows:
                    owned[row['pid']]=row
                    if row['exe']==PREFIX+'cosh-shell':host=row['pid']
                    if row['exe']==WORKER and host:
                        key=(row['pid'],row['start'])
                        if key not in workers:
                            workers[key]=worker_record(row,host,bound['payload_sha256'][WORKER])
                            journal_event(output,'worker_verified',**workers[key])
                    if host and row['ppid']==host and Path(row['exe']).name=='bash':
                        current={k:row[k] for k in ['pid','start','cwd']}
                        if bash_before is None:bash_before=current
                        bash_after=current
                data=physical.read_bytes() if physical.exists() else b''
                if len(data)!=observed_size:
                    journal_event(output,'physical_growth',physical_offset=len(data),sha256=hashlib.sha256(data).hexdigest(),allow_ready=frame_ready(data,'Allow once'),deny_ready=frame_ready(data,'Deny'))
                    observed_size=len(data)
                if host and geometry(host)==geometry(os.getpid())==[20,47]:resize=True
                selected='Deny' if options.scenario=='focus' else 'Allow once'
                if faults and len(recoveries)<len(faults):
                    fault=faults[-1]
                    old_absent=process_start(fault['pid'])!=fault['start']
                    if old_absent and (fault['pid'],fault['start']) not in retired:
                        journal_event(output,'old_process_absent',pid=fault['pid'],start=fault['start'],physical_offset=len(data))
                        retired.add((fault['pid'],fault['start']))
                    if old_absent and frame_ready(data[fault['physical_offset']:],selected):
                        for (pid,start),record in workers.items():
                            live=process_info(pid)
                            if pid!=fault['pid'] and live and live['start']==start and live['exe']==WORKER:
                                recoveries.append({'fault_pid':fault['pid'],'fault_start':fault['start'],'pid':pid,'start':start,'old_process_absent':True,'physical_frame_end':len(data),'selected':selected})
                                journal_event(output,'recovery_observed',**recoveries[-1]);break
                limit=3 if options.scenario=='exhausted' else 1
                if options.scenario in ['kill','stall','focus','exhausted'] and len(faults)<limit and len(faults)==len(recoveries) and frame_ready(data,selected):
                    for (pid,start),record in workers.items():
                        live=process_info(pid)
                        if live and live['start']==start and live['exe']==WORKER:
                            sig=signal.SIGSTOP if options.scenario=='stall' else signal.SIGKILL
                            faults.append(inject_fault(output,pid,start,sig,len(data)));break
                if options.scenario=='exhausted' and len(faults)==3 and b'The approval display above is no longer current' in data:
                    if not any(row['exe']==WORKER for row in rows) and process_start(faults[-1]['pid'])!=faults[-1]['start'] and not effect.exists():
                        exhausted_fallback=True;last_fault_absent=True
                time.sleep(0.01)
        except BaseException as error:
            journal_event(output,'fixture_error',error_type=type(error).__name__,message=str(error),faults=faults,recoveries=recoveries,physical_offset=physical.stat().st_size if physical.exists() else 0)
            raise
        finally:
            journal_event(output,'cleanup_started',owned=list(owned.values()),faults=faults,recoveries=recoveries)
            server.shutdown();server.server_close();thread.join(timeout=2)
            if child.poll() is None:child.terminate()
            try:child.wait(timeout=2)
            except subprocess.TimeoutExpired:child.kill();child.wait(timeout=2)
            for pid,row in owned.items():
                live=process_info(pid)
                if row and live and live['start']==row['start']:
                    try:os.kill(pid,signal.SIGKILL)
                    except ProcessLookupError:pass
            until=time.monotonic()+2
            while time.monotonic()<until and any(row and process_start(pid)==row['start'] for pid,row in owned.items()):time.sleep(0.01)
            journal_event(output,'cleanup_finished',remaining_pids=[pid for pid,row in owned.items() if row and process_start(pid)==row['start']],effect_current_exists=effect.exists(),requests=len(requests))
        data=physical.read_bytes() if physical.exists() else b''
        result={'evidence_class':'installed-release-loopback','real_provider':False,'identity_verified':True,'identity':bound,'scenario':options.scenario,'workers':list(workers.values()),'effect_lines':effect.read_text().splitlines() if effect.exists() else [],'host_tool_result':len(requests)>=2 and any(x.get('role')=='tool' for x in requests[1].get('messages',[])),'requests':len(requests),'remaining_pids':[pid for pid,row in owned.items() if row and process_start(pid)==row['start']],'termios_restored':termios.tcgetattr(0)==outer_termios,'bash_before':bash_before,'bash_after':bash_after,'shell_exit':child.returncode,'faults':faults,'recoveries':recoveries,'exhausted_fallback_observed':exhausted_fallback,'last_fault_process_absent':last_fault_absent,'old_generation_authority':'not established by physical process retirement; separate late-IPC witness required','resize_observed':resize,'history_tokens_observed':all(x in data for x in [b'PW_LEFT_SENTINEL',b'PW_RIGHT_SENTINEL',b'PW_HISTORY_READY']) if options.scenario=='resize' else True,'environment_keys':sorted(environment),'debug_environment_keys':[], 'visual_history_review':'required separately; transcript token presence is not screen preservation'}
        (output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        (output/'requests.json').write_text(json.dumps(requests,indent=2)+'\n')
        verify_outcome(result)
        print('PW_RESULT '+json.dumps({'scenario':options.scenario,'effect':len(result['effect_lines']),'workers':len(workers),'faults':len(faults),'rebuilds':len(recoveries),'cleanup':len(result['remaining_pids']),'status':'PASS','evidence_class':result['evidence_class']}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--candidate',required=True)
    parser.add_argument('--binding',required=True)
    parser.add_argument('--scenario',choices=sorted(SCENARIOS),required=True)
    parser.add_argument('--out',default='/var/lib/cosh-production-accept/evidence')
    parser.add_argument('--timeout-seconds',type=int,default=180)
    run(parser.parse_args())
