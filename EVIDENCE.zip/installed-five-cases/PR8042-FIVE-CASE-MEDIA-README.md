# PR8042 ARM source/media evidence

Scope: installed Core deterministic HTTP loopback only. Source 84db0a65; tool 84bbb552; RPM 635f2db6. No real-provider, final dual-architecture or default-enable acceptance.

| Case | Actual run | Outcome | Selected media points |
| --- | --- | --- | --- |
| INL-PROD-ALLOW-001 | 20261017T134912Z-2cced2ab | PASS | 5 |
| INL-PROD-DENY-001 | 20261017T135822Z-6d0dfaee | PASS | 5 |
| INL-PROD-CANCEL-001 | 20261017T140152Z-30eb42c9 | PASS | 5 |
| INL-PROD-DETAILS-001 | 20261017T140248Z-66424e62 | PASS | 6 |
| INL-PROD-ROUTE-CARD-001 | 20261017T140348Z-8e8142c7 | PASS | 7 |

All 28 selected PNG and context-WebM pairs have hashes and per-point visual QA in PR8042-FIVE-CASE-MEDIA-INDEX.json. Original media remains intact; exact stage/complete-card source prefixes are separate derived artifacts, not new product executions.

Original e5f34a7 and 411bf26 observer failures, tool RED/GREEN and mutation evidence, original media issues and v1 anchor correction remain preserved.

All five guest results/events/physical logs were downloaded with verified directory transfer hashes. Same Bash and PS1, exact effect/fresh counts, actual Core tool results, two Agent replies, terminal restoration and owned-process cleanup were checked. The existing environment remains owned by Root and was not released.

Root independently accepted ALLOW. Four later cases await Root independent final review and PR asset publication. Release/default enable remains No-Go.
