import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from fixtures.inline_real_contract import verify_real_join


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--provider',required=True);parser.add_argument('--observer',required=True)
    args=parser.parse_args()
    case=ROOT/'specs/shell-e2e-validation/cases/inline-production-real.yaml'
    a=json.loads(Path(args.provider).read_text());b=json.loads(Path(args.observer).read_text())
    verify_real_join(a,b,hashlib.sha256(case.read_bytes()).hexdigest())
    print(json.dumps({'functional_real_provider_join':'PASS','candidate_sha256':b['candidate_sha256'],'rpm_sha256':b['rpm_sha256'],'input_artifact_sha256':{'provider':hashlib.sha256(Path(args.provider).read_bytes()).hexdigest(),'observer':hashlib.sha256(Path(args.observer).read_bytes()).hexdigest(),'canonical':hashlib.sha256(case.read_bytes()).hexdigest()},'original_U02':'not established','physical_prompt_and_native_consumers':'separate canonical evidence required','no_worker_activation':'source audit and process tracing additionally required'}))


if __name__=='__main__':main()
