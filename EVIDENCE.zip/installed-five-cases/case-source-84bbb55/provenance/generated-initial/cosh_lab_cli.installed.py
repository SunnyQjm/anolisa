from __future__ import annotations

import argparse
import copy
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any, Sequence

from cosh_lab import __version__
from cosh_lab.artifacts import RunArtifacts, refresh_checksums, write_json
from cosh_lab.backends import (
    BackendError,
    bridge_environment,
    prepare_private_auth,
    remove_runtime,
    run_bridge,
    run_bridge_interactive,
)
from cosh_lab.ecs_backend import (
    EcsError,
    cleanup_ecs,
    ecs_creation_lock,
    ecs_download_file,
    ecs_exec,
    ecs_public_endpoint,
    ecs_upload_file,
    ecs_status,
    plan_or_create_ecs,
    recover_instance_by_run,
    stop_ecs_invocation,
)
from cosh_lab.evidence import (
    EvidenceError,
    attach_independent_screen,
    render_point_screenshots,
    verify_run,
)
from cosh_lab.issuefix import (
    IssueFixError,
    close_out,
    gh_auth_status,
    issue_audit,
    pr_assets_push,
    pr_preflight,
    pr_watch,
    ws_down,
    ws_status,
    ws_up,
)
from cosh_lab.profile import ProfileError, load_profile
from cosh_lab.test_runner import (
    build_test_plan,
    changed_paths,
    command_for_exact_case,
    command_for_scope,
    failed_test_cases,
    run_command,
)
from cosh_lab.transfer import (
    TransferError,
    create_directory_archive,
    extract_directory_archive,
    parse_remote_sha256,
    sha256_file,
    validate_remote_path,
)
from cosh_lab.transport import (
    INTERACTIVE_TRANSPORTS,
    NON_INTERACTIVE_TRANSPORTS,
    TransportError,
    resolve_transport,
    scp_argv,
    ssh_argv,
    transport_candidates,
)
from cosh_lab.workbench import (
    workbench_download_file,
    workbench_exec,
    workbench_profile_capability,
    workbench_upload_file,
    workbench_version_capability,
)


TOOL_ROOT = Path(__file__).resolve().parents[2]


def bridge_path_for(backend: dict[str, Any]) -> Path:
    """Resolve the backend bridge, preferring the recorded path.

    Run metadata pins the absolute bridge path captured at env-up time; if
    that file has since disappeared (for example a standalone cosh-lab
    checkout was moved or removed), fall back to this tool's embedded
    bridge for the same backend kind so exec/cancel/down keep working
    instead of failing on a stale path.
    """
    recorded = Path(str(backend.get("bridge_path") or ""))
    if recorded.is_file() and os.access(recorded, os.X_OK):
        return recorded
    kind = backend.get("kind")
    if kind:
        fallback = TOOL_ROOT / "scripts" / f"cosh-lab-{kind}"
        if fallback.is_file() and os.access(fallback, os.X_OK):
            return fallback
    return recorded


def target_repo_root(explicit: str | None = None) -> Path:
    configured = explicit or os.environ.get("COSH_LAB_TARGET_ROOT")
    if configured:
        return Path(configured).expanduser().resolve()
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        cwd=Path.cwd(),
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode == 0 and result.stdout.strip():
        return Path(result.stdout.strip()).resolve()
    return Path.cwd().resolve()


REPO_ROOT = target_repo_root()


def envelope(
    ok: bool,
    *,
    data: dict[str, Any] | None = None,
    code: str | None = None,
    message: str | None = None,
    run_dir: Path | None = None,
) -> dict[str, Any]:
    return {
        "ok": ok,
        "data": data if ok else None,
        "error": None if ok else {"code": code, "message": message},
        "meta": {
            "schema_version": 1,
            "run_dir": str(run_dir) if run_dir else None,
        },
    }


def repo_metadata() -> dict[str, Any]:
    commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=REPO_ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    status = subprocess.run(
        ["git", "status", "--short"],
        cwd=REPO_ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    branch = subprocess.run(
        ["git", "branch", "--show-current"],
        cwd=REPO_ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    return {
        "root": str(REPO_ROOT),
        "worktree": str(REPO_ROOT),
        "commit": commit.stdout.strip() if commit.returncode == 0 else None,
        "branch": branch.stdout.strip() if branch.returncode == 0 else None,
        "dirty": bool(status.stdout.strip()) if status.returncode == 0 else None,
        "architecture": platform.machine(),
    }


def command_version(command: str, *args: str) -> dict[str, Any]:
    path = shutil.which(command)
    if path is None:
        return {"ok": False, "path": None, "version": None}
    result = subprocess.run(
        [path, *args],
        text=True,
        capture_output=True,
        check=False,
    )
    version = (result.stdout or result.stderr).strip().splitlines()
    return {
        "ok": result.returncode == 0,
        "path": path,
        "version": version[0] if version else None,
    }


def resolved_container_runtime() -> dict[str, Any]:
    """Mirror the bridge script's runtime resolution for doctor visibility.

    The bridge prefers Apple ``container``, then ``docker``, then ``podman``;
    ``COSH_LAB_CONTAINER_RUNTIME`` overrides detection. Doctor reports the
    same resolution so operators see which runtime the container backend
    will use before starting an environment.
    """
    override = os.environ.get("COSH_LAB_CONTAINER_RUNTIME")
    candidates = ("container", "docker", "podman")
    if override:
        valid = override in candidates and shutil.which(override) is not None
        return {"ok": valid, "runtime": override if valid else None, "source": "override"}
    for candidate in candidates:
        if shutil.which(candidate) is not None:
            return {"ok": True, "runtime": candidate, "source": "detected"}
    return {"ok": False, "runtime": None, "source": "detected"}


def host_contention() -> dict[str, Any]:
    """Detect concurrent heavy workloads that would pollute timing runs.

    Benchmark and wall-time measurements are only attributable on an
    uncontended host; surface busy build/VM processes and load average so
    callers can gate timing scopes on ``contended``.
    """
    busy_names = ("cargo", "rustc", "container", "docker", "podman", "limactl", "qemu")
    busy_processes: list[dict[str, Any]] = []
    result = subprocess.run(
        ["ps", "-axo", "pid=,pcpu=,comm="],
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode == 0:
        for line in result.stdout.splitlines():
            parts = line.split(None, 2)
            if len(parts) != 3:
                continue
            raw_pid, raw_pcpu, comm = parts
            try:
                pid = int(raw_pid)
                pcpu = float(raw_pcpu)
            except ValueError:
                continue
            name = Path(comm).name
            if pid == os.getpid():
                continue
            if name in busy_names or pcpu >= 80.0:
                busy_processes.append(
                    {"pid": pid, "cpu_percent": pcpu, "name": name}
                )
    cpu_count = os.cpu_count() or 1
    try:
        load_1m = os.getloadavg()[0]
    except OSError:
        load_1m = None
    contended = bool(busy_processes) or (
        load_1m is not None and load_1m > cpu_count * 0.7
    )
    return {
        "busy_processes": busy_processes,
        "load_1m": load_1m,
        "cpu_count": cpu_count,
        "contended": contended,
    }


def run_doctor(args: argparse.Namespace) -> int:
    profile = None
    if args.profile:
        try:
            profile = load_profile(resolve_profile_arg(args.profile))
        except ProfileError as error:
            payload = envelope(False, code="invalid-profile", message=str(error))
            emit(payload, args.output)
            return 1
    artifacts = RunArtifacts(Path(args.artifact_root), "doctor", repo_metadata())
    capabilities = {
        "python": {
            "ok": sys.version_info >= (3, 11),
            "path": sys.executable,
            "version": platform.python_version(),
        },
        "ruby": command_version("ruby", "--version"),
        "canonical_runner": {
            "ok": (TOOL_ROOT / "scripts" / "e2e" / "cosh-shell-run-case").is_file(),
            "path": str(TOOL_ROOT / "scripts" / "e2e" / "cosh-shell-run-case"),
        },
        "canonical_cases": {
            "ok": (REPO_ROOT / "specs" / "shell-e2e-validation" / "cases").is_dir(),
            "path": str(REPO_ROOT / "specs" / "shell-e2e-validation" / "cases"),
        },
        "asciinema": command_version("asciinema", "--version"),
        "agg": command_version("agg", "--version"),
        "ffmpeg": command_version("ffmpeg", "-version"),
        "container": command_version("container", "--version"),
        "docker": command_version("docker", "--version"),
        "podman": command_version("podman", "--version"),
        "container_runtime": resolved_container_runtime(),
        "limactl": command_version("limactl", "--version"),
        "aliyun": command_version("aliyun", "--version"),
        "workbench": workbench_version_capability(),
        "gh": command_version("gh", "--version"),
        "gh_auth": gh_auth_status(),
    }
    profile_checks = None
    profile_summary = None
    if profile:
        backend = profile["backend"]
        section = profile[backend]
        source_root = (REPO_ROOT / profile["source_root"]).resolve()
        workbench_profile = None
        if backend == "ecs":
            bridge_ok = capabilities["aliyun"]["ok"]
            workbench_profile = section.get("transport", {}).get(
                "workbench_profile"
            )
        else:
            bridge_value = section.get("script_path")
            bridge = (
                Path(bridge_value).expanduser().resolve()
                if bridge_value
                else TOOL_ROOT / "scripts" / f"cosh-lab-{backend}"
            )
            bridge_ok = bridge.is_file() and os.access(bridge, os.X_OK)
        auth = profile.get("auth", {})
        if auth.get("mode") == "private_copy":
            source_value = auth.get("source_path")
            files = auth.get("files", [])
            auth_root = (
                Path(source_value).expanduser().resolve() if source_value else None
            )
            auth_ok = bool(
                auth_root
                and isinstance(files, list)
                and files
                and all(
                    not Path(relative).is_absolute()
                    and ".." not in Path(relative).parts
                    and (auth_root / relative).is_file()
                    and not (auth_root / relative).is_symlink()
                    for relative in files
                )
            )
        elif auth.get("mode") == "ecs_ram_role":
            auth_ok = bool(auth.get("ram_role_name"))
        else:
            auth_ok = not auth
        profile_checks = {
            "source_root": source_root.is_dir(),
            "bridge": bridge_ok,
            "auth_inputs": auth_ok,
        }
        if workbench_profile:
            if capabilities["workbench"]["ok"]:
                checked_profile = workbench_profile_capability(
                    workbench_profile
                )
            else:
                checked_profile = {
                    "ok": False,
                    "profile": workbench_profile,
                    "kind": "binary",
                    "exit_code": None,
                    "message": "Workbench binary is unavailable or unsupported",
                }
            capabilities["workbench_profile"] = {
                key: checked_profile.get(key)
                for key in (
                    "ok",
                    "profile",
                    "kind",
                    "exit_code",
                    "message",
                )
            }
            profile_checks["workbench_profile"] = bool(
                checked_profile.get("ok")
            )
        profile_summary = {
            "name": profile["name"],
            "backend": backend,
            "arch": profile["arch"],
        }
        if workbench_profile:
            profile_summary["workbench_profile"] = workbench_profile
    data = {
        "capabilities": capabilities,
        "repo": repo_metadata(),
        "profile": profile_summary,
        "profile_checks": profile_checks,
        "contention": host_contention(),
    }
    profile_ok = profile_checks is None or all(profile_checks.values())
    if profile_ok:
        payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    else:
        payload = envelope(
            False,
            code="environment-unavailable",
            message="profile capability checks failed",
            run_dir=artifacts.run_dir,
        )
        payload["data"] = data
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0 if profile_ok else 1


def run_runtime_check(args: argparse.Namespace) -> int:
    version = tuple(int(part) for part in args.version.split(".", 1))
    if version < (3, 11):
        payload = envelope(
            False,
            code="unsupported-python",
            message=f"Python 3.11+ required, got {args.version}",
        )
        emit(payload, "json")
        return 1
    emit(envelope(True, data={"version": args.version}), "json")
    return 0


def run_env_up(args: argparse.Namespace) -> int:
    try:
        profile = load_profile(resolve_profile_arg(args.profile))
    except ProfileError as error:
        payload = envelope(False, code="invalid-profile", message=str(error))
        emit(payload, args.output)
        return 1
    if profile["backend"] != args.backend:
        payload = envelope(
            False,
            code="invalid-profile",
            message=(
                f"profile backend {profile['backend']} does not match "
                f"requested backend {args.backend}"
            ),
        )
        emit(payload, args.output)
        return 1

    if args.backend == "ecs":
        return run_ecs_up(args, profile)

    backend_profile = profile.get(args.backend, {})
    bridge_path_value = backend_profile.get("script_path")
    if bridge_path_value:
        bridge_path = Path(bridge_path_value).expanduser().resolve()
    else:
        bridge_path = TOOL_ROOT / "scripts" / f"cosh-lab-{args.backend}"
    bridge_sha256 = None
    if bridge_path and bridge_path.is_file():
        bridge_sha256 = hashlib.sha256(bridge_path.read_bytes()).hexdigest()

    artifacts = RunArtifacts(Path(args.artifact_root), "env-up", repo_metadata())
    artifacts.manifest["capabilities"] = ["environment", "cleanup"]
    artifacts.manifest["profile"] = {
        "name": profile["name"],
        "arch": profile["arch"],
    }
    artifacts.manifest["backend"] = {
        "kind": args.backend,
        "bridge_path": str(bridge_path) if bridge_path else None,
        "bridge_sha256": bridge_sha256,
        "name": backend_profile.get("name"),
        "retain": bool(backend_profile.get("retain", False)),
    }
    change_plan = {
        "backend": args.backend,
        "profile": profile["name"],
        "actions": ["start"],
        "external_changes": not args.dry_run,
        "bridge_path": str(bridge_path) if bridge_path else None,
        "bridge_sha256": bridge_sha256,
    }
    if args.dry_run:
        payload = envelope(
            True,
            data={
                "run_id": artifacts.run_id,
                "dry_run": True,
                "change_plan": change_plan,
            },
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 0

    if (
        bridge_path is None
        or not bridge_path.is_file()
        or not os.access(bridge_path, os.X_OK)
    ):
        payload = envelope(
            False,
            code="environment-unavailable",
            message="backend bridge is missing or not executable",
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1

    try:
        private_auth, auth_hashes = prepare_private_auth(
            profile,
            Path(args.artifact_root),
            artifacts.run_id,
        )
        environment = bridge_environment(
            args.backend,
            profile,
            private_auth,
            REPO_ROOT,
        )
        environment["COSH_LAB_RUN_ID"] = artifacts.run_id
    except BackendError as error:
        payload = envelope(
            False,
            code="auth-blocked",
            message=str(error),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1

    runtime_dir = (
        Path(args.artifact_root).expanduser().resolve() / ".runtime" / artifacts.run_id
    )
    artifacts.manifest["state"] = "provisioning"
    artifacts.manifest["backend"]["runtime_dir"] = str(runtime_dir)
    auth_source_value = profile.get("auth", {}).get("source_path")
    artifacts.manifest["backend"]["auth_source_path"] = (
        str(Path(auth_source_value).expanduser().resolve())
        if auth_source_value
        else None
    )
    artifacts.manifest["backend"]["environment"] = {
        key: value
        for key, value in environment.items()
        if key.startswith(("COSH_LAB_", "COSH_ANOLIS_", "COSH_LIMA_"))
    }
    artifacts.manifest["backend"]["auth_source_hashes"] = auth_hashes
    artifacts.manifest["resources"] = [
        {
            "kind": args.backend,
            "id": backend_profile.get("name"),
        }
    ]
    artifacts.manifest["cleanup"]["status"] = "retained-by-policy"
    artifacts.save_manifest()
    result = run_bridge(
        bridge_path,
        "start",
        environment,
        timeout_seconds=backend_profile.get("provision_timeout_seconds", 300) + 180,
    )
    artifacts.manifest["commands"].append(result)
    (artifacts.run_dir / "commands.log").write_text(
        json.dumps(result, sort_keys=True) + "\n"
    )
    if result["exit_code"] != 0:
        payload = envelope(
            False,
            code="environment-unavailable",
            message=result["stderr"].strip() or "backend start failed",
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1

    environment_summary = {
        "run_id": artifacts.run_id,
        "backend": args.backend,
        "name": backend_profile.get("name"),
        "bridge_path": str(bridge_path),
        "bridge_sha256": bridge_sha256,
        "auth_source_hashes": auth_hashes,
    }
    write_json(artifacts.run_dir / "environment.json", environment_summary)
    write_json(artifacts.run_dir / "cleanup.json", artifacts.manifest["cleanup"])
    payload = envelope(
        True,
        data={
            "run_id": artifacts.run_id,
            "dry_run": False,
            "change_plan": change_plan,
            "stdout": result["stdout"],
        },
        run_dir=artifacts.run_dir,
    )
    artifacts.complete(payload, final_state="ready")
    emit(payload, args.output)
    return 0


def record_commands(artifacts: RunArtifacts, commands: list[dict[str, Any]]) -> None:
    for result in commands:
        artifacts.manifest["commands"].append(sanitize_record(result))
    (artifacts.run_dir / "commands.log").write_text(
        "".join(
            json.dumps(result, sort_keys=True) + "\n"
            for result in artifacts.manifest["commands"]
        )
    )


def redact_text(value: str) -> str:
    patterns = (
        (
            re.compile(
                r'(\\"(?:ak|sts|authorization|password|passwd|token|secret|api[_-]?key|private[_-]?key|command[_-]?content|oss[_-]?access[_-]?key[_-]?id|alibaba[_-]?cloud[_-]?access[_-]?key[_-]?(?:id|secret)|alibaba[_-]?cloud[_-]?security[_-]?token|access[_-]?key[_-]?(?:id|secret)|security[_-]?token|signature|x[_-]?oss[_-]?signature|x[_-]?oss[_-]?security[_-]?token)\\"\s*:\s*\\").*',
                re.I,
            ),
            r"\1[REDACTED]",
        ),
        (
            re.compile(r"(Authorization:\s*Bearer\s+)\S+", re.I),
            r"\1[REDACTED]",
        ),
        (re.compile(r"\b(?:LTAI|AKID)[A-Za-z0-9]{12,}\b"), "[REDACTED]"),
        (re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"), "[REDACTED]"),
        (
            re.compile(
                r'("(?:ak|sts|authorization|password|passwd|token|secret|api[_-]?key|private[_-]?key|command[_-]?content|oss[_-]?access[_-]?key[_-]?id|alibaba[_-]?cloud[_-]?access[_-]?key[_-]?(?:id|secret)|alibaba[_-]?cloud[_-]?security[_-]?token|access[_-]?key[_-]?id|access[_-]?key[_-]?secret|security[_-]?token|signature|x[_-]?oss[_-]?signature|x[_-]?oss[_-]?security[_-]?token)"\s*:\s*")((?:\\.|[^"\\])*)(")',
                re.I,
            ),
            r"\1[REDACTED]\3",
        ),
        (
            re.compile(
                r"(\b(?:ak|sts|password|passwd|token|secret|api[_-]?key|"
                r"oss[_-]?access[_-]?key[_-]?id|alibaba[_-]?cloud[_-]?"
                r"access[_-]?key[_-]?(?:id|secret)|alibaba[_-]?cloud[_-]?security[_-]?"
                r"token|access[_-]?key[_-]?id|access[_-]?key[_-]?secret|"
                r"security[_-]?token|signature|x[_-]?oss[_-]?signature|"
                r"x[_-]?oss[_-]?security[_-]?token|private[_-]?key|"
                r"command[_-]?content)\b\s*[:=]\s*)([^&\s,;]+)",
                re.I,
            ),
            r"\1[REDACTED]",
        ),
    )
    for pattern, replacement in patterns:
        value = pattern.sub(replacement, value)
    return value


def sanitize_value(value: Any) -> Any:
    if isinstance(value, str):
        return redact_text(value)
    if isinstance(value, list):
        sanitized = []
        redact_next = False
        for item in value:
            if redact_next:
                sanitized.append("[REDACTED]")
                redact_next = False
                continue
            sanitized_item = sanitize_value(item)
            sanitized.append(sanitized_item)
            if isinstance(item, str):
                option = re.sub(
                    r"[^a-z0-9]", "", item.lower().lstrip("-")
                )
                redact_next = option in {
                    "ak",
                    "sts",
                    "authorization",
                    "password",
                    "passwd",
                    "token",
                    "accesskeyid",
                    "accesskeysecret",
                    "securitytoken",
                    "ossaccesskeyid",
                    "alibabacloudaccesskeyid",
                    "alibabacloudaccesskeysecret",
                    "alibabacloudsecuritytoken",
                    "signature",
                    "xosssignature",
                    "xosssecuritytoken",
                    "apikey",
                    "privatekey",
                    "commandcontent",
                    "content",
                }
        return sanitized
    if isinstance(value, dict):
        sanitized = {}
        for key, item in value.items():
            normalized_key = re.sub(r"[^a-z0-9]", "", str(key).lower())
            if normalized_key in {
                "ak",
                "sts",
                "authorization",
                "password",
                "passwd",
                "token",
                "secret",
                "accesskeyid",
                "accesskeysecret",
                "securitytoken",
                "ossaccesskeyid",
                "alibabacloudaccesskeyid",
                "alibabacloudaccesskeysecret",
                "alibabacloudsecuritytoken",
                "signature",
                "xosssignature",
                "xosssecuritytoken",
                "apikey",
                "privatekey",
                "commandcontent",
                "content",
            }:
                sanitized[key] = "[REDACTED]"
            else:
                sanitized[key] = sanitize_value(item)
        return sanitized
    return value


def sanitize_record(result: dict[str, Any]) -> dict[str, Any]:
    return sanitize_value(copy.deepcopy(result))


def trusted_provider_evidence(
    auth_preflight: dict[str, Any],
    binary_preflight: dict[str, Any],
    argv: list[str],
    lifecycle: dict[str, Any],
) -> dict[str, Any]:
    required_auth = (
        "resolved_provider",
        "model",
        "adapter_type",
        "auth_source",
        "source_run_id",
    )
    if auth_preflight.get("effective_auth_required") is not False or any(
        not isinstance(auth_preflight.get(key), str)
        or not auth_preflight.get(key)
        for key in required_auth
    ):
        raise ValueError("trusted auth preflight is incomplete")
    resolved_path = binary_preflight.get("resolved_path")
    binary_sha256 = binary_preflight.get("binary_sha256")
    adapter_version = binary_preflight.get("adapter_version")
    build_attestation_sha256 = binary_preflight.get(
        "build_attestation_sha256"
    )
    if (
        not isinstance(resolved_path, str)
        or Path(resolved_path).name != "cosh-shell"
        or not isinstance(binary_sha256, str)
        or re.fullmatch(r"[0-9a-f]{64}", binary_sha256) is None
        or not isinstance(adapter_version, str)
        or not adapter_version
        or not (
            binary_preflight.get("isolated_build") is True
            or (
                binary_preflight.get("binary_origin") == "installed-rpm"
                and resolved_path == "/usr/libexec/anolisa/cosh-ng/cosh-shell"
                and re.fullmatch(r"[0-9a-f]{64}", str(binary_preflight.get("installed_manifest_sha256", "")))
                and re.fullmatch(r"[0-9a-f]{64}", str(binary_preflight.get("rpm_sha256", "")))
                and binary_preflight.get("payload_sha256", {}).get(resolved_path) == binary_sha256
            )
        )
        or not isinstance(build_attestation_sha256, str)
        or re.fullmatch(r"[0-9a-f]{64}", build_attestation_sha256) is None
    ):
        raise ValueError("production binary preflight is incomplete")
    if not argv or not all(isinstance(item, str) for item in argv):
        raise ValueError("production argv is incomplete")
    if binary_preflight.get("binary_origin") == "installed-rpm" and (
        argv[-3:] != [resolved_path, "raw", "cosh-core"]
        or argv[0] != "env"
        or "COSH_CORE_PATH=/usr/libexec/anolisa/cosh-ng/cosh-core" not in argv
    ):
        raise ValueError("installed RPM production argv differs from attested Shell/Core")
    timestamps = (
        lifecycle.get("request_started_at"),
        lifecycle.get("first_stream_event_at"),
        lifecycle.get("request_finished_at"),
    )
    if (
        not all(isinstance(value, str) and value for value in timestamps)
        or timestamps != tuple(sorted(timestamps))
        or not isinstance(lifecycle.get("request_count"), int)
        or lifecycle["request_count"] < 1
    ):
        raise ValueError("provider lifecycle is incomplete")
    if (
        lifecycle.get("provider_started_observed") is not True
        or lifecycle.get("semantic_checkpoint_observed") is not True
        or lifecycle.get("prompt_recovered") is not True
        or lifecycle.get("upstream_response_observed") is not True
        or re.fullmatch(
            r"[0-9a-f]{64}",
            str(lifecycle.get("request_nonce_sha256", "")),
        )
        is None
        or re.fullmatch(
            r"[0-9a-f]{64}",
            str(lifecycle.get("response_sha256", "")),
        )
        is None
        or not isinstance(lifecycle.get("response_summary"), str)
        or not lifecycle["response_summary"]
    ):
        raise ValueError("provider interaction checkpoints are incomplete")
    if auth_preflight["adapter_type"] in {"fake", "mock", "test"} or any(
        item in {"fake", "mock"} for item in argv
    ):
        raise ValueError("mock provider cannot produce real-provider evidence")
    return {
        "resolved_provider": auth_preflight["resolved_provider"],
        "model": auth_preflight["model"],
        "effective_auth_required": False,
        "binary_sha256": binary_sha256,
        "argv": argv[argv.index(resolved_path):] if binary_preflight.get("binary_origin") == "installed-rpm" else [resolved_path, *argv[1:]],
        "launch_argv": argv,
        "core_path": "/usr/libexec/anolisa/cosh-ng/cosh-core" if binary_preflight.get("binary_origin") == "installed-rpm" else None,
        "adapter_type": auth_preflight["adapter_type"],
        "auth_source": auth_preflight["auth_source"],
        "adapter_version": adapter_version,
        "isolated_build": binary_preflight.get("isolated_build") is True,
        "binary_origin": binary_preflight.get("binary_origin", "isolated-build"),
        "installed_manifest_sha256": binary_preflight.get("installed_manifest_sha256"),
        "rpm_sha256": binary_preflight.get("rpm_sha256"),
        "payload_sha256": binary_preflight.get("payload_sha256"),
        "build_attestation_sha256": build_attestation_sha256,
        "mock_enabled": False,
        "request_started_at": timestamps[0],
        "first_stream_event_at": timestamps[1],
        "request_finished_at": timestamps[2],
        "request_count": lifecycle["request_count"],
        "provider_started_observed": True,
        "semantic_checkpoint_observed": True,
        "prompt_recovered": True,
        "upstream_response_observed": True,
        "request_nonce_sha256": lifecycle["request_nonce_sha256"],
        "response_sha256": lifecycle["response_sha256"],
        "response_summary": lifecycle["response_summary"],
        "auth_preflight_run_id": auth_preflight["source_run_id"],
    }


def auth_preflight_is_fresh(
    auth_preflight: dict[str, Any],
    acceptance_started_at: str,
    max_age_seconds: int = 300,
) -> bool:
    try:
        checked = datetime.fromisoformat(str(auth_preflight["checked_at"]))
        started = datetime.fromisoformat(acceptance_started_at)
        if checked.tzinfo is None or started.tzinfo is None:
            return False
        age = (started - checked).total_seconds()
    except (KeyError, TypeError, ValueError):
        return False
    return 0 <= age <= max_age_seconds


def installed_provider_binary(environment_manifest, candidate_path, acceptance_run_id, on_invoke=None):
    candidate_file = Path(candidate_path)
    candidate = json.loads(candidate_file.read_text())
    binding_path = os.environ.get('COSH_LAB_INSTALLED_BINDING_JSON')
    if not binding_path:
        raise ValueError('Root installed binding is required')
    binding_file = Path(binding_path)
    verifier = (
        "import hashlib,pathlib,subprocess,sys; "
        "root=pathlib.Path('/var/lib/cosh-production-accept'); "
        "helper=root/'tools/fixtures/installed_identity.py'; "
        "contract=root/'tools/fixtures/production_contract.py'; "
        "manifest=root/'candidate.json';binding=root/'binding.json'; "
        "assert hashlib.sha256(helper.read_bytes()).hexdigest()==sys.argv[1]; "
        "assert hashlib.sha256(contract.read_bytes()).hexdigest()==sys.argv[2]; "
        "assert hashlib.sha256(manifest.read_bytes()).hexdigest()==sys.argv[3]; "
        "assert hashlib.sha256(binding.read_bytes()).hexdigest()==sys.argv[4]; "
        "subprocess.run(['python3','-B',str(helper),str(manifest),str(binding)],check=True)"
    )
    result, commands = execute_in_environment(
        environment_manifest,
        ['python3', '-B', '-c', verifier, '072607b7230c9f37e3415123c733d2555693793e9d7905c2e1eed18c7b0fdab6', 'a5b0085793f7a37db7c09ee57ef50c58f24976e830e74e4076bbade27880c651',
         hashlib.sha256(candidate_file.read_bytes()).hexdigest(),
         hashlib.sha256(binding_file.read_bytes()).hexdigest()],
        execution_id=f'{acceptance_run_id}-installed-rpm', on_invoke=on_invoke,
    )
    if result['exit_code'] != 0:
        error = ValueError('installed release six-payload identity preflight failed')
        error.commands = commands
        raise error
    parsed = json.loads(result['stdout'])
    artifact = candidate['architectures'][parsed['architecture']]
    if (parsed['source'] != candidate['source']
            or parsed['rpm_sha256'] != artifact['rpm_sha256']
            or parsed['rpm_nevra'] != artifact['nevra']
            or parsed['payload_sha256'] != artifact['payload_sha256']):
        raise ValueError('installed RPM differs from the new frozen input')
    parsed['isolated_build'] = False
    parsed['installed_manifest_sha256'] = hashlib.sha256(candidate_file.read_bytes()).hexdigest()
    parsed['build_attestation_sha256'] = hashlib.sha256(
        json.dumps({'command': result['argv'], 'identity': parsed},sort_keys=True).encode()).hexdigest()
    return parsed, commands


def build_provider_binary(
    environment_manifest: dict[str, Any],
    acceptance_run_id: str,
    on_invoke=None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    installed_candidate = os.environ.get('COSH_LAB_INSTALLED_CANDIDATE_JSON')
    if installed_candidate:
        if re.fullmatch(r"[0-9A-Za-z-]+", acceptance_run_id) is None:
            raise ValueError("acceptance run ID is unsafe")
        return installed_provider_binary(environment_manifest, installed_candidate, acceptance_run_id, on_invoke)
    if re.fullmatch(r"[0-9A-Za-z-]+", acceptance_run_id) is None:
        raise ValueError("acceptance run ID is unsafe")
    build_target = f"/cache/cosh-lab-provider-build/{acceptance_run_id}"
    script = (
        "set -eu; target=$1; test ! -e \"$target\"; mkdir -p \"$target\"; "
        "CARGO_TARGET_DIR=\"$target\" "
        "cargo build --locked --package cosh-shell --bin cosh-shell; "
        'resolved="$target/debug/cosh-shell"; test -x "$resolved"; '
        'digest_line=$(sha256sum "$resolved"); digest=${digest_line%% *}; '
        'version=$("$resolved" --version 2>&1 | head -n 1); '
        "printf 'resolved_path\\t%s\\nbinary_sha256\\t%s\\nadapter_version\\t%s\\n' "
        '"$resolved" "$digest" "$version"'
    )
    result, commands = execute_in_environment(
        environment_manifest,
        [
            "sh",
            "-lc",
            script,
            "cosh-lab-provider-build",
            build_target,
        ],
        execution_id=f"{acceptance_run_id}-provider-build",
        on_invoke=on_invoke,
    )
    if result["exit_code"] != 0:
        error = ValueError(
            result["stderr"].strip() or "isolated production binary build failed"
        )
        error.commands = commands
        raise error
    parsed = {}
    for line in result["stdout"].splitlines():
        key, separator, value = line.partition("\t")
        if separator:
            parsed[key] = value
    if (
        Path(str(parsed.get("resolved_path", ""))).name != "cosh-shell"
        or re.fullmatch(
            r"[0-9a-f]{64}",
            str(parsed.get("binary_sha256", "")),
        )
        is None
        or not parsed.get("adapter_version")
    ):
        error = ValueError("isolated production binary build output is incomplete")
        error.commands = commands
        raise error
    parsed["isolated_build"] = True
    parsed["build_attestation_sha256"] = hashlib.sha256(
        json.dumps(
            {
                "argv": result["argv"],
                "exit_code": result["exit_code"],
                "resolved_path": parsed.get("resolved_path"),
                "binary_sha256": parsed.get("binary_sha256"),
            },
            sort_keys=True,
        ).encode()
    ).hexdigest()
    return parsed, commands


def write_provider_evidence_index(
    run_dir: Path,
    evidence: dict[str, Any],
) -> None:
    headers = list(evidence)
    values = [json.dumps(evidence[key], sort_keys=True) for key in headers]
    (run_dir / "provider-parity-evidence-index.tsv").write_text(
        "\t".join(headers) + "\n" + "\t".join(values) + "\n"
    )


def run_ecs_up(args: argparse.Namespace, profile: dict[str, Any]) -> int:
    if args.apply and args.dry_run:
        payload = envelope(
            False,
            code="invalid-command",
            message="--apply and --dry-run cannot be combined",
        )
        emit(payload, args.output)
        return 1

    artifacts = RunArtifacts(Path(args.artifact_root), "env-up", repo_metadata())
    artifacts.manifest["capabilities"] = ["environment", "cleanup", "ecs"]
    artifacts.manifest["profile"] = {
        "name": profile["name"],
        "arch": profile["arch"],
    }
    artifacts.manifest["backend"] = {
        "kind": "ecs",
        "region": profile["ecs"]["region"],
        "ram_role_name": profile["auth"]["ram_role_name"],
        "security_group_id": profile["ecs"]["security_group_id"],
        "internet_max_bandwidth_out": profile["ecs"][
            "internet_max_bandwidth_out"
        ],
        "transport": profile["ecs"].get("transport", {}),
    }
    if args.apply:
        artifacts.manifest["state"] = "provisioning"
        artifacts.save_manifest()

    precreate_commands: list[dict[str, Any]] = []

    def persist_plan(
        plan: dict[str, Any],
        cli_path: str,
        commands: list[dict[str, Any]],
    ) -> None:
        precreate_commands[:] = commands
        artifacts.manifest["backend"].update(
            {
                "cli_path": cli_path,
                "amount": 1,
                "metadata_mode": profile["ecs"]["metadata_mode"],
                "client_token": plan["client_token"],
                "auto_release_time": plan["auto_release_time"],
                "internet_max_bandwidth_out": plan[
                    "internet_max_bandwidth_out"
                ],
                "tags": plan["tags"],
                "price": plan["price"],
                "create_state": "intent-persisted",
                "transport": profile["ecs"].get("transport", {}),
            }
        )
        if args.apply:
            artifacts.manifest["cleanup"]["status"] = "retained-by-policy"
        artifacts.save_manifest()

    def persist_instance(
        instance_id: str,
        plan: dict[str, Any],
        cli_path: str,
    ) -> None:
        artifacts.manifest["backend"].update(
            {
                "cli_path": cli_path,
                "amount": 1,
                "metadata_mode": profile["ecs"]["metadata_mode"],
                "client_token": plan["client_token"],
                "auto_release_time": plan["auto_release_time"],
                "internet_max_bandwidth_out": plan[
                    "internet_max_bandwidth_out"
                ],
                "tags": plan["tags"],
                "price": plan["price"],
                "create_state": "instance-recorded",
                "transport": profile["ecs"].get("transport", {}),
            }
        )
        artifacts.manifest["resources"] = [{"kind": "ecs", "id": instance_id}]
        artifacts.manifest["cleanup"]["status"] = "retained-by-policy"
        artifacts.save_manifest()
        write_json(
            artifacts.run_dir / "environment.json",
            {
                "run_id": artifacts.run_id,
                "backend": "ecs",
                "region": profile["ecs"]["region"],
                "instance_id": instance_id,
                "metadata_mode": profile["ecs"]["metadata_mode"],
                "ram_role_name": profile["auth"]["ram_role_name"],
                "price": plan["price"],
            },
        )
        write_json(
            artifacts.run_dir / "cleanup.json",
            artifacts.manifest["cleanup"],
        )

    try:
        if args.apply:
            with ecs_creation_lock(profile["ecs"]["region"]):
                result = plan_or_create_ecs(
                    profile,
                    artifacts.run_id,
                    True,
                    on_plan=persist_plan,
                    on_instance=persist_instance,
                )
        else:
            result = plan_or_create_ecs(
                profile,
                artifacts.run_id,
                False,
                on_plan=persist_plan,
                on_instance=persist_instance,
            )
    except KeyboardInterrupt:
        backend = artifacts.manifest["backend"]
        recovered_id = None
        recovery_commands: list[dict[str, Any]] = []
        if backend.get("cli_path") and backend.get("tags"):
            try:
                recovery = recover_instance_by_run(
                    backend["cli_path"],
                    backend["region"],
                    artifacts.run_id,
                )
                recovered_id = recovery["instance_id"]
                recovery_commands = recovery["commands"]
            except EcsError as error:
                recovery_commands = error.commands
        record_commands(artifacts, [*precreate_commands, *recovery_commands])
        if recovered_id:
            artifacts.manifest["resources"] = [{"kind": "ecs", "id": recovered_id}]
            artifacts.manifest["cleanup"]["status"] = "retained-by-policy"
            artifacts.save_manifest()
        payload = envelope(
            False,
            code="user-cancelled",
            message=(
                "ECS creation interrupted; inspect the manifest and run "
                f"env down --run {artifacts.run_id}"
            ),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    except EcsError as error:
        record_commands(artifacts, error.commands)
        payload = envelope(
            False,
            code="environment-unavailable",
            message=str(error),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1

    record_commands(artifacts, result["commands"])
    plan = result["plan"]
    transport = dict(profile["ecs"].get("transport", {}))
    instance = result.get("instance") or {}
    public_addresses = (
        instance.get("PublicIpAddress", {}).get("IpAddress", [])
    )
    eip = instance.get("EipAddress", {}).get("IpAddress")
    private_addresses = (
        instance.get("VpcAttributes", {})
        .get("PrivateIpAddress", {})
        .get("IpAddress", [])
    )
    inner_addresses = instance.get("InnerIpAddress", {}).get("IpAddress", [])
    if "public_host" not in transport:
        if public_addresses:
            transport["public_host"] = public_addresses[0]
        elif isinstance(eip, str) and eip:
            transport["public_host"] = eip
    if "private_host" not in transport:
        addresses = private_addresses or inner_addresses
        if addresses:
            transport["private_host"] = addresses[0]
    artifacts.manifest["backend"] = {
        "kind": "ecs",
        "region": profile["ecs"]["region"],
        "cli_path": result["cli_path"],
        "ram_role_name": profile["auth"]["ram_role_name"],
        "security_group_id": profile["ecs"]["security_group_id"],
        "internet_max_bandwidth_out": plan["internet_max_bandwidth_out"],
        "amount": 1,
        "metadata_mode": profile["ecs"]["metadata_mode"],
        "client_token": plan["client_token"],
        "auto_release_time": plan["auto_release_time"],
        "tags": plan["tags"],
        "price": plan["price"],
        "create_state": (
            "instance-recorded"
            if result["instance_id"] is not None
            else "not-submitted"
        ),
        "transport": transport,
    }
    if result["instance_id"] is None:
        artifacts.manifest["cleanup"]["status"] = "not-applicable"
        payload = envelope(
            True,
            data={
                "run_id": artifacts.run_id,
                "applied": False,
                "instance_id": None,
                "price": plan["price"],
                "change_plan": plan,
            },
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 0

    payload = envelope(
        True,
        data={
            "run_id": artifacts.run_id,
            "applied": True,
            "instance_id": result["instance_id"],
            "price": plan["price"],
            "change_plan": plan,
        },
        run_dir=artifacts.run_dir,
    )
    artifacts.complete(payload, final_state="ready")
    emit(payload, args.output)
    return 0


def load_environment(artifact_root: Path, run_id: str) -> tuple[Path, dict[str, Any]]:
    if re.fullmatch(r"\d{8}T\d{6}Z-[0-9a-f]{8}", run_id) is None:
        raise BackendError(f"unsafe environment run ID: {run_id}")
    root = artifact_root.expanduser().resolve()
    run_dir = (root / run_id).resolve()
    if run_dir.parent != root:
        raise BackendError(f"unsafe environment run ID: {run_id}")
    manifest_path = run_dir / "run.json"
    if not manifest_path.is_file():
        raise BackendError(
            f"environment run not found: {run_id} under {root} "
            "(the artifact root follows the invocation directory; run from "
            "the directory where env up was executed or pass --artifact-root)"
        )
    try:
        manifest = json.loads(manifest_path.read_text())
    except (OSError, json.JSONDecodeError) as error:
        raise BackendError(f"cannot load environment manifest: {error}") from error
    if not isinstance(manifest, dict):
        raise BackendError("environment manifest must be an object")
    if manifest.get("operation") != "env-up":
        raise BackendError(f"run is not an environment: {run_id}")
    if manifest.get("run_id") != run_id:
        raise BackendError(f"environment run ID does not match manifest: {run_id}")
    backend = manifest.get("backend")
    if not isinstance(backend, dict):
        raise BackendError("environment backend must be an object")
    transport = backend.get("transport", {})
    if not isinstance(transport, dict):
        raise BackendError("environment transport must be an object")
    if not isinstance(manifest.get("resources", []), list):
        raise BackendError("environment resources must be an array")
    return run_dir, manifest


def append_command(
    run_dir: Path, manifest: dict[str, Any], result: dict[str, Any]
) -> None:
    result = sanitize_record(result)
    manifest["commands"].append(result)
    with (run_dir / "commands.log").open("a") as log:
        log.write(json.dumps(result, sort_keys=True) + "\n")


@contextmanager
def environment_refresh_lock(environment_dir: Path):
    lock_id = hashlib.sha256(str(environment_dir.resolve()).encode()).hexdigest()
    lock_path = Path(tempfile.gettempdir()) / f"cosh-lab-refresh-{lock_id}.lock"
    with lock_path.open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def commit_environment_refresh(
    environment_dir: Path,
    manifest: dict[str, Any],
    command: dict[str, Any],
) -> None:
    manifest_path = environment_dir / "run.json"
    command_path = environment_dir / "commands.log"
    checksum_path = environment_dir / "checksums.sha256"
    for path in (manifest_path, command_path):
        if not path.is_file():
            raise OSError(f"owner evidence is not a regular file: {path.name}")
    if checksum_path.exists() and not checksum_path.is_file():
        raise OSError("owner checksum target is not a regular file")

    sanitized = sanitize_record(command)
    manifest["commands"].append(sanitized)
    replacements = {
        manifest_path: (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode(),
        command_path: command_path.read_bytes()
        + (json.dumps(sanitized, sort_keys=True) + "\n").encode(),
    }
    checksum_lines = []
    for path in sorted(environment_dir.rglob("*")):
        if not path.is_file() or path == checksum_path:
            continue
        content = replacements.get(path, path.read_bytes())
        checksum_lines.append(
            f"{hashlib.sha256(content).hexdigest()}  {path.relative_to(environment_dir)}"
        )
    replacements[checksum_path] = ("\n".join(checksum_lines) + "\n").encode()

    originals = {
        path: path.read_bytes() if path.exists() else None for path in replacements
    }
    staged: dict[Path, Path] = {}
    replaced: list[Path] = []
    try:
        for destination, content in replacements.items():
            with tempfile.NamedTemporaryFile(
                dir=environment_dir,
                prefix=f".{destination.name}.",
                delete=False,
            ) as temporary:
                temporary.write(content)
                temporary.flush()
                os.fsync(temporary.fileno())
                staged[destination] = Path(temporary.name)
        for destination in (manifest_path, command_path, checksum_path):
            staged[destination].replace(destination)
            replaced.append(destination)
    except OSError:
        for destination in reversed(replaced):
            original = originals[destination]
            if original is None:
                destination.unlink(missing_ok=True)
                continue
            with tempfile.NamedTemporaryFile(
                dir=environment_dir,
                prefix=f".{destination.name}.rollback.",
                delete=False,
            ) as temporary:
                temporary.write(original)
                rollback = Path(temporary.name)
            rollback.replace(destination)
        raise
    finally:
        for temporary in staged.values():
            temporary.unlink(missing_ok=True)


def invocation_persister(
    environment_dir: Path,
    manifest: dict[str, Any],
):
    def persist(invoke_id: str, name: str, client_token: str) -> None:
        with environment_refresh_lock(environment_dir):
            current = json.loads((environment_dir / "run.json").read_text())
            invocations = current.setdefault("invocations", [])
            invocation = next(
                (
                    item
                    for item in invocations
                    if item.get("client_token") == client_token
                ),
                None,
            )
            if invocation is None:
                invocation = {
                    "invoke_id": None,
                    "name": name,
                    "client_token": client_token,
                    "status": "submitted",
                }
                invocations.append(invocation)
            if invoke_id:
                invocation["invoke_id"] = invoke_id
                invocation["status"] = "active"
            write_json(environment_dir / "run.json", current)
            refresh_checksums(environment_dir)
            manifest.clear()
            manifest.update(current)

    def complete(invoke_id: str) -> None:
        with environment_refresh_lock(environment_dir):
            current = json.loads((environment_dir / "run.json").read_text())
            for invocation in current.get("invocations", []):
                if invocation.get("invoke_id") == invoke_id:
                    invocation["status"] = "completed"
            write_json(environment_dir / "run.json", current)
            refresh_checksums(environment_dir)
            manifest.clear()
            manifest.update(current)

    persist.complete = complete
    return persist


def execute_in_environment(
    manifest: dict[str, Any],
    command: list[str],
    execution_id: str | None = None,
    on_invoke=None,
    transport: str = "auto",
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    backend = manifest["backend"]
    if backend.get("kind") == "ecs":
        if not execution_id:
            raise BackendError("ECS execution requires an operation ID")

        probe_records: list[dict[str, Any]] = []

        def probe(candidate: str) -> dict[str, Any]:
            if candidate == "assistant":
                result = {
                    "transport": candidate,
                    "ok": True,
                    "exit_code": 0,
                    "probe": "manifest-capability",
                }
            elif candidate == "workbench":
                result = workbench_exec(
                    manifest, ["true"], timeout_seconds=30
                )
                result.update(
                    {
                        "ok": result["exit_code"] == 0,
                        "probe": True,
                    }
                )
            else:
                argv = ssh_argv(backend, candidate, ["true"])
                started = time.monotonic()
                completed = subprocess.run(
                    argv,
                    stdin=subprocess.DEVNULL,
                    text=True,
                    capture_output=True,
                    check=False,
                )
                result = {
                    "transport": candidate,
                    "ok": completed.returncode == 0,
                    "argv": argv,
                    "exit_code": completed.returncode,
                    "duration_seconds": round(time.monotonic() - started, 6),
                    "stdout": completed.stdout,
                    "stderr": completed.stderr,
                    "probe": True,
                }
            probe_records.append(result)
            return result

        try:
            selection = resolve_transport(
                manifest,
                transport,
                "exec",
                probe,
            )
        except TransportError as error:
            error.commands = probe_records
            raise
        selected = selection["selected"]
        if selected == "workbench":
            try:
                result = workbench_exec(manifest, command)
            except KeyboardInterrupt as error:
                error.commands = [
                    *probe_records,
                    *getattr(error, "commands", []),
                ]
                raise
            commands = [*probe_records, result]
        elif selected == "assistant":
            result = ecs_exec(
                manifest,
                command,
                execution_id=execution_id,
                on_invoke=on_invoke,
            )
            result["terminal_state_known"] = True
            result["failure_kind"] = (
                "remote-command" if result["exit_code"] != 0 else None
            )
            commands = [*probe_records, *result["commands"]]
        else:
            argv = ssh_argv(backend, selected, command)
            started = time.monotonic()
            completed = subprocess.run(
                argv,
                stdin=subprocess.DEVNULL,
                text=True,
                capture_output=True,
                check=False,
            )
            result = {
                "argv": argv,
                "exit_code": completed.returncode,
                "duration_seconds": round(time.monotonic() - started, 6),
                "stdout": completed.stdout,
                "stderr": completed.stderr,
                "terminal_state_known": completed.returncode != 255,
                "failure_kind": (
                    "transport"
                    if completed.returncode == 255
                    else "remote-command"
                    if completed.returncode != 0
                    else None
                ),
                "transport": selected,
            }
            commands = [*probe_records, result]
        result["transport"] = selected
        result["probes"] = selection["probes"]
        return result, commands
    selection = native_transport_selection(manifest, transport, "exec")
    result = run_bridge(
        bridge_path_for(backend),
        "exec",
        {**os.environ, **backend["environment"]},
        command,
    )
    result["transport"] = selection["selected"]
    result["probes"] = selection["probes"]
    result["terminal_state_known"] = True
    result["failure_kind"] = (
        "remote-command" if result["exit_code"] != 0 else None
    )
    return result, [result]


def interrupted_transport(error: BaseException) -> str | None:
    for command in reversed(getattr(error, "commands", [])):
        transport = command.get("transport")
        if isinstance(transport, str):
            return transport
    return None


def cancel_environment_command(
    environment_dir: Path,
    manifest: dict[str, Any],
) -> dict[str, Any] | None:
    backend = manifest["backend"]
    if backend.get("kind") == "ecs":
        result = stop_ecs_invocation(manifest)
        if result is None:
            return None
        with environment_refresh_lock(environment_dir):
            current = json.loads((environment_dir / "run.json").read_text())
            for invocation in current.get("invocations", []):
                if invocation.get("invoke_id") == result.get("invoke_id"):
                    invocation["status"] = "completed"
            append_command(environment_dir, current, result)
            write_json(environment_dir / "run.json", current)
            refresh_checksums(environment_dir)
            manifest.clear()
            manifest.update(current)
        return result
    result = run_bridge(
        bridge_path_for(backend),
        "cancel",
        {**os.environ, **backend["environment"]},
    )
    with environment_refresh_lock(environment_dir):
        current = json.loads((environment_dir / "run.json").read_text())
        append_command(environment_dir, current, result)
        write_json(environment_dir / "run.json", current)
        refresh_checksums(environment_dir)
        manifest.clear()
        manifest.update(current)
    return result


def run_env_exec(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        environment_dir, environment_manifest = load_environment(
            artifact_root, args.run
        )
    except BackendError as error:
        payload = envelope(False, code="environment-unavailable", message=str(error))
        emit(payload, args.output)
        return 1
    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        payload = envelope(
            False, code="invalid-command", message="exec requires a command"
        )
        emit(payload, args.output)
        return 1

    artifacts = RunArtifacts(artifact_root, "env-exec", repo_metadata())
    artifacts.manifest["environment_ref"] = args.run

    persist_invoke = invocation_persister(
        environment_dir,
        environment_manifest,
    )

    try:
        result, commands = execute_in_environment(
            environment_manifest,
            command,
            execution_id=artifacts.run_id,
            on_invoke=persist_invoke,
            transport=args.transport,
        )
    except KeyboardInterrupt as error:
        interrupted_commands = getattr(error, "commands", [])
        if interrupted_commands:
            record_commands(artifacts, interrupted_commands)
        cleanup_safe = getattr(error, "cleanup_safe", True)
        cancel_assistant = (
            cleanup_safe and interrupted_transport(error) != "workbench"
        )
        if cancel_assistant:
            cancel_result = cancel_environment_command(
                environment_dir,
                environment_manifest,
            )
            if cancel_result:
                record_commands(artifacts, [cancel_result])
        payload = envelope(
            False,
            code="user-cancelled",
            message=(
                "operation interrupted; backend command cancellation attempted"
                if cancel_assistant
                else "operation interrupted; backend command state is unknown"
            ),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    except (EcsError, TransportError) as error:
        record_commands(artifacts, getattr(error, "commands", []))
        payload = envelope(
            False,
            code="environment-unavailable",
            message=str(error),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    record_commands(artifacts, commands)
    data = {
        "command": command,
        "exit_code": result["exit_code"],
        "stdout": result["stdout"],
        "stderr": result["stderr"],
        "transport": result["transport"],
        "probes": result["probes"],
        "terminal_state_known": result.get("terminal_state_known"),
        "failure_kind": result.get("failure_kind"),
    }
    data = sanitize_value(data)
    if result["exit_code"] == 0:
        payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    else:
        remote_command_failed = data["failure_kind"] == "remote-command"
        payload = envelope(
            False,
            code=(
                "command-failed"
                if remote_command_failed
                else "environment-unavailable"
            ),
            message=data["stderr"].strip() or "backend exec failed",
            run_dir=artifacts.run_dir,
        )
        payload["data"] = data
    artifacts.complete(payload)
    emit(payload, args.output)
    if result["exit_code"] == 0:
        return 0
    return result["exit_code"] if remote_command_failed else 1


def native_transport_selection(
    manifest: dict[str, Any],
    requested: str,
    operation: str,
) -> dict[str, Any]:
    return resolve_transport(
        manifest,
        requested,
        operation,
        lambda name: {
            "transport": name,
            "ok": name == "native",
            "exit_code": 0 if name == "native" else 1,
        },
    )


def subprocess_record(argv: list[str]) -> dict[str, Any]:
    started = time.monotonic()
    completed = subprocess.run(
        argv,
        stdin=subprocess.DEVNULL,
        text=True,
        capture_output=True,
        check=False,
    )
    return {
        "argv": argv,
        "exit_code": completed.returncode,
        "duration_seconds": round(time.monotonic() - started, 6),
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


def select_operation_transport(
    manifest: dict[str, Any],
    requested: str,
    operation: str,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    if manifest["backend"].get("kind") in {"container", "vm"}:
        return native_transport_selection(
            manifest,
            requested,
            operation,
        ), []
    records = []

    def probe(candidate: str) -> dict[str, Any]:
        if candidate == "assistant":
            result = {
                "transport": candidate,
                "ok": True,
                "exit_code": 0,
                "probe": "manifest-capability",
            }
        elif candidate == "workbench":
            result = workbench_exec(
                manifest, ["true"], timeout_seconds=30
            )
            result.update(
                {
                    "ok": result["exit_code"] == 0,
                    "probe": True,
                }
            )
        else:
            result = subprocess_record(
                ssh_argv(manifest["backend"], candidate, ["true"])
            )
            result.update(
                {
                    "transport": candidate,
                    "ok": result["exit_code"] == 0,
                    "probe": True,
                }
            )
        records.append(result)
        return result

    try:
        selection = resolve_transport(manifest, requested, operation, probe)
    except TransportError as error:
        error.commands = records
        raise
    except KeyboardInterrupt as error:
        error.commands = [*records, *getattr(error, "commands", [])]
        raise
    return selection, records


def emit_transport_setup_error(
    args: argparse.Namespace,
    operation: str,
    error: Exception,
) -> int:
    commands = list(getattr(error, "commands", []))
    if not commands:
        emit(envelope(False, code="invalid-command", message=str(error)), args.output)
        return 1
    artifacts = RunArtifacts(Path(args.artifact_root), operation, repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    record_commands(artifacts, commands)
    payload = envelope(
        False,
        code="environment-unavailable",
        message=str(error),
        run_dir=artifacts.run_dir,
    )
    artifacts.complete(payload)
    emit(payload, args.output)
    return 1


def emit_transport_setup_interrupt(
    args: argparse.Namespace,
    operation: str,
    error: KeyboardInterrupt,
) -> int:
    artifacts = RunArtifacts(Path(args.artifact_root), operation, repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    record_commands(artifacts, getattr(error, "commands", []))
    payload = envelope(
        False,
        code="user-cancelled",
        message="transport probe interrupted; backend command state is unknown",
        run_dir=artifacts.run_dir,
    )
    artifacts.complete(payload)
    emit(payload, args.output)
    return 1


def workbench_transfer_error(
    result: dict[str, Any], fallback: str
) -> TransferError:
    detail = result["stderr"].strip()
    message = f"{fallback}: {detail}" if detail else fallback
    error = TransferError(message)
    error.cleanup_safe = result.get("terminal_state_known") is True
    return error


def wait_workbench_remote_file(
    manifest: dict[str, Any],
    remote_path: str,
    *,
    timeout_seconds: float = 10.0,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    deadline = time.monotonic() + timeout_seconds
    records = []
    while True:
        result = workbench_exec(
            manifest,
            ["test", "-f", remote_path],
            timeout_seconds=30,
        )
        result["readiness_probe"] = True
        records.append(result)
        if result["exit_code"] == 0:
            return result, records
        if (
            result.get("failure_kind") != "remote-command"
            or result.get("terminal_state_known") is not True
            or time.monotonic() >= deadline
        ):
            return result, records
        time.sleep(0.2)


def ssh_remote_command(
    manifest: dict[str, Any],
    transport: str,
    command: list[str],
) -> dict[str, Any]:
    result = subprocess_record(
        ssh_argv(manifest["backend"], transport, command)
    )
    result["transport"] = transport
    return result


def ssh_copy_command(
    manifest: dict[str, Any],
    transport: str,
    local_path: Path,
    remote_path: str,
    *,
    upload: bool,
) -> dict[str, Any]:
    argv = scp_argv(
        manifest["backend"],
        transport,
        str(local_path),
        remote_path,
        upload=upload,
    )
    started = time.monotonic()
    try:
        result = subprocess_record(argv)
    except OSError as error:
        result = {
            "argv": argv,
            "exit_code": 127,
            "duration_seconds": round(time.monotonic() - started, 6),
            "stdout": "",
            "stderr": str(error),
        }
    result["transport"] = transport
    result["transfer_method"] = "scp"
    return result


def ssh_stream_copy_command(
    manifest: dict[str, Any],
    transport: str,
    local_path: Path,
    remote_path: str,
    *,
    upload: bool,
) -> dict[str, Any]:
    operation = "upload" if upload else "download"
    command = (
        ["sh", "-c", 'cat > "$1"', "cosh-lab-upload", remote_path]
        if upload
        else ["sh", "-c", 'cat "$1"', "cosh-lab-download", remote_path]
    )
    argv = ssh_argv(manifest["backend"], transport, command)
    started = time.monotonic()
    try:
        if upload:
            with local_path.open("rb") as source:
                completed = subprocess.run(
                    argv,
                    stdin=source,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE,
                    check=False,
                )
        else:
            with local_path.open("wb") as destination:
                completed = subprocess.run(
                    argv,
                    stdin=subprocess.DEVNULL,
                    stdout=destination,
                    stderr=subprocess.PIPE,
                    check=False,
                )
        stderr = completed.stderr
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
        result = {
            "argv": argv,
            "exit_code": completed.returncode,
            "duration_seconds": round(time.monotonic() - started, 6),
            "stdout": "",
            "stderr": stderr,
        }
    except KeyboardInterrupt as error:
        error.commands = [
            {
                "argv": argv,
                "exit_code": 130,
                "duration_seconds": round(time.monotonic() - started, 6),
                "stdout": "",
                "stderr": "SSH stream interrupted",
                "transport": transport,
                "transfer_method": "ssh-stream",
                "operation": operation,
            }
        ]
        raise
    except OSError as error:
        result = {
            "argv": argv,
            "exit_code": 127,
            "duration_seconds": round(time.monotonic() - started, 6),
            "stdout": "",
            "stderr": str(error),
        }
    result["transport"] = transport
    result["transfer_method"] = "ssh-stream"
    result["operation"] = operation
    return result


def ssh_copy_with_fallback(
    manifest: dict[str, Any],
    transport: str,
    local_path: Path,
    remote_path: str,
    *,
    upload: bool,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    scp = ssh_copy_command(
        manifest,
        transport,
        local_path,
        remote_path,
        upload=upload,
    )
    records = [scp]
    if scp["exit_code"] == 0:
        return scp, records
    try:
        stream = ssh_stream_copy_command(
            manifest,
            transport,
            local_path,
            remote_path,
            upload=upload,
        )
    except KeyboardInterrupt as error:
        error.commands = [scp, *getattr(error, "commands", [])]
        raise
    records.append(stream)
    return stream, records


def best_effort_remote_cleanup(
    manifest: dict[str, Any],
    transport: str,
    remote_paths: list[str],
    execution_id: str,
    on_invoke=None,
) -> list[dict[str, Any]]:
    if not remote_paths:
        return []
    try:
        result, commands = execute_in_environment(
            manifest,
            ["rm", "-rf", *remote_paths],
            execution_id=execution_id,
            on_invoke=on_invoke,
            transport=transport,
        )
        if result["exit_code"] != 0:
            result["cleanup_failed"] = True
        return commands
    except (EcsError, TransportError, KeyboardInterrupt) as error:
        commands = list(getattr(error, "commands", []))
        commands.append(
            {
                "argv": ["remote-cleanup", *remote_paths],
                "exit_code": 1,
                "stdout": "",
                "stderr": str(error),
                "cleanup_failed": True,
                "transport": transport,
            }
        )
        return commands


def native_transfer_command(
    manifest: dict[str, Any],
    action: str,
    local_path: Path | None,
    remote_path: str,
    transfer_id: str | None = None,
) -> dict[str, Any]:
    backend = manifest["backend"]
    environment = {**os.environ, **backend["environment"]}
    environment["COSH_LAB_TRANSFER_REMOTE"] = remote_path
    if transfer_id is not None:
        environment["COSH_LAB_TRANSFER_ID"] = transfer_id
    if local_path is not None:
        environment["COSH_LAB_TRANSFER_LOCAL"] = str(local_path)
    return run_bridge(
        bridge_path_for(backend),
        action,
        environment,
    )


def run_env_upload(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        environment_dir, manifest = load_environment(artifact_root, args.run)
        source_argument = Path(args.local).expanduser()
        if source_argument.is_symlink():
            raise TransferError("upload source cannot be a symlink")
        source = source_argument.resolve(strict=True)
        if not (source.is_file() or source.is_dir()):
            raise TransferError("upload source must be a file or directory")
        source_kind = "directory" if source.is_dir() else "file"
        remote = validate_remote_path(args.remote)
        selection, probe_records = select_operation_transport(
            manifest,
            args.transport,
            "upload",
        )
    except KeyboardInterrupt as error:
        return emit_transport_setup_interrupt(args, "env-upload", error)
    except (BackendError, OSError, TransferError, TransportError) as error:
        return emit_transport_setup_error(args, "env-upload", error)

    artifacts = RunArtifacts(artifact_root, "env-upload", repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    artifacts.manifest["capabilities"] = ["environment-operation", "transfer"]
    transfer_source = source
    transfer_remote = remote
    archive_root = None
    if source_kind == "directory":
        archive_root = Path(tempfile.mkdtemp(prefix="cosh-lab-upload-"))
        archive_root.chmod(0o700)
        transfer_source = archive_root / "directory-upload.tar"
        try:
            create_directory_archive(source, transfer_source)
        except (OSError, TransferError) as error:
            shutil.rmtree(archive_root, ignore_errors=True)
            payload = envelope(
                False,
                code="invalid-command",
                message=str(error),
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        transfer_remote = f"/tmp/.cosh-lab-{artifacts.run_id}-upload.tar"
    expected = sha256_file(transfer_source)
    transfer_size = transfer_source.stat().st_size
    selected = selection["selected"]
    commands = list(probe_records)
    persist_invoke = invocation_persister(environment_dir, manifest)
    cleanup_paths = []
    workbench_staging_root = None
    workbench_staging = None
    workbench_directory_staging = None
    publish_started = False
    published = False
    if selected in {"native", "ssh", "proxyjump"}:
        cleanup_paths.append(
            f"{transfer_remote}.cosh-lab-{artifacts.run_id}.tmp"
        )
    elif selected == "workbench":
        transfer_hash = hashlib.sha256(
            (manifest["run_id"] + "\0" + artifacts.run_id).encode()
        ).hexdigest()[:24]
        if source_kind == "directory":
            workbench_staging_root = f"/tmp/.cosh-lab-transfer-{transfer_hash}"
            workbench_staging = (
                f"{workbench_staging_root}/{transfer_source.name}"
            )
            transfer_remote = workbench_staging
        else:
            workbench_staging_root = (
                f"{transfer_remote}.cosh-lab-{transfer_hash}.stage"
            )
            workbench_staging = f"{workbench_staging_root}/{transfer_source.name}"
    else:
        transfer_hash = hashlib.sha256(
            (manifest["run_id"] + "\0" + artifacts.run_id).encode()
        ).hexdigest()[:24]
        cleanup_paths.extend(
            (
                f"/tmp/.cosh-lab-transfer-{transfer_hash}",
                f"{transfer_remote}.cosh-lab-{transfer_hash}.tmp",
            )
        )
    if source_kind == "directory" and selected != "workbench":
        cleanup_paths.extend(
            (
                transfer_remote,
                f"{remote}.cosh-lab-{artifacts.run_id}.tmp",
            )
        )
    artifacts.manifest["temporary_remote_paths"] = [
        {"path": path, "cleanup_status": "pending"}
        for path in cleanup_paths
    ]
    artifacts.save_manifest()
    try:
        if selected == "native":
            upload = native_transfer_command(
                manifest,
                "upload",
                transfer_source,
                transfer_remote,
                artifacts.run_id,
            )
            commands.append(upload)
            verify = native_transfer_command(
                manifest,
                "hash",
                None,
                transfer_remote,
                artifacts.run_id,
            )
            commands.append(verify)
            actual = parse_remote_sha256(verify["stdout"])
            if upload["exit_code"] != 0:
                raise TransferError(upload["stderr"].strip() or "upload failed")
            if verify["exit_code"] != 0 or actual != expected:
                raise TransferError("uploaded file SHA-256 mismatch")
        elif selected in {"ssh", "proxyjump"}:
            staging = (
                f"{transfer_remote}.cosh-lab-{artifacts.run_id}.tmp"
            )
            prepare = ssh_remote_command(
                manifest,
                selected,
                [
                    "sh",
                    "-lc",
                    'mkdir -p "$(dirname "$1")"; rm -f "$1"',
                    "cosh-lab-upload",
                    staging,
                ],
            )
            upload, upload_commands = ssh_copy_with_fallback(
                manifest,
                selected,
                transfer_source,
                staging,
                upload=True,
            )
            verify = ssh_remote_command(
                manifest,
                selected,
                [
                    "sh",
                    "-lc",
                    'sha256sum "$1" | awk \'{print $1}\'',
                    "cosh-lab-upload",
                    staging,
                ],
            )
            commands.extend((prepare, *upload_commands, verify))
            if any(item["exit_code"] != 0 for item in (prepare, upload, verify)):
                raise TransferError("SSH upload failed")
            actual = parse_remote_sha256(verify["stdout"])
            if actual != expected:
                raise TransferError("uploaded file SHA-256 mismatch")
            replace = ssh_remote_command(
                manifest,
                selected,
                [
                    "sh",
                    "-lc",
                    'mv -f "$1" "$2"',
                    "cosh-lab-upload",
                    staging,
                    transfer_remote,
                ],
            )
            commands.append(replace)
            if replace["exit_code"] != 0:
                raise TransferError("SSH upload atomic replace failed")
        elif selected == "workbench":
            artifacts.manifest["temporary_remote_paths"].append(
                {
                    "path": workbench_staging_root,
                    "cleanup_status": "ownership-unconfirmed",
                }
            )
            artifacts.save_manifest()
            claim = workbench_exec(
                manifest,
                [
                    "sh",
                    "-c",
                    'set -eu; mkdir -p "$(dirname "$1")"; umask 077; '
                    'mkdir "$1"; chmod 0777 "$1"',
                    "cosh-lab-upload",
                    workbench_staging_root,
                ],
                timeout_seconds=30,
            )
            commands.append(claim)
            if claim["exit_code"] != 0:
                if claim.get("terminal_state_known") is True:
                    artifacts.manifest["temporary_remote_paths"][-1][
                        "cleanup_status"
                    ] = "unowned"
                    artifacts.save_manifest()
                error = workbench_transfer_error(
                    claim, "Workbench upload staging claim failed"
                )
                error.cleanup_safe = False
                raise error
            cleanup_paths.append(workbench_staging_root)
            artifacts.manifest["temporary_remote_paths"][-1][
                "cleanup_status"
            ] = "pending"
            artifacts.save_manifest()
            upload = workbench_upload_file(
                manifest,
                transfer_source,
                f"{workbench_staging_root}/",
            )
            commands.append(upload)
            if upload["exit_code"] != 0:
                raise workbench_transfer_error(
                    upload, "Workbench upload failed"
                )
            ready, readiness_records = wait_workbench_remote_file(
                manifest,
                workbench_staging,
            )
            commands.extend(readiness_records)
            if ready["exit_code"] != 0:
                raise workbench_transfer_error(
                    ready, "Workbench upload did not become visible"
                )
            verify = workbench_exec(
                manifest,
                [
                    "sh",
                    "-c",
                    'set -eu; digest=$(sha256sum "$1"); printf "%s\\n" "${digest%% *}"',
                    "cosh-lab-upload",
                    workbench_staging,
                ],
            )
            commands.append(verify)
            if verify["exit_code"] != 0:
                raise workbench_transfer_error(
                    verify, "Workbench upload hash failed"
                )
            actual = parse_remote_sha256(verify["stdout"])
            if actual != expected:
                raise TransferError("uploaded file SHA-256 mismatch")
            if workbench_staging != transfer_remote:
                publish_started = True
                replace = workbench_exec(
                    manifest,
                    [
                        "sh",
                        "-c",
                        ('set -eu; source=$1; target=$2; '
                         'mkdir -p "$(dirname "$target")"; '
                         'inode=$(stat -c "%d:%i" "$source"); '
                         'mv -T -f -- "$source" "$target"; '
                         'test ! -e "$source"; test -f "$target"; '
                         'test "$(stat -c "%d:%i" "$target")" = "$inode"'),
                        "cosh-lab-upload",
                        workbench_staging,
                        transfer_remote,
                    ],
                )
                commands.append(replace)
                if replace["exit_code"] != 0:
                    fallback = (
                        "Workbench upload atomic replace failed"
                        if replace.get("terminal_state_known") is True
                        else "Workbench upload publish state is unknown; "
                        "do not retry automatically"
                    )
                    raise workbench_transfer_error(replace, fallback)
                published = True
        else:
            upload = ecs_upload_file(
                manifest,
                transfer_source,
                transfer_remote,
                artifacts.run_id,
                on_invoke=persist_invoke,
            )
            commands.extend(upload["commands"])
            actual = upload["sha256"]
        if source_kind == "directory" and selected == "workbench":
            workbench_directory_staging = (
                f"{remote}.cosh-lab-{artifacts.run_id}.tmp"
            )
            artifacts.manifest["temporary_remote_paths"].append(
                {
                    "path": workbench_directory_staging,
                    "cleanup_status": "ownership-unconfirmed",
                }
            )
            artifacts.save_manifest()
            claim = workbench_exec(
                manifest,
                [
                    "sh",
                    "-c",
                    'set -eu; test ! -e "$2"; '
                    'mkdir -p "$(dirname "$1")"; umask 077; mkdir "$1"',
                    "cosh-lab-directory-upload",
                    workbench_directory_staging,
                    remote,
                ],
                timeout_seconds=30,
            )
            commands.append(claim)
            if claim["exit_code"] != 0:
                if claim.get("terminal_state_known") is True:
                    artifacts.manifest["temporary_remote_paths"][-1][
                        "cleanup_status"
                    ] = "unowned"
                    artifacts.save_manifest()
                error = workbench_transfer_error(
                    claim, "Workbench directory staging claim failed"
                )
                error.cleanup_safe = (
                    claim.get("terminal_state_known") is True
                )
                raise error
            cleanup_paths.append(workbench_directory_staging)
            artifacts.manifest["temporary_remote_paths"][-1][
                "cleanup_status"
            ] = "pending"
            artifacts.save_manifest()
        if source_kind == "directory":
            extraction_script = (
                'set -eu; archive=$1; staging=$3; '
                'tar -xf "$archive" -C "$staging"'
                if selected == "workbench"
                else (
                    'set -eu; archive=$1; target=$2; staging=$3; '
                    'test ! -e "$target"; rm -rf "$staging"; '
                    'mkdir -p "$(dirname "$target")" "$staging"; '
                    'tar -xf "$archive" -C "$staging"; '
                    'mv "$staging" "$target"; rm -f "$archive"; '
                    'test -d "$target"'
                )
            )
            directory_staging = (
                workbench_directory_staging
                if selected == "workbench"
                else f"{remote}.cosh-lab-{artifacts.run_id}.tmp"
            )
            extraction, extraction_commands = execute_in_environment(
                manifest,
                [
                    "sh",
                    "-lc",
                    extraction_script,
                    "cosh-lab-directory-upload",
                    transfer_remote,
                    remote,
                    directory_staging,
                ],
                execution_id=f"{artifacts.run_id}-extract",
                on_invoke=persist_invoke,
                transport=selected,
            )
            commands.extend(extraction_commands)
            if extraction["exit_code"] != 0:
                if selected == "workbench":
                    raise workbench_transfer_error(
                        extraction, "Workbench directory extraction failed"
                    )
                raise TransferError(
                    extraction["stderr"].strip()
                    or "remote directory extraction failed"
                )
            if selected == "workbench":
                publish_started = True
                publish = workbench_exec(
                    manifest,
                    [
                        "sh",
                        "-c",
                        'set -eu; staging=$1; target=$2; '
                        'test ! -e "$target"; '
                        'inode=$(stat -c "%d:%i" "$staging"); '
                        'mv -T -n "$staging" "$target"; '
                        'test ! -e "$staging"; '
                        'test "$(stat -c "%d:%i" "$target")" = "$inode"; '
                        'test -d "$target"',
                        "cosh-lab-directory-upload-publish",
                        workbench_directory_staging,
                        remote,
                    ],
                )
                commands.append(publish)
                if publish["exit_code"] != 0:
                    fallback = (
                        "Workbench directory publish failed"
                        if publish.get("terminal_state_known") is True
                        else "Workbench directory publish state is unknown; "
                        "do not retry automatically"
                    )
                    raise workbench_transfer_error(publish, fallback)
                published = True
        if selected == "workbench":
            cleanup = workbench_exec(
                manifest,
                [
                    "sh",
                    "-c",
                    'rm -rf -- "$1"',
                    "cosh-lab-upload-cleanup",
                    workbench_staging_root,
                ],
                timeout_seconds=30,
            )
            commands.append(cleanup)
            if cleanup["exit_code"] != 0:
                raise workbench_transfer_error(
                    cleanup,
                    "upload published but Workbench staging cleanup failed",
                )
    except KeyboardInterrupt as error:
        commands.extend(getattr(error, "commands", []))
        if getattr(error, "publish_started", False):
            publish_started = True
        if getattr(error, "published", False):
            published = True
        cleanup_safe = getattr(error, "cleanup_safe", True)
        if cleanup_safe and selected != "workbench":
            try:
                cancel_result = cancel_environment_command(environment_dir, manifest)
                if cancel_result:
                    commands.append(cancel_result)
            except EcsError as cancel_error:
                commands.extend(cancel_error.commands)
                cleanup_safe = False
        if cleanup_safe:
            commands.extend(
                best_effort_remote_cleanup(
                    manifest,
                    selected,
                    cleanup_paths,
                    f"{artifacts.run_id}-interrupt-cleanup",
                    persist_invoke,
                )
            )
        for item in artifacts.manifest["temporary_remote_paths"]:
            if item["cleanup_status"] == "pending":
                item["cleanup_status"] = (
                    "attempted" if cleanup_safe else "deferred-unconfirmed-stop"
                )
        record_commands(artifacts, commands)
        if archive_root is not None:
            shutil.rmtree(archive_root, ignore_errors=True)
        if published:
            message = (
                f"upload published to {remote}; staging cleanup state is unknown; "
                "do not retry upload"
            )
        elif publish_started:
            message = "upload publish state is unknown; do not retry upload"
        elif cleanup_safe:
            message = "upload interrupted; remote cleanup attempted"
        else:
            message = "upload interrupted; cleanup deferred because stop is unconfirmed"
        payload = envelope(
            False,
            code="user-cancelled",
            message=message,
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    except (EcsError, OSError, TransferError, TransportError) as error:
        if isinstance(error, (EcsError, TransportError)):
            commands.extend(getattr(error, "commands", []))
        cleanup_safe = getattr(error, "cleanup_safe", True)
        if cleanup_safe:
            commands.extend(
                best_effort_remote_cleanup(
                    manifest,
                    selected,
                    cleanup_paths,
                    f"{artifacts.run_id}-failure-cleanup",
                    persist_invoke,
                )
            )
        for item in artifacts.manifest["temporary_remote_paths"]:
            if item["cleanup_status"] == "pending":
                item["cleanup_status"] = (
                    "attempted" if cleanup_safe else "deferred-unconfirmed-stop"
                )
        record_commands(artifacts, commands)
        if archive_root is not None:
            shutil.rmtree(archive_root, ignore_errors=True)
        message = str(error)
        if selected == "workbench" and published and "do not retry" not in message:
            if "published" in message:
                message += "; do not retry upload"
            else:
                message = (
                    f"upload published to {remote}, but cleanup failed: {message}; "
                    "do not retry upload"
                )
        elif selected == "workbench" and publish_started:
            message = (
                f"upload publish state is unknown: {message}; "
                "do not retry upload"
            )
        payload = envelope(
            False,
            code="environment-unavailable",
            message=message,
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    record_commands(artifacts, commands)
    for item in artifacts.manifest["temporary_remote_paths"]:
        item["cleanup_status"] = "cleaned"
    if archive_root is not None:
        shutil.rmtree(archive_root, ignore_errors=True)
    data = {
        "transport": selected,
        "local": str(source),
        "remote": remote,
        "kind": source_kind,
        "size": transfer_size,
        "sha256": expected,
        "probes": selection["probes"],
    }
    payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0


def run_env_download(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        destination_argument = Path(args.local).expanduser()
        if destination_argument.is_symlink():
            raise TransferError("download destination cannot be a symlink")
        destination = destination_argument.resolve()
        environment_dir, manifest = load_environment(artifact_root, args.run)
        remote = validate_remote_path(args.remote)
        destination.parent.mkdir(parents=True, exist_ok=True)
        selection, probe_records = select_operation_transport(
            manifest,
            args.transport,
            "download",
        )
    except KeyboardInterrupt as error:
        return emit_transport_setup_interrupt(args, "env-download", error)
    except (BackendError, OSError, TransferError, TransportError) as error:
        return emit_transport_setup_error(args, "env-download", error)

    artifacts = RunArtifacts(artifact_root, "env-download", repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    artifacts.manifest["capabilities"] = ["environment-operation", "transfer"]
    staging_root = Path(
        tempfile.mkdtemp(
            prefix=".cosh-lab-download-",
            dir=destination.parent,
        )
    )
    staging_root.chmod(0o700)
    staging = staging_root / "payload"
    selected = selection["selected"]
    commands = list(probe_records)
    persist_invoke = invocation_persister(environment_dir, manifest)
    directory = bool(args.directory)
    download_remote = remote
    workbench_archive_root = None
    workbench_archive_owned = False
    publish_started = False
    published = False
    artifacts.manifest["temporary_remote_paths"] = []
    artifacts.save_manifest()
    try:
        if directory:
            if selected == "workbench":
                transfer_hash = hashlib.sha256(
                    (manifest["run_id"] + "\0" + artifacts.run_id).encode()
                ).hexdigest()[:24]
                workbench_archive_root = (
                    f"/tmp/.cosh-lab-transfer-{transfer_hash}"
                )
                download_remote = (
                    f"{workbench_archive_root}/"
                    f".cosh-lab-{artifacts.run_id}-download.tar"
                )
                artifacts.manifest["temporary_remote_paths"] = [
                    {
                        "path": workbench_archive_root,
                        "cleanup_status": "ownership-unconfirmed",
                    }
                ]
                artifacts.save_manifest()
                claim = workbench_exec(
                    manifest,
                    [
                        "sh",
                        "-c",
                        'set -eu; mkdir -p "$(dirname "$1")"; '
                        'umask 077; mkdir "$1"',
                        "cosh-lab-directory-download",
                        workbench_archive_root,
                    ],
                    timeout_seconds=30,
                )
                commands.append(claim)
                if claim["exit_code"] != 0:
                    if claim.get("terminal_state_known") is True:
                        artifacts.manifest["temporary_remote_paths"][0][
                            "cleanup_status"
                        ] = "unowned"
                        artifacts.save_manifest()
                    error = workbench_transfer_error(
                        claim, "Workbench download archive claim failed"
                    )
                    error.cleanup_safe = False
                    raise error
                workbench_archive_owned = True
                artifacts.manifest["temporary_remote_paths"][0][
                    "cleanup_status"
                ] = "pending"
                archive_script = (
                    'set -eu; source=$1; archive=$2; '
                    'test -d "$source"; tar -C "$source" -cf "$archive" .'
                )
            else:
                download_remote = (
                    f"/tmp/.cosh-lab-{artifacts.run_id}-download.tar"
                )
                artifacts.manifest["temporary_remote_paths"] = [
                    {"path": download_remote, "cleanup_status": "pending"}
                ]
                archive_script = (
                    'set -eu; source=$1; archive=$2; '
                    'test -d "$source"; rm -f "$archive"; '
                    'tar -C "$source" -cf "$archive" .'
                )
            artifacts.save_manifest()
            archive_result, archive_commands = execute_in_environment(
                manifest,
                [
                    "sh",
                    "-lc",
                    archive_script,
                    "cosh-lab-directory-download",
                    remote,
                    download_remote,
                ],
                execution_id=f"{artifacts.run_id}-archive",
                on_invoke=persist_invoke,
                transport=selected,
            )
            commands.extend(archive_commands)
            if archive_result["exit_code"] != 0:
                if selected == "workbench":
                    raise workbench_transfer_error(
                        archive_result, "Workbench directory archive failed"
                    )
                raise TransferError(
                    archive_result["stderr"].strip()
                    or "remote directory archive failed"
                )
        if selected == "native":
            remote_hash = native_transfer_command(
                manifest,
                "hash",
                None,
                download_remote,
                artifacts.run_id,
            )
            transfer = native_transfer_command(
                manifest,
                "download",
                staging,
                download_remote,
                artifacts.run_id,
            )
            commands.extend((remote_hash, transfer))
            expected = parse_remote_sha256(remote_hash["stdout"])
            if remote_hash["exit_code"] != 0:
                raise TransferError("remote hash failed")
            if transfer["exit_code"] != 0:
                raise TransferError(
                    transfer["stderr"].strip() or "download failed"
                )
        elif selected in {"ssh", "proxyjump"}:
            remote_hash = ssh_remote_command(
                manifest,
                selected,
                [
                    "sh",
                    "-lc",
                    'sha256sum "$1" | awk \'{print $1}\'',
                    "cosh-lab-download",
                    download_remote,
                ],
            )
            transfer, transfer_commands = ssh_copy_with_fallback(
                manifest,
                selected,
                staging,
                download_remote,
                upload=False,
            )
            commands.extend((remote_hash, *transfer_commands))
            expected = parse_remote_sha256(remote_hash["stdout"])
            if remote_hash["exit_code"] != 0 or transfer["exit_code"] != 0:
                raise TransferError("SSH download failed")
        elif selected == "workbench":
            remote_hash = workbench_exec(
                manifest,
                [
                    "sh",
                    "-c",
                    'set -eu; digest=$(sha256sum "$1"); printf "%s\\n" "${digest%% *}"',
                    "cosh-lab-download",
                    download_remote,
                ],
            )
            commands.append(remote_hash)
            if remote_hash["exit_code"] != 0:
                raise workbench_transfer_error(
                    remote_hash, "Workbench download hash failed"
                )
            expected = parse_remote_sha256(remote_hash["stdout"])
            transfer = workbench_download_file(
                manifest,
                download_remote,
                staging,
            )
            commands.append(transfer)
            if transfer["exit_code"] != 0:
                raise workbench_transfer_error(
                    transfer, "Workbench download failed"
                )
        else:
            transfer = ecs_download_file(
                manifest,
                download_remote,
                staging,
                artifacts.run_id,
                on_invoke=persist_invoke,
            )
            commands.extend(transfer["commands"])
            expected = transfer["sha256"]
        actual = sha256_file(staging)
        if actual != expected:
            raise TransferError("downloaded file SHA-256 mismatch")
        transfer_size = staging.stat().st_size
        if directory:
            extract_directory_archive(staging, destination)
            if selected == "workbench":
                published = True
            staging.unlink()
            cleanup_command = (
                ["rm", "-rf", workbench_archive_root]
                if selected == "workbench"
                else ["rm", "-f", download_remote]
            )
            cleanup_result, cleanup_commands = execute_in_environment(
                manifest,
                cleanup_command,
                execution_id=f"{artifacts.run_id}-archive-cleanup",
                on_invoke=persist_invoke,
                transport=selected,
            )
            for item in artifacts.manifest["temporary_remote_paths"]:
                item["cleanup_status"] = "attempted"
            commands.extend(cleanup_commands)
            if cleanup_result["exit_code"] != 0:
                if selected == "workbench":
                    raise workbench_transfer_error(
                        cleanup_result,
                        "download published but Workbench remote archive cleanup failed",
                    )
                raise TransferError("remote directory archive cleanup failed")
        else:
            publish_started = selected == "workbench"
            staging.replace(destination)
            if selected == "workbench":
                published = True
    except KeyboardInterrupt as error:
        commands.extend(getattr(error, "commands", []))
        if getattr(error, "publish_started", False):
            publish_started = True
        if getattr(error, "published", False):
            published = True
        cleanup_safe = getattr(error, "cleanup_safe", True)
        if cleanup_safe and selected != "workbench":
            try:
                cancel_result = cancel_environment_command(environment_dir, manifest)
                if cancel_result:
                    commands.append(cancel_result)
            except EcsError as cancel_error:
                commands.extend(cancel_error.commands)
                cleanup_safe = False
        if (
            directory
            and cleanup_safe
            and (selected != "workbench" or workbench_archive_owned)
        ):
            cleanup_path = (
                workbench_archive_root
                if selected == "workbench"
                else download_remote
            )
            commands.extend(
                best_effort_remote_cleanup(
                    manifest,
                    selected,
                    [cleanup_path],
                    f"{artifacts.run_id}-interrupt-cleanup",
                    persist_invoke,
                )
            )
            for item in artifacts.manifest["temporary_remote_paths"]:
                if item["cleanup_status"] == "pending":
                    item["cleanup_status"] = "attempted"
        elif directory:
            for item in artifacts.manifest["temporary_remote_paths"]:
                if item["cleanup_status"] == "pending":
                    item["cleanup_status"] = "deferred-unconfirmed-stop"
        shutil.rmtree(staging_root, ignore_errors=True)
        record_commands(artifacts, commands)
        if published:
            message = (
                f"download published to {destination}; remote cleanup state is unknown; "
                "do not retry download"
            )
        elif publish_started:
            message = "download publish state is unknown; do not retry download"
        elif cleanup_safe:
            message = "download interrupted; cleanup attempted"
        else:
            message = "download interrupted; cleanup deferred because stop is unconfirmed"
        payload = envelope(
            False,
            code="user-cancelled",
            message=message,
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    except (EcsError, OSError, TransferError, TransportError) as error:
        if isinstance(error, (EcsError, TransportError)):
            commands.extend(getattr(error, "commands", []))
        if getattr(error, "publish_started", False):
            publish_started = True
        if getattr(error, "published", False):
            published = True
        cleanup_safe = getattr(error, "cleanup_safe", True)
        if (
            directory
            and cleanup_safe
            and (selected != "workbench" or workbench_archive_owned)
        ):
            cleanup_path = (
                workbench_archive_root
                if selected == "workbench"
                else download_remote
            )
            commands.extend(
                best_effort_remote_cleanup(
                    manifest,
                    selected,
                    [cleanup_path],
                    f"{artifacts.run_id}-failure-cleanup",
                    persist_invoke,
                )
            )
        if directory:
            for item in artifacts.manifest["temporary_remote_paths"]:
                if item["cleanup_status"] == "pending":
                    item["cleanup_status"] = (
                        "attempted" if cleanup_safe else "deferred-unconfirmed-stop"
                    )
        shutil.rmtree(staging_root, ignore_errors=True)
        record_commands(artifacts, commands)
        message = str(error)
        if selected == "workbench" and published and "do not retry" not in message:
            if "published" in message:
                message += "; do not retry download"
            else:
                message = (
                    f"download published to {destination}, but cleanup failed: {message}; "
                    "do not retry download"
                )
        elif selected == "workbench" and publish_started:
            message = (
                f"download publish state is unknown: {message}; "
                "do not retry download"
            )
        payload = envelope(
            False,
            code="evidence-incomplete",
            message=message,
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    record_commands(artifacts, commands)
    for item in artifacts.manifest["temporary_remote_paths"]:
        item["cleanup_status"] = "cleaned"
    shutil.rmtree(staging_root, ignore_errors=True)
    data = {
        "transport": selected,
        "remote": remote,
        "local": str(destination),
        "kind": "directory" if directory else "file",
        "size": transfer_size,
        "sha256": expected,
        "probes": selection["probes"],
    }
    payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0


def run_env_hash(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        environment_dir, manifest = load_environment(artifact_root, args.run)
        remote = validate_remote_path(args.remote)
        selection, probe_records = select_operation_transport(
            manifest,
            args.transport,
            "hash",
        )
    except KeyboardInterrupt as error:
        return emit_transport_setup_interrupt(args, "env-hash", error)
    except (BackendError, TransferError, TransportError) as error:
        return emit_transport_setup_error(args, "env-hash", error)
    artifacts = RunArtifacts(artifact_root, "env-hash", repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    selected = selection["selected"]
    commands = list(probe_records)
    persist_invoke = invocation_persister(environment_dir, manifest)
    try:
        if selected == "native":
            result = native_transfer_command(
                manifest,
                "hash",
                None,
                remote,
                artifacts.run_id,
            )
            commands.append(result)
        elif selected in {"ssh", "proxyjump"}:
            result = ssh_remote_command(
                manifest,
                selected,
                [
                    "sh",
                    "-lc",
                    'sha256sum "$1" | awk \'{print $1}\'',
                    "cosh-lab-hash",
                    remote,
                ],
            )
            commands.append(result)
        elif selected == "workbench":
            result = workbench_exec(
                manifest,
                [
                    "sh",
                    "-lc",
                    'set -eu; digest=$(sha256sum "$1"); '
                    'printf "%s\\n" "${digest%% *}"',
                    "cosh-lab-hash",
                    remote,
                ],
            )
            commands.append(result)
        else:
            result = ecs_exec(
                manifest,
                [
                    "sh",
                    "-lc",
                    'sha256sum "$1" | awk \'{print $1}\'',
                    "cosh-lab-hash",
                    remote,
                ],
                execution_id=artifacts.run_id,
                on_invoke=persist_invoke,
            )
            commands.extend(result["commands"])
        if result["exit_code"] != 0:
            raise TransferError(
                result["stderr"].strip() or "remote hash failed"
            )
        digest = parse_remote_sha256(result["stdout"])
    except KeyboardInterrupt as error:
        commands.extend(getattr(error, "commands", []))
        cleanup_safe = getattr(error, "cleanup_safe", True)
        cancel_assistant = cleanup_safe and selected != "workbench"
        if cancel_assistant:
            cancel_result = cancel_environment_command(environment_dir, manifest)
            if cancel_result:
                commands.append(cancel_result)
        record_commands(artifacts, commands)
        payload = envelope(
            False,
            code="user-cancelled",
            message=(
                "hash interrupted; cancellation attempted"
                if cancel_assistant
                else "hash interrupted; backend command state is unknown"
            ),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    except (EcsError, TransferError) as error:
        if isinstance(error, EcsError):
            commands.extend(error.commands)
        record_commands(artifacts, commands)
        payload = envelope(
            False,
            code="environment-unavailable",
            message=str(error),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    record_commands(artifacts, commands)
    data = {
        "transport": selected,
        "remote": remote,
        "sha256": digest,
        "probes": selection["probes"],
    }
    payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0


def run_env_transport_check(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        environment_dir, manifest = load_environment(artifact_root, args.run)
        candidates = transport_candidates(manifest, "exec")
    except (BackendError, TransportError) as error:
        payload = envelope(False, code="environment-unavailable", message=str(error))
        emit(payload, args.output)
        return 1
    artifacts = RunArtifacts(artifact_root, "env-transport-check", repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    persist_invoke = invocation_persister(environment_dir, manifest)
    probes = []
    commands = []
    for candidate in candidates:
        if candidate == "native":
            backend = manifest["backend"]
            result = run_bridge(
                bridge_path_for(backend),
                "status",
                {**os.environ, **backend["environment"]},
            )
            result.update(
                {
                    "transport": candidate,
                    "ok": result["exit_code"] == 0,
                    "probe": True,
                }
            )
            commands.append(result)
        elif candidate == "workbench":
            try:
                result = workbench_exec(
                    manifest, ["true"], timeout_seconds=30
                )
                result.update(
                    {
                        "ok": result["exit_code"] == 0,
                        "probe": True,
                    }
                )
                commands.append(result)
            except KeyboardInterrupt as error:
                commands.extend(getattr(error, "commands", []))
                result = {
                    "transport": "workbench",
                    "ok": False,
                    "exit_code": 130,
                    "probe": True,
                    "error": "interrupted",
                }
                probes.append(result)
                record_commands(artifacts, commands)
                payload = envelope(
                    False,
                    code="user-cancelled",
                    message="transport check interrupted; backend command state is unknown",
                    run_dir=artifacts.run_dir,
                )
                payload["data"] = {"preferred": None, "probes": probes}
                artifacts.complete(payload)
                emit(payload, args.output)
                return 1
            except TransportError as error:
                result = {
                    "transport": "workbench",
                    "ok": False,
                    "exit_code": 1,
                    "probe": True,
                    "error": str(error),
                }
        elif candidate in {"ssh", "proxyjump"}:
            result = ssh_remote_command(
                manifest,
                candidate,
                ["true"],
            )
            result.update(
                {
                    "ok": result["exit_code"] == 0,
                    "probe": True,
                }
            )
            commands.append(result)
        else:
            try:
                checked = ecs_exec(
                    manifest,
                    ["true"],
                    execution_id=f"{artifacts.run_id}-assistant-check",
                    on_invoke=persist_invoke,
                )
                commands.extend(checked["commands"])
                result = {
                    "transport": "assistant",
                    "ok": checked["exit_code"] == 0,
                    "exit_code": checked["exit_code"],
                    "probe": True,
                    "invoke_id": checked.get("invoke_id"),
                }
            except KeyboardInterrupt as error:
                commands.extend(getattr(error, "commands", []))
                cancel_result = cancel_environment_command(
                    environment_dir,
                    manifest,
                )
                if cancel_result:
                    commands.append(cancel_result)
                result = {
                    "transport": "assistant",
                    "ok": False,
                    "exit_code": 130,
                    "probe": True,
                    "error": "interrupted; cancellation attempted",
                }
            except EcsError as error:
                commands.extend(error.commands)
                result = {
                    "transport": "assistant",
                    "ok": False,
                    "exit_code": 1,
                    "probe": True,
                    "error": str(error),
                }
        probes.append(result)
    record_commands(artifacts, commands)
    preferred = next(
        (item["transport"] for item in probes if item.get("ok")),
        None,
    )
    data = {"preferred": preferred, "probes": probes}
    payload = (
        envelope(True, data=data, run_dir=artifacts.run_dir)
        if preferred is not None
        else envelope(
            False,
            code="environment-unavailable",
            message="no environment transport is usable",
            run_dir=artifacts.run_dir,
        )
    )
    if not payload["ok"]:
        payload["data"] = data
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0 if payload["ok"] else 1


def run_environment_diagnostic(
    args: argparse.Namespace,
    *,
    operation: str,
    script: str,
    artifact_name: str | None = None,
) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        environment_dir, manifest = load_environment(artifact_root, args.run)
    except BackendError as error:
        payload = envelope(False, code="environment-unavailable", message=str(error))
        emit(payload, args.output)
        return 1
    artifacts = RunArtifacts(artifact_root, operation, repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    persist_invoke = invocation_persister(environment_dir, manifest)
    command = ["sh", "-lc", script]
    try:
        result, commands = execute_in_environment(
            manifest,
            command,
            execution_id=artifacts.run_id,
            on_invoke=persist_invoke,
            transport=args.transport,
        )
    except KeyboardInterrupt as error:
        commands = list(getattr(error, "commands", []))
        cleanup_safe = getattr(error, "cleanup_safe", True)
        cancel_assistant = (
            cleanup_safe and interrupted_transport(error) != "workbench"
        )
        if cancel_assistant:
            cancel_result = cancel_environment_command(environment_dir, manifest)
            if cancel_result:
                commands.append(cancel_result)
        record_commands(artifacts, commands)
        payload = envelope(
            False,
            code="user-cancelled",
            message=(
                f"{operation} interrupted; cancellation attempted"
                if cancel_assistant
                else f"{operation} interrupted; backend command state is unknown"
            ),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    except (EcsError, TransportError) as error:
        commands = list(getattr(error, "commands", []))
        record_commands(artifacts, commands)
        payload = envelope(
            False,
            code="environment-unavailable",
            message=str(error),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    record_commands(artifacts, commands)
    sanitized_stdout = redact_text(result["stdout"])
    sanitized_stderr = redact_text(result["stderr"])
    if artifact_name is not None:
        (artifacts.run_dir / artifact_name).write_text(sanitized_stdout)
    data = {
        "transport": result["transport"],
        "exit_code": result["exit_code"],
        "stdout": sanitized_stdout,
        "stderr": sanitized_stderr,
        "artifact": artifact_name,
    }
    payload = (
        envelope(True, data=data, run_dir=artifacts.run_dir)
        if result["exit_code"] == 0
        else envelope(
            False,
            code="environment-unavailable",
            message=sanitized_stderr.strip() or f"{operation} failed",
            run_dir=artifacts.run_dir,
        )
    )
    if not payload["ok"]:
        payload["data"] = data
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0 if payload["ok"] else 1


def run_env_inspect(args: argparse.Namespace) -> int:
    return run_environment_diagnostic(
        args,
        operation="env-inspect",
        script=(
            "set -u; printf '== uname ==\\n'; uname -a; "
            "printf '== identity ==\\n'; id; "
            "printf '== working-directory ==\\n'; pwd; "
            "printf '== filesystem ==\\n'; df -h; "
            "printf '== tools ==\\n'; "
            "for tool in cosh-shell cargo rustc git; do "
            "command -v \"$tool\" 2>/dev/null || true; done"
        ),
    )


def run_env_collect(args: argparse.Namespace) -> int:
    scripts = {
        "failure": (
            "set -u; printf '== uname ==\\n'; uname -a; "
            "printf '== identity ==\\n'; id; "
            "printf '== filesystem ==\\n'; df -h; "
            "printf '== memory ==\\n'; "
            "(free -h 2>/dev/null || vm_stat 2>/dev/null || true); "
            "printf '== processes ==\\n'; ps -eo pid,ppid,user,comm; "
            "printf '== recent-kernel ==\\n'; "
            "(dmesg 2>/dev/null | tail -n 100 || true)"
        ),
        "network": (
            "set -u; printf '== resolver ==\\n'; cat /etc/resolv.conf; "
            "printf '== addresses ==\\n'; "
            "(ip address 2>/dev/null || ifconfig 2>/dev/null || true); "
            "printf '== routes ==\\n'; "
            "(ip route 2>/dev/null || route -n 2>/dev/null || true); "
            "printf '== proxies ==\\n'; env | grep -iE '^(http|https|no)_proxy=' || true"
        ),
        "toolchain": (
            "set -u; printf '== tools ==\\n'; "
            "for tool in cosh-shell cargo rustc rustup git gcc clang make; do "
            "printf '%s: ' \"$tool\"; command -v \"$tool\" 2>/dev/null || true; done; "
            "printf '== versions ==\\n'; "
            "(rustc -Vv 2>/dev/null || true); (cargo -V 2>/dev/null || true); "
            "(git --version 2>/dev/null || true)"
        ),
        "system": (
            "set -u; printf '== init ==\\n'; ps -p 1 -o pid,comm,args; "
            "printf '== systemd ==\\n'; "
            "(systemctl is-system-running 2>/dev/null || true); "
            "(systemctl --failed --no-pager 2>/dev/null || true); "
            "printf '== journal ==\\n'; "
            "(journalctl -n 100 --no-pager 2>/dev/null || true)"
        ),
    }
    return run_environment_diagnostic(
        args,
        operation="env-collect",
        script=scripts[args.preset],
        artifact_name=f"{args.preset}-collection.txt",
    )


def read_run_manifest(run_dir: Path) -> dict[str, Any]:
    manifest_path = run_dir / "run.json"
    if not manifest_path.is_file():
        raise ValueError(f"run manifest not found: {manifest_path}")
    manifest = json.loads(manifest_path.read_text())
    if manifest.get("run_id") != run_dir.name:
        raise ValueError(f"run id does not match directory: {run_dir}")
    return manifest


def run_runs_list(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root).expanduser().resolve()
    runs = []
    if artifact_root.is_dir():
        for run_dir in sorted(artifact_root.iterdir(), reverse=True):
            if not run_dir.is_dir() or run_dir.name.startswith("."):
                continue
            try:
                manifest = read_run_manifest(run_dir)
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            runs.append(
                {
                    "run_id": manifest["run_id"],
                    "operation": manifest.get("operation"),
                    "state": manifest.get("state"),
                    "environment_ref": manifest.get("environment_ref"),
                    "cleanup": manifest.get("cleanup", {}).get("status"),
                    "started_at": manifest.get("started_at"),
                    "completed_at": manifest.get("completed_at"),
                    "run_dir": str(run_dir),
                }
            )
    payload = envelope(True, data={"runs": runs, "count": len(runs)})
    emit(payload, args.output)
    return 0


def run_runs_resume(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root).expanduser().resolve()
    try:
        manifest = read_run_manifest(artifact_root / args.run)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        emit(envelope(False, code="run-unavailable", message=str(error)), args.output)
        return 1
    recommendations = [f"inspect {artifact_root / args.run / 'report.md'}"]
    if manifest.get("operation") == "env-up":
        recommendations = [
            f"cosh-lab env status --run {args.run}",
            f"cosh-lab env transport check --run {args.run}",
            f"cosh-lab env down --run {args.run}",
        ]
    elif "acceptance" in manifest.get("capabilities", []):
        recommendations = [
            f"cosh-lab evidence verify {artifact_root / args.run}"
        ]
    payload = envelope(
        True,
        data={
            "run_id": args.run,
            "state": manifest.get("state"),
            "recommendations": recommendations,
        },
    )
    emit(payload, args.output)
    return 0


def run_runs_gc(args: argparse.Namespace) -> int:
    if args.older_than_hours <= 0:
        emit(
            envelope(
                False,
                code="invalid-retention",
                message="older-than-hours must be greater than zero",
            ),
            args.output,
        )
        return 1
    artifact_root = Path(args.artifact_root).expanduser().resolve()
    cutoff = time.time() - args.older_than_hours * 3600
    candidates = []
    referenced_runs = set()
    if artifact_root.is_dir():
        for run_dir in artifact_root.iterdir():
            if not run_dir.is_dir() or run_dir.name.startswith("."):
                continue
            try:
                manifest = read_run_manifest(run_dir)
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            reference = manifest.get("environment_ref")
            if reference not in {None, "host"}:
                referenced_runs.add(reference)
    if artifact_root.is_dir():
        for run_dir in artifact_root.iterdir():
            if not run_dir.is_dir() or run_dir.name.startswith("."):
                continue
            try:
                manifest = read_run_manifest(run_dir)
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            cleanup = manifest.get("cleanup", {}).get("status")
            safe = (
                manifest.get("state") in {"completed", "failed"}
                and cleanup in {"not-applicable", "cleaned"}
                and not manifest.get("resources")
                and manifest["run_id"] not in referenced_runs
                and run_dir.stat().st_mtime < cutoff
            )
            if safe:
                candidates.append(run_dir)
    removed = []
    if args.apply:
        for run_dir in candidates:
            shutil.rmtree(run_dir)
            removed.append(run_dir.name)
    payload = envelope(
        True,
        data={
            "mode": "apply" if args.apply else "dry-run",
            "candidates": [path.name for path in candidates],
            "removed": removed,
        },
    )
    emit(payload, args.output)
    return 0


def run_gate_evaluate(args: argparse.Namespace) -> int:
    release = {}
    profile_path = None
    if args.profile:
        try:
            profile_path = resolve_profile_arg(args.profile)
            profile = load_profile(profile_path)
        except ProfileError as error:
            emit(envelope(False, code="invalid-profile", message=str(error)), args.output)
            return 1
        release = profile.get("release", {})
        if not release:
            emit(
                envelope(
                    False,
                    code="invalid-profile",
                    message="gate profile requires a release table",
                ),
                args.output,
            )
            return 1
    required_scopes = set(args.require_scope) | set(
        release.get("required_scopes", [])
    )
    required_backends = set(args.require_backend) | set(
        release.get("required_backends", [])
    )
    required_arches = set(args.require_arch) | set(
        release.get("required_arches", [])
    )
    required_cases = set(release.get("required_cases", []))
    require_real_provider = args.require_real_provider or release.get(
        "require_real_provider", False
    )
    manifests = []
    errors = []
    categories = set()
    scopes = set()
    case_ids = set()
    execution_evidence = set()
    backends = set()
    architectures = set()
    ecs_required_cleanup = set()
    ecs_cleanup_proofs = set()
    verdict = "Go"
    for value in args.run_dir:
        run_dir = Path(value).expanduser().resolve()
        try:
            manifest = read_run_manifest(run_dir)
            result = json.loads((run_dir / "result.json").read_text())
        except (OSError, ValueError, json.JSONDecodeError) as error:
            errors.append(str(error))
            verdict = "Blocked"
            continue
        manifests.append(manifest["run_id"])
        categories.add(
            "acceptance"
            if "acceptance" in manifest.get("capabilities", [])
            else manifest.get("operation", "")
        )
        result_data = result.get("data") or {}
        if (
            manifest.get("operation") == "env-down"
            and result.get("ok")
            and result_data.get("remaining") == 0
        ):
            environment_ref = manifest.get("environment_ref")
            try:
                proof_environment = read_run_manifest(run_dir.parent / environment_ref)
                instance_id = proof_environment["resources"][0]["id"]
                records = [
                    json.loads(line)
                    for line in (run_dir / "commands.log").read_text().splitlines()
                ]
            except (OSError, ValueError, IndexError, KeyError, json.JSONDecodeError):
                records = []
                instance_id = None
            by_id = 0
            by_run = 0
            for record in records:
                argv = record.get("argv", [])
                payload_instances = (
                    record.get("payload", {})
                    .get("Instances", {})
                    .get("Instance", [None])
                )
                if (
                    record.get("exit_code") != 0
                    or "DescribeInstances" not in argv
                    or payload_instances != []
                ):
                    continue
                if instance_id and json.dumps([instance_id]) in argv:
                    by_id += 1
                if environment_ref in argv and "run-id" in argv:
                    by_run += 1
            if by_id >= 3 and by_run >= 3:
                ecs_cleanup_proofs.add(environment_ref)
        if result_data.get("scope"):
            scopes.add(result_data["scope"])
        case = result_data.get("case")
        canonical_acceptance = (
            "acceptance" in manifest.get("capabilities", [])
            and isinstance(case, dict)
            and case.get("source") == "canonical"
            and case.get("logical_path")
        )
        if canonical_acceptance and case.get("id"):
            case_ids.add(case["id"])
        execution = result_data.get("execution_evidence")
        if execution and (
            execution != "real-provider"
            or (
                canonical_acceptance
                and "real-provider" in manifest.get("capabilities", [])
            )
        ):
            execution_evidence.add(result_data["execution_evidence"])
        environment_ref = manifest.get("environment_ref")
        environment_manifest = manifest if manifest.get("operation") == "env-up" else None
        linked_environment = manifest.get("operation") != "env-up"
        if environment_ref not in {None, "host"}:
            try:
                environment_manifest = read_run_manifest(
                    run_dir.parent / environment_ref
                )
            except (OSError, ValueError, json.JSONDecodeError) as error:
                errors.append(str(error))
                if verdict == "Go":
                    verdict = "Blocked"
        if environment_manifest:
            backend = environment_manifest.get("backend", {}).get("kind")
            arch = environment_manifest.get("profile", {}).get("arch")
            if backend and linked_environment:
                backends.add(backend)
            if arch and linked_environment:
                architectures.add(arch)
            environment_dir = run_dir.parent / environment_manifest["run_id"]
            environment_errors = verify_run(environment_dir)
            if environment_errors and verdict == "Go":
                verdict = "Blocked"
            errors.extend(
                f"{environment_manifest['run_id']}: {item}"
                for item in environment_errors
            )
            if environment_manifest.get("state") not in {"completed", "retained"}:
                if verdict == "Go":
                    verdict = "Blocked"
                errors.append(
                    f"{environment_manifest['run_id']}: environment state is not terminal"
                )
            if (
                backend == "ecs"
                and linked_environment
            ):
                ecs_required_cleanup.add(environment_manifest["run_id"])
                if (
                    environment_manifest.get("cleanup", {}).get("status") != "cleaned"
                    and verdict == "Go"
                ):
                    errors.append(
                        f"{environment_manifest['run_id']}: ECS cleanup is not cleaned"
                    )
                    verdict = "Blocked"
        cleanup = manifest.get("cleanup", {}).get("status")
        if not result.get("ok") or cleanup == "cleanup-failed":
            verdict = "No-Go"
        elif manifest.get("state") not in {"completed"} and verdict == "Go":
            verdict = "Blocked"
        evidence_errors = verify_run(run_dir)
        if evidence_errors and verdict == "Go":
            verdict = "Blocked"
        errors.extend(f"{manifest['run_id']}: {item}" for item in evidence_errors)
    missing = sorted(set(args.require) - categories)
    if missing and verdict == "Go":
        verdict = "Blocked"
    errors.extend(f"missing required gate: {item}" for item in missing)
    for label, required, actual in (
        ("scope", required_scopes, scopes),
        ("backend", required_backends, backends),
        ("architecture", required_arches, architectures),
        ("case", required_cases, case_ids),
    ):
        absent = sorted(required - actual)
        if absent and verdict == "Go":
            verdict = "Blocked"
        errors.extend(f"missing required {label}: {item}" for item in absent)
    if require_real_provider and "real-provider" not in execution_evidence:
        if verdict == "Go":
            verdict = "Blocked"
        errors.append("missing required execution evidence: real-provider")
    missing_cleanup = sorted(ecs_required_cleanup - ecs_cleanup_proofs)
    if missing_cleanup and verdict == "Go":
        verdict = "Blocked"
    errors.extend(
        f"missing ECS absence proof from env-down: {run_id}"
        for run_id in missing_cleanup
    )
    payload = envelope(
        True,
        data={
            "verdict": verdict,
            "runs": manifests,
            "errors": errors,
            "scopes": sorted(scopes),
            "cases": sorted(case_ids),
            "execution_evidence": sorted(execution_evidence),
            "backends": sorted(backends),
            "architectures": sorted(architectures),
            "release_profile": str(profile_path) if profile_path else None,
        },
    )
    emit(payload, args.output)
    return 0 if verdict == "Go" else 1


def run_env_shell(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        _, environment_manifest = load_environment(artifact_root, args.run)
    except BackendError as error:
        payload = envelope(False, code="environment-unavailable", message=str(error))
        emit(payload, args.output)
        return 1
    backend = environment_manifest["backend"]
    if backend.get("kind") == "ecs":
        probe_records = []

        def probe(candidate: str) -> dict[str, Any]:
            argv = ssh_argv(backend, candidate, ["true"])
            started = time.monotonic()
            completed = subprocess.run(
                argv,
                text=True,
                capture_output=True,
                check=False,
            )
            record = {
                "transport": candidate,
                "ok": completed.returncode == 0,
                "argv": argv,
                "exit_code": completed.returncode,
                "duration_seconds": round(time.monotonic() - started, 6),
                "stdout": completed.stdout,
                "stderr": completed.stderr,
                "probe": True,
            }
            probe_records.append(record)
            return record

        try:
            selection = resolve_transport(
                environment_manifest,
                args.transport,
                "shell",
                probe,
            )
        except TransportError as error:
            payload = envelope(
                False,
                code="environment-unavailable",
                message=str(error),
            )
            emit(payload, args.output)
            return 1
        artifacts = RunArtifacts(artifact_root, "env-shell", repo_metadata())
        artifacts.manifest["environment_ref"] = args.run
        argv = ssh_argv(backend, selection["selected"])
        started = time.monotonic()
        completed = subprocess.run(argv, check=False)
        result = {
            "argv": argv,
            "exit_code": completed.returncode,
            "duration_seconds": round(time.monotonic() - started, 6),
            "stdout": "",
            "stderr": "",
            "transport": selection["selected"],
        }
        record_commands(artifacts, [*probe_records, result])
        data = {
            "exit_code": result["exit_code"],
            "interactive": True,
            "transport": selection["selected"],
            "probes": selection["probes"],
            "stdout": "",
            "stderr": "",
        }
        payload = (
            envelope(True, data=data, run_dir=artifacts.run_dir)
            if result["exit_code"] == 0
            else envelope(
                False,
                code="environment-unavailable",
                message="ECS shell failed",
                run_dir=artifacts.run_dir,
            )
        )
        if not payload["ok"]:
            payload["data"] = data
        artifacts.complete(payload)
        emit(payload, args.output)
        return 0 if result["exit_code"] == 0 else 1

    artifacts = RunArtifacts(artifact_root, "env-shell", repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    try:
        selection = native_transport_selection(
            environment_manifest,
            args.transport,
            "shell",
        )
    except TransportError as error:
        payload = envelope(
            False,
            code="environment-unavailable",
            message=str(error),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    result = run_bridge_interactive(
        bridge_path_for(backend),
        {**os.environ, **backend["environment"]},
    )
    append_command(artifacts.run_dir, artifacts.manifest, result)
    data = {
        "exit_code": result["exit_code"],
        "interactive": True,
        "transport": selection["selected"],
        "probes": selection["probes"],
        "stdout": result["stdout"],
        "stderr": result["stderr"],
    }
    payload = (
        envelope(True, data=data, run_dir=artifacts.run_dir)
        if result["exit_code"] == 0
        else envelope(
            False,
            code="environment-unavailable",
            message="backend shell failed",
            run_dir=artifacts.run_dir,
        )
    )
    if not payload["ok"]:
        payload["data"] = data
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0 if result["exit_code"] == 0 else 1


def run_env_status(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        _, environment_manifest = load_environment(artifact_root, args.run)
    except BackendError as error:
        payload = envelope(False, code="environment-unavailable", message=str(error))
        emit(payload, args.output)
        return 1

    artifacts = RunArtifacts(artifact_root, "env-status", repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    backend = environment_manifest["backend"]
    try:
        if backend.get("kind") == "ecs":
            status = ecs_status(environment_manifest)
            commands = status["commands"]
            result = {
                "exit_code": 0,
                "stdout": status["state"] + "\n",
                "stderr": "",
            }
        else:
            result = run_bridge(
                bridge_path_for(backend),
                "status",
                {**os.environ, **backend["environment"]},
            )
            commands = [result]
    except EcsError as error:
        record_commands(artifacts, error.commands)
        payload = envelope(
            False,
            code="environment-unavailable",
            message=str(error),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    record_commands(artifacts, commands)
    data = {
        "state": environment_manifest["state"],
        "cleanup": environment_manifest["cleanup"],
        "exit_code": result["exit_code"],
        "stdout": result["stdout"],
        "stderr": result["stderr"],
    }
    if result["exit_code"] == 0:
        payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    else:
        payload = envelope(
            False,
            code="environment-unavailable",
            message=result["stderr"].strip() or "backend status failed",
            run_dir=artifacts.run_dir,
        )
        payload["data"] = data
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0 if result["exit_code"] == 0 else 1


def run_env_transport_refresh(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        environment_dir, _ = load_environment(artifact_root, args.run)
    except BackendError as error:
        payload = envelope(False, code="environment-unavailable", message=str(error))
        emit(payload, args.output)
        return 1

    artifacts = RunArtifacts(artifact_root, "env-transport-refresh", repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    with environment_refresh_lock(environment_dir):
        try:
            _, environment_manifest = load_environment(artifact_root, args.run)
        except BackendError as error:
            payload = envelope(
                False,
                code="environment-unavailable",
                message=str(error),
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        return run_env_transport_refresh_locked(
            args,
            artifacts,
            environment_dir,
            environment_manifest,
        )


def run_env_transport_refresh_locked(
    args: argparse.Namespace,
    artifacts: RunArtifacts,
    environment_dir: Path,
    environment_manifest: dict[str, Any],
) -> int:
    backend = environment_manifest.get("backend", {})
    transport = backend.get("transport", {})
    if backend.get("kind") != "ecs":
        payload = envelope(
            False,
            code="environment-unavailable",
            message="transport refresh requires an ECS environment",
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    if not isinstance(transport, dict):
        payload = envelope(
            False,
            code="environment-unavailable",
            message="transport refresh requires a transport manifest",
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    if args.route == "proxyjump-public" and (
        not isinstance(transport.get("proxy_jump"), str)
        or not transport["proxy_jump"]
    ):
        payload = envelope(
            False,
            code="environment-unavailable",
            message="proxyjump-public refresh requires an existing ProxyJump",
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    if args.route == "direct-public" and backend.get(
        "internet_max_bandwidth_out"
    ) != 1:
        payload = envelope(
            False,
            code="environment-unavailable",
            message="direct-public refresh requires owner bandwidth 1",
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1

    file_overrides = {}
    for field in ("identity_file", "known_hosts_file"):
        value = getattr(args, field, None)
        if value is None:
            continue
        try:
            path = Path(value).expanduser().resolve()
            if not path.is_file():
                raise ValueError("path must be an existing regular file")
        except (OSError, ValueError, RuntimeError) as error:
            payload = envelope(
                False,
                code="environment-unavailable",
                message=f"invalid --{field.replace('_', '-')}: {error}",
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        file_overrides[field] = str(path)

    try:
        endpoint = ecs_public_endpoint(
            environment_manifest,
            require_security_group=args.route == "direct-public",
        )
    except EcsError as error:
        record_commands(artifacts, error.commands)
        payload = envelope(
            False,
            code="environment-unavailable",
            message=str(error),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1

    commands = endpoint["commands"]
    before = copy.deepcopy(transport)
    after = copy.deepcopy(before)
    after.update(file_overrides)
    if args.route == "direct-public":
        after.pop("private_host", None)
        after.pop("proxy_jump", None)
        after["public_host"] = endpoint["public_host"]
    else:
        after["private_host"] = endpoint["public_host"]
    payload_bytes = json.dumps(
        endpoint["payload"], sort_keys=True, separators=(",", ":")
    ).encode()
    receipt = {
        "schema_version": 1,
        "route": args.route,
        "environment_run_id": args.run,
        "instance_id": endpoint["instance_id"],
        "before": before,
        "after": after,
        "describe_argv": commands[0]["argv"],
        "describe_payload_sha256": hashlib.sha256(payload_bytes).hexdigest(),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    updated = copy.deepcopy(environment_manifest)
    updated["backend"]["transport"] = after
    updated.setdefault("transport_refreshes", []).append(receipt)
    try:
        commit_environment_refresh(environment_dir, updated, commands[0])
    except OSError as error:
        payload = envelope(
            False,
            code="environment-unavailable",
            message=f"transport refresh manifest update failed: {error}",
            run_dir=artifacts.run_dir,
        )
        record_commands(artifacts, commands)
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1

    record_commands(artifacts, commands)
    data = {
        "environment_run_id": args.run,
        "instance_id": endpoint["instance_id"],
        "route": args.route,
        "before": before,
        "after": after,
        "receipt": receipt,
    }
    payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0


def run_env_auth_check(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        environment_dir, environment_manifest = load_environment(
            artifact_root, args.run
        )
    except BackendError as error:
        payload = envelope(False, code="environment-unavailable", message=str(error))
        emit(payload, args.output)
        return 1

    artifacts = RunArtifacts(artifact_root, "env-auth-check", repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    backend = environment_manifest["backend"]
    persist_invoke = invocation_persister(
        environment_dir,
        environment_manifest,
    )

    registry_script = (
        "set -eu; "
        'core=${COSH_CORE_BIN:-${CARGO_TARGET_DIR:-target}/debug/cosh-core}; test -x "$core"; '
        "printf '%s\\n' "
        '\'{"type":"registry_request","request_id":"cosh-lab-auth",'
        '"domain":"auth","action":"state","params":null}\' '
        '| "$core" --registry --bare'
    )

    def registry_check() -> tuple[dict[str, Any], list[dict[str, Any]]]:
        result, commands = execute_in_environment(
            environment_manifest,
            ["sh", "-lc", registry_script],
            execution_id=f"{artifacts.run_id}-registry",
            on_invoke=persist_invoke,
        )
        response: dict[str, Any] = {}
        for line in reversed(result["stdout"].splitlines()):
            try:
                candidate = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(candidate, dict):
                response = candidate
                break
        data = response.get("data", {}) if response.get("success") is True else {}
        active_provider = data.get("active_provider")
        saved_providers = data.get("saved_providers", [])
        active = next(
            (
                provider
                for provider in saved_providers
                if isinstance(provider, dict)
                and (
                    provider.get("provider_id") == active_provider
                    or provider.get("active") is True
                )
            ),
            {},
        )
        return {
            "registry_ok": result["exit_code"] == 0 and bool(data),
            "effective_auth_required": data.get("effective_auth_required"),
            "resolved_provider": active_provider,
            "model": active.get("model"),
            "adapter_type": active.get("provider_type"),
            # cosh-core reports auth_source=null for a plain config-file API
            # key while has_api_key/source still prove the credential chain;
            # derive a stable label so the trusted-preflight completeness
            # check does not reject the common private_copy setup.
            "auth_source": active.get("auth_source")
            or (
                f"{active.get('source', 'config')}:api_key"
                if active.get("has_api_key")
                else None
            ),
        }, commands

    def persist_auth_preflight(data: dict[str, Any]) -> None:
        with environment_refresh_lock(environment_dir):
            current = json.loads((environment_dir / "run.json").read_text())
            current["auth_preflight"] = {
                "source_run_id": artifacts.run_id,
                "checked_at": artifacts.manifest["completed_at"],
                "effective_auth_required": data.get("effective_auth_required"),
                "resolved_provider": data.get("resolved_provider"),
                "model": data.get("model"),
                "adapter_type": data.get("adapter_type"),
                "auth_source": data.get("auth_source"),
            }
            write_json(environment_dir / "run.json", current)
            refresh_checksums(environment_dir)
            environment_manifest.clear()
            environment_manifest.update(current)

    if backend.get("kind") == "ecs":
        script = (
            "set -eu; "
            "token=$(curl -fsS -X PUT "
            "-H 'X-aliyun-ecs-metadata-token-ttl-seconds: 60' "
            "http://100.100.100.200/latest/api/token); "
            'role=$(curl -fsS -H "X-aliyun-ecs-metadata-token: $token" '
            "http://100.100.100.200/latest/meta-data/ram/security-credentials/); "
            'test -n "$role"; '
            "printf "
            '\'{"metadata_hardened":true,"actual_ram_role_name":"%s"}\\n\' '
            '"$role"'
        )
        metadata_commands = []
        try:
            result, metadata_commands = execute_in_environment(
                environment_manifest,
                ["sh", "-lc", script],
                execution_id=f"{artifacts.run_id}-metadata",
                on_invoke=persist_invoke,
            )
            registry, registry_commands = registry_check()
        except KeyboardInterrupt as error:
            commands = [
                *metadata_commands,
                *getattr(error, "commands", []),
            ]
            if (
                getattr(error, "cleanup_safe", True)
                and interrupted_transport(error) != "workbench"
            ):
                cancel_result = cancel_environment_command(
                    environment_dir,
                    environment_manifest,
                )
                if cancel_result:
                    commands.append(cancel_result)
            record_commands(artifacts, commands)
            payload = envelope(
                False,
                code="user-cancelled",
                message="auth check interrupted; backend command state is unknown",
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        except (EcsError, TransportError) as error:
            record_commands(
                artifacts,
                [*metadata_commands, *getattr(error, "commands", [])],
            )
            payload = envelope(
                False,
                code="auth-blocked",
                message=str(error),
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        record_commands(artifacts, [*metadata_commands, *registry_commands])
        report: dict[str, Any] = {}
        for line in reversed(result["stdout"].splitlines()):
            try:
                candidate = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(candidate, dict):
                report = candidate
                break
        data = {
            **report,
            "ram_role_name": backend.get("ram_role_name"),
            "ram_role_available": (
                report.get("actual_ram_role_name") == backend.get("ram_role_name")
            ),
            **registry,
            "provider_reachable": None,
        }
        ok = (
            result["exit_code"] == 0
            and report.get("metadata_hardened") is True
            and data["ram_role_available"] is True
            and registry["registry_ok"] is True
            and registry["effective_auth_required"] is False
        )
        payload = (
            envelope(True, data=data, run_dir=artifacts.run_dir)
            if ok
            else envelope(
                False,
                code="auth-blocked",
                message="ECS metadata or RAM Role check failed",
                run_dir=artifacts.run_dir,
            )
        )
        if not ok:
            payload["data"] = data
        artifacts.complete(payload)
        if ok:
            persist_auth_preflight(data)
        emit(payload, args.output)
        return 0 if ok else 1

    source_root_value = backend.get("auth_source_path")
    recorded_hashes = backend.get("auth_source_hashes", {})
    current_hashes: dict[str, str | None] = {}
    if source_root_value:
        source_root = Path(source_root_value)
        for relative in recorded_hashes:
            source = source_root / relative
            current_hashes[relative] = (
                hashlib.sha256(source.read_bytes()).hexdigest()
                if source.is_file() and not source.is_symlink()
                else None
            )
    source_unchanged = current_hashes == recorded_hashes

    private_auth_value = backend.get("environment", {}).get("COSH_LAB_PRIVATE_AUTH")
    private_copy_present = bool(
        private_auth_value and Path(private_auth_value).is_dir()
    )
    result = run_bridge(
        bridge_path_for(backend),
        "exec",
        {**os.environ, **backend["environment"]},
        ["sh", "-lc", 'test -d "$HOME/.copilot-shell"'],
    )
    append_command(artifacts.run_dir, artifacts.manifest, result)
    environment_visible = result["exit_code"] == 0
    try:
        registry, registry_commands = registry_check()
    except EcsError as error:
        registry = {
            "registry_ok": False,
            "effective_auth_required": None,
        }
        registry_commands = error.commands
    for command in registry_commands:
        append_command(artifacts.run_dir, artifacts.manifest, command)
    data = {
        "source_unchanged": source_unchanged,
        "private_copy_present": private_copy_present,
        "environment_visible": environment_visible,
        **registry,
        "provider_reachable": None,
    }
    ok = (
        source_unchanged
        and private_copy_present
        and environment_visible
        and registry["registry_ok"] is True
        and registry["effective_auth_required"] is False
    )
    if ok:
        payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    else:
        payload = envelope(
            False,
            code="auth-blocked",
            message="auth source, private copy, or environment visibility check failed",
            run_dir=artifacts.run_dir,
        )
        payload["data"] = data
    artifacts.complete(payload)
    if ok:
        persist_auth_preflight(data)
    emit(payload, args.output)
    return 0 if ok else 1


def run_env_down(args: argparse.Namespace) -> int:
    artifact_root = Path(args.artifact_root)
    try:
        environment_dir, environment_manifest = load_environment(
            artifact_root, args.run
        )
    except BackendError as error:
        payload = envelope(False, code="environment-unavailable", message=str(error))
        emit(payload, args.output)
        return 1

    artifacts = RunArtifacts(artifact_root, "env-down", repo_metadata())
    artifacts.manifest["environment_ref"] = args.run
    current_cleanup = environment_manifest.get("cleanup", {}).get("status")
    if current_cleanup == "cleaned":
        cleanup = {"status": "cleaned"}
        payload = envelope(
            True,
            data={"already_absent": True, "cleanup": cleanup},
            run_dir=artifacts.run_dir,
        )
        artifacts.manifest["cleanup"] = cleanup
        artifacts.complete(payload)
        emit(payload, args.output)
        return 0

    backend = environment_manifest["backend"]
    if backend.get("kind") == "ecs":
        try:
            cleanup_result = cleanup_ecs(environment_manifest)
        except EcsError as error:
            record_commands(artifacts, error.commands)
            cleanup = {"status": "cleanup-failed"}
            artifacts.manifest["cleanup"] = cleanup
            with environment_refresh_lock(environment_dir):
                current = json.loads((environment_dir / "run.json").read_text())
                current["cleanup"] = cleanup
                current["state"] = "cleanup_failed"
                write_json(environment_dir / "run.json", current)
                write_json(environment_dir / "cleanup.json", cleanup)
                refresh_checksums(environment_dir)
                environment_manifest.clear()
                environment_manifest.update(current)
            payload = envelope(
                False,
                code="cleanup-failed",
                message=str(error),
                run_dir=artifacts.run_dir,
            )
            payload["data"] = {
                "already_absent": False,
                "cleanup": cleanup,
            }
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1

        record_commands(artifacts, cleanup_result["commands"])
        cleanup = {"status": "cleaned"}
        artifacts.manifest["cleanup"] = cleanup
        with environment_refresh_lock(environment_dir):
            current = json.loads((environment_dir / "run.json").read_text())
            current["cleanup"] = cleanup
            current["state"] = "completed"
            write_json(environment_dir / "run.json", current)
            write_json(environment_dir / "cleanup.json", cleanup)
            refresh_checksums(environment_dir)
            environment_manifest.clear()
            environment_manifest.update(current)
        data = {
            "already_absent": False,
            "cleanup": cleanup,
            "remaining": cleanup_result["remaining"],
        }
        payload = envelope(True, data=data, run_dir=artifacts.run_dir)
        artifacts.complete(payload)
        emit(payload, args.output)
        return 0

    action = "stop" if backend.get("retain") else "delete"
    result = run_bridge(
        bridge_path_for(backend),
        action,
        {**os.environ, **backend["environment"]},
    )
    append_command(artifacts.run_dir, artifacts.manifest, result)
    if result["exit_code"] == 0:
        cleanup_status = "retained-by-policy" if backend.get("retain") else "cleaned"
    else:
        cleanup_status = "cleanup-failed"
    cleanup = {"status": cleanup_status}
    artifacts.manifest["cleanup"] = cleanup
    with environment_refresh_lock(environment_dir):
        current = json.loads((environment_dir / "run.json").read_text())
        current["cleanup"] = cleanup
        current["state"] = {
            "retained-by-policy": "retained",
            "cleaned": "completed",
            "cleanup-failed": "cleanup_failed",
        }[cleanup_status]
        write_json(environment_dir / "run.json", current)
        write_json(environment_dir / "cleanup.json", cleanup)
        refresh_checksums(environment_dir)
        environment_manifest.clear()
        environment_manifest.update(current)
    if cleanup_status == "cleaned":
        runtime_value = backend.get("runtime_dir")
        if runtime_value:
            remove_runtime(Path(runtime_value), artifact_root, args.run)
    data = {
        "already_absent": False,
        "cleanup": cleanup,
        "stdout": result["stdout"],
        "stderr": result["stderr"],
    }
    if result["exit_code"] == 0:
        payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    else:
        payload = envelope(
            False,
            code="cleanup-failed",
            message=result["stderr"].strip() or "backend cleanup failed",
            run_dir=artifacts.run_dir,
        )
        payload["data"] = data
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0 if result["exit_code"] == 0 else 1


def run_test_plan(args: argparse.Namespace) -> int:
    profile = None
    if args.profile:
        try:
            profile = load_profile(resolve_profile_arg(args.profile))
        except ProfileError as error:
            payload = envelope(False, code="invalid-profile", message=str(error))
            emit(payload, args.output)
            return 1
        if "full_gate" not in profile:
            payload = envelope(
                False,
                code="invalid-profile",
                message="test plan profile must declare full_gate",
            )
            emit(payload, args.output)
            return 1
    try:
        paths = changed_paths(REPO_ROOT, args.base)
    except ValueError as error:
        payload = envelope(False, code="invalid-base", message=str(error))
        emit(payload, args.output)
        return 1
    artifacts = RunArtifacts(Path(args.artifact_root), "test-plan", repo_metadata())
    plan = build_test_plan(paths)
    profile_summary = None
    if profile:
        plan["wider_gate"] = profile["full_gate"]
        plan["profile_full_gate"] = profile["full_gate"]
        profile_summary = {
            "name": profile["name"],
            "backend": profile["backend"],
            "arch": profile["arch"],
            "full_gate": profile["full_gate"],
        }
    payload = envelope(
        True,
        data={
            "base": args.base,
            "profile": profile_summary,
            "changed_paths": paths,
            "test_plan": plan,
        },
        run_dir=artifacts.run_dir,
    )
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0


def profile_summary(profile: dict[str, Any], path: Path) -> dict[str, Any]:
    return {
        "path": str(path),
        "name": profile["name"],
        "backend": profile["backend"],
        "arch": profile["arch"],
        "full_gate": profile.get("full_gate"),
        "release": profile.get("release"),
    }


def resolve_profile_arg(value: str) -> Path:
    """Resolve a --profile argument to a file path.

    An existing path always wins. A bare name (no separator, no .toml
    suffix) is matched against the `name` field of the profiles in the
    default profiles directory, so the names printed by `profiles list`
    are directly usable (#1932 retro: validate/doctor only accepted
    paths and failed on the listed names with a misleading error).
    """
    path = Path(os.path.abspath(Path(value).expanduser()))
    if path.is_file():
        return path
    raw = str(value)
    if os.sep in raw or raw.endswith(".toml"):
        return path
    directory = TOOL_ROOT / "profiles"
    matches = []
    if directory.is_dir():
        for candidate in sorted(directory.glob("*.toml")):
            try:
                profile = load_profile(candidate)
            except ProfileError:
                continue
            if profile.get("name") == raw:
                matches.append(candidate)
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise ProfileError(
            f"profile name {raw!r} is ambiguous: "
            + ", ".join(str(match) for match in matches)
        )
    return path


def run_profiles_list(args: argparse.Namespace) -> int:
    directory = Path(os.path.abspath(Path(args.directory).expanduser()))
    profiles = []
    invalid = []
    if directory.is_dir():
        for path in sorted(directory.glob("*.toml")):
            try:
                profiles.append(profile_summary(load_profile(path), path))
            except ProfileError as error:
                invalid.append({"path": str(path), "error": str(error)})
    data = {"directory": str(directory), "profiles": profiles, "invalid": invalid}
    payload = (
        envelope(True, data=data)
        if not invalid
        else envelope(
            False,
            code="invalid-profile",
            message="one or more profiles are invalid",
        )
    )
    if invalid:
        payload["data"] = data
    emit(payload, args.output)
    return 0 if not invalid else 1


def run_profiles_validate(args: argparse.Namespace) -> int:
    try:
        path = resolve_profile_arg(args.profile)
        profile = load_profile(path)
    except ProfileError as error:
        emit(envelope(False, code="invalid-profile", message=str(error)), args.output)
        return 1
    emit(envelope(True, data=profile_summary(profile, path)), args.output)
    return 0


def discover_accept_cases() -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    canonical_root = REPO_ROOT / "specs" / "shell-e2e-validation" / "cases"
    runner = TOOL_ROOT / "scripts" / "e2e" / "cosh-shell-run-case"
    ruby = shutil.which("ruby")
    if ruby is None or not runner.is_file():
        return [], [{"path": str(runner), "error": "Ruby canonical E2E runner is unavailable"}]
    cases = []
    errors = []
    for path in sorted(canonical_root.glob("*.yaml")):
        if path.is_symlink() or not path.resolve().is_relative_to(
            canonical_root.resolve()
        ):
            errors.append(
                {
                    "path": str(path),
                    "error": "canonical case symlinks are not allowed",
                }
            )
            continue
        result = run_command(
            [ruby, str(runner), "--case", str(path), "--list-only"],
            REPO_ROOT,
        )
        if result["exit_code"] != 0:
            errors.append({"path": str(path), "error": result["stderr"].strip()})
            continue
        try:
            listed = json.loads(result["stdout"])
        except json.JSONDecodeError as error:
            errors.append({"path": str(path), "error": str(error)})
            continue
        for item in listed:
            cases.append(
                {
                    **item,
                    "path": str(path),
                    "logical_path": str(path.relative_to(REPO_ROOT)),
                }
            )
    return cases, errors


def run_accept_list(args: argparse.Namespace) -> int:
    cases, errors = discover_accept_cases()
    data = {"cases": cases, "errors": errors}
    payload = (
        envelope(True, data=data)
        if not errors
        else envelope(
            False,
            code="invalid-case",
            message="one or more case files are invalid",
        )
    )
    if errors:
        payload["data"] = data
    emit(payload, args.output)
    return 0 if not errors else 1


def run_accept_describe(args: argparse.Namespace) -> int:
    cases, errors = discover_accept_cases()
    if errors:
        payload = envelope(
            False,
            code="invalid-case",
            message="one or more case files are invalid",
        )
        payload["data"] = {"cases": cases, "errors": errors}
        emit(payload, args.output)
        return 1
    matches = [case for case in cases if case["id"] == args.id]
    if len(matches) != 1:
        emit(
            envelope(
                False,
                code="invalid-case",
                message=f"canonical case id is not unique or unavailable: {args.id}",
            ),
            args.output,
        )
        return 1
    emit(envelope(True, data={"case": matches[0]}), args.output)
    return 0


def run_test(args: argparse.Namespace) -> int:
    workdir = getattr(args, "workdir", None)
    cargo = getattr(args, "cargo", None)
    host_cwd = Path(workdir) if workdir is not None else REPO_ROOT / "src" / "cosh-ng"

    def prepare_command(native_command: list[str]) -> list[str]:
        if cargo is not None:
            native_command = [cargo, *native_command[1:]]
        if workdir is not None and args.on != "host":
            return [
                "sh", "-c", 'cd "$1" && shift && exec "$@"',
                "cosh-lab-test", workdir, *native_command,
            ]
        return native_command

    def execute_remote_test(
        command: list[str], execution_id: str,
    ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        records = []
        try:
            result, records = execute_in_environment(
                environment_manifest, command,
                execution_id=execution_id, on_invoke=persist_invoke,
            )
            return result, records
        except (KeyboardInterrupt, EcsError, TransportError) as error:
            records = getattr(error, "commands", [])
            raise
        finally:
            if records and (workdir is not None or cargo is not None):
                # Cloud Assistant redacts the script in its transport records.
                records[-1]["native_command"] = command

    try:
        command = prepare_command(command_for_scope(args.scope, args.filter, args.jobs))
    except ValueError as error:
        payload = envelope(False, code="invalid-scope", message=str(error))
        emit(payload, args.output)
        return 1

    artifacts = RunArtifacts(Path(args.artifact_root), "test", repo_metadata())
    artifacts.manifest["environment_ref"] = args.on
    environment_manifest = None
    if args.on == "host":
        try:
            result = run_command(command, host_cwd)
            commands = [result]
        except KeyboardInterrupt as error:
            record_commands(artifacts, getattr(error, "commands", []))
            payload = envelope(
                False,
                code="user-cancelled",
                message="test interrupted",
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
    else:
        try:
            environment_dir, environment_manifest = load_environment(
                Path(args.artifact_root),
                args.on,
            )
        except BackendError as error:
            payload = envelope(
                False,
                code="environment-unavailable",
                message=str(error),
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        persist_invoke = invocation_persister(
            environment_dir,
            environment_manifest,
        )
        try:
            result, commands = execute_remote_test(
                command,
                execution_id=f"{artifacts.run_id}-primary",
            )
        except KeyboardInterrupt as error:
            cleanup_safe = getattr(error, "cleanup_safe", True)
            cancel_assistant = (
                cleanup_safe and interrupted_transport(error) != "workbench"
            )
            cancel_result = (
                cancel_environment_command(
                    environment_dir,
                    environment_manifest,
                )
                if cancel_assistant
                else None
            )
            commands = list(getattr(error, "commands", []))
            if cancel_result:
                commands.append(cancel_result)
            record_commands(artifacts, commands)
            payload = envelope(
                False,
                code="user-cancelled",
                message=(
                    "test interrupted; backend command cancellation attempted"
                    if cancel_assistant
                    else "test interrupted; backend command state is unknown"
                ),
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        except (EcsError, TransportError) as error:
            record_commands(artifacts, getattr(error, "commands", []))
            payload = envelope(
                False,
                code="environment-unavailable",
                message=str(error),
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
    reruns = []
    try:
        if (
            result["exit_code"] != 0
            and args.filter is None
            and args.scope in {"unit", "logic", "protocol", "raw-cli", "shell-host"}
        ):
            for case in failed_test_cases(result["stdout"]):
                rerun_command = prepare_command(command_for_exact_case(args.scope, case))
                if args.on == "host":
                    rerun_result = run_command(rerun_command, host_cwd)
                    rerun_commands = [rerun_result]
                else:
                    rerun_result, rerun_commands = execute_remote_test(
                        rerun_command,
                        execution_id=f"{artifacts.run_id}-rerun",
                    )
                commands.extend(rerun_commands)
                reruns.append(
                    {
                        "case": case,
                        "command": rerun_command,
                        "result": rerun_result,
                    }
                )
    except (KeyboardInterrupt, EcsError, TransportError) as error:
        commands.extend(getattr(error, "commands", []))
        if isinstance(error, (EcsError, TransportError)):
            reruns.append(
                {
                    "case": case,
                    "command": rerun_command,
                    "result": {
                        "argv": rerun_command,
                        "exit_code": 1,
                        "duration_seconds": 0,
                        "stdout": "",
                        "stderr": str(error),
                    },
                }
            )
        else:
            if (
                environment_manifest is not None
                and getattr(error, "cleanup_safe", True)
                and interrupted_transport(error) != "workbench"
            ):
                cancel_result = cancel_environment_command(
                    environment_dir,
                    environment_manifest,
                )
                if cancel_result:
                    commands.append(cancel_result)
            record_commands(artifacts, commands)
            payload = envelope(
                False,
                code="user-cancelled",
                message="test rerun interrupted",
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1

    artifacts.manifest["commands"].extend(commands)
    (artifacts.run_dir / "commands.log").write_text(
        "".join(json.dumps(item, sort_keys=True) + "\n" for item in commands)
    )
    data = {
        "scope": args.scope,
        "command": command,
        "target_cache_key": (
            environment_manifest.get("backend", {})
            .get("environment", {})
            .get("COSH_LAB_TARGET_CACHE_KEY")
            if environment_manifest is not None
            else None
        ),
        "exit_code": result["exit_code"],
        "duration_seconds": result["duration_seconds"],
        "stdout": result["stdout"],
        "stderr": result["stderr"],
    }
    if workdir is not None:
        data["workdir"] = workdir
    if reruns:
        data["initial"] = result
        data["serial_reruns"] = reruns
    if result["exit_code"] == 0:
        payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    else:
        suspected_flaky = bool(reruns) and all(
            rerun["result"]["exit_code"] == 0 for rerun in reruns
        )
        code = "suspected-flaky" if suspected_flaky else "test-failure"
        payload = envelope(
            False,
            data=data,
            code=code,
            message=f"test scope {args.scope} exited {result['exit_code']}",
            run_dir=artifacts.run_dir,
        )
        payload["data"] = data
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0 if result["exit_code"] == 0 else 1


def run_accept(args: argparse.Namespace) -> int:
    case_path = Path(args.case).expanduser().resolve()
    canonical_root = REPO_ROOT / "specs" / "shell-e2e-validation" / "cases"
    if args.case_source == "canonical":
        forbidden_overrides = (
            "COSH_E2E_COMMAND_JSON",
            "COSH_E2E_EXEC_PREFIX_JSON",
            "COSH_E2E_REAL_PROVIDER_EVIDENCE_JSON",
        )
        if any(os.environ.get(name) for name in forbidden_overrides):
            payload = envelope(
                False,
                code="invalid-case",
                message="canonical cases reject runner evidence overrides",
            )
            emit(payload, args.output)
            return 1
        if not case_path.is_relative_to(canonical_root) or not case_path.is_file():
            payload = envelope(
                False,
                code="invalid-case",
                message=f"case must be under canonical root: {canonical_root}",
            )
            emit(payload, args.output)
            return 1
        logical_case_path = str(case_path.relative_to(REPO_ROOT))
    else:
        if args.gate != "development":
            payload = envelope(
                False,
                code="invalid-case",
                message="fixture cases are limited to the development gate",
            )
            emit(payload, args.output)
            return 1
        if not case_path.is_file():
            payload = envelope(
                False,
                code="invalid-case",
                message=f"fixture case is unavailable: {case_path}",
            )
            emit(payload, args.output)
            return 1
        logical_case_path = None

    runner = TOOL_ROOT / "scripts" / "e2e" / "cosh-shell-run-case"
    ruby = shutil.which("ruby")
    if ruby is None or not runner.is_file():
        payload = envelope(
            False,
            code="environment-unavailable",
            message="Ruby canonical E2E runner is unavailable",
        )
        emit(payload, args.output)
        return 1

    artifacts = RunArtifacts(Path(args.artifact_root), "accept", repo_metadata())
    artifacts.manifest["capabilities"] = ["pty", "acceptance", "cleanup"]
    artifacts.manifest["environment_ref"] = args.on
    artifacts.manifest["case_source"] = args.case_source
    quarantine_root = Path(args.artifact_root).expanduser().resolve() / ".quarantine"
    command = [
        ruby,
        str(runner),
        "--case",
        str(case_path),
        "--id",
        args.id,
        "--out",
        str(artifacts.run_dir),
        "--quarantine-root",
        str(quarantine_root),
    ]
    command_env = os.environ.copy()
    command_env.pop("COSH_E2E_REAL_PROVIDER_EVIDENCE_JSON", None)
    if args.case_source == "canonical":
        command_env["COSH_E2E_FAIL_ON_SECRET"] = "1"
    environment_dir = None
    environment_manifest = None
    persist_invoke = None
    provider_binary_preflight: dict[str, Any] | None = None
    if args.on != "host":
        try:
            environment_dir, environment_manifest = load_environment(
                Path(args.artifact_root),
                args.on,
            )
        except BackendError as error:
            payload = envelope(
                False,
                code="environment-unavailable",
                message=str(error),
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        backend = environment_manifest["backend"]
        persist_invoke = invocation_persister(
            environment_dir,
            environment_manifest,
        )
        if backend.get("kind") == "ecs":
            try:
                selection, transport_commands = select_operation_transport(
                    environment_manifest,
                    args.transport,
                    "shell",
                )
            except TransportError as error:
                payload = envelope(
                    False,
                    code="environment-unavailable",
                    message=str(error),
                    run_dir=artifacts.run_dir,
                )
                artifacts.complete(payload)
                emit(payload, args.output)
                return 1
            record_commands(artifacts, transport_commands)
            ssh_prefix = ssh_argv(
                backend,
                selection["selected"],
            )
            ssh_prefix.insert(-1, "-tt")
            command_env["COSH_E2E_EXEC_PREFIX_JSON"] = json.dumps(ssh_prefix)
            artifacts.manifest["acceptance_transport"] = selection
        else:
            command_env.update(backend["environment"])
            command_env["COSH_E2E_EXEC_PREFIX_JSON"] = json.dumps(
                [str(bridge_path_for(backend)), "exec-pty"]
            )
    def finish_acceptance_interrupt(error: KeyboardInterrupt) -> int:
        commands = list(getattr(error, "commands", []))
        cleanup_safe = getattr(error, "cleanup_safe", True)
        cancel_assistant = (
            cleanup_safe and interrupted_transport(error) != "workbench"
        )
        if (
            cancel_assistant
            and environment_dir is not None
            and environment_manifest is not None
        ):
            cancel_result = cancel_environment_command(
                environment_dir,
                environment_manifest,
            )
            if cancel_result:
                commands.append(cancel_result)
        record_commands(artifacts, commands)
        payload = envelope(
            False,
            code="user-cancelled",
            message=(
                "acceptance interrupted; backend command cancellation attempted"
                if cancel_assistant
                else "acceptance interrupted; backend command state is unknown"
            ),
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1

    try:
        describe_result = run_command(
            [*command, "--describe-only"],
            REPO_ROOT / "src" / "cosh-ng",
            env=command_env,
        )
    except KeyboardInterrupt as error:
        return finish_acceptance_interrupt(error)
    record_commands(artifacts, [describe_result])
    description = None
    for line in reversed(describe_result["stdout"].splitlines()):
        try:
            candidate = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(candidate, dict):
            description = candidate
            break
    if describe_result["exit_code"] != 0 or description is None:
        payload = envelope(
            False,
            code="invalid-case",
            message=describe_result["stderr"].strip()
            or "canonical E2E case description failed",
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1
    if (
        description.get("execution") == "real-provider"
        and args.case_source == "canonical"
    ):
        if environment_manifest is None:
            payload = envelope(
                False,
                code="auth-blocked",
                message="real-provider canonical cases require a VM or ECS environment",
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        if not auth_preflight_is_fresh(
            environment_manifest.get("auth_preflight", {}),
            artifacts.manifest["started_at"],
        ):
            payload = envelope(
                False,
                code="auth-blocked",
                message="real-provider requires an auth preflight from the last 5 minutes",
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        try:
            provider_binary_preflight, build_commands = build_provider_binary(
                environment_manifest,
                artifacts.run_id,
                on_invoke=persist_invoke,
            )
        except KeyboardInterrupt as error:
            return finish_acceptance_interrupt(error)
        except (EcsError, TransportError, ValueError) as error:
            record_commands(artifacts, getattr(error, "commands", []))
            payload = envelope(
                False,
                code="environment-unavailable",
                message=str(error),
                run_dir=artifacts.run_dir,
            )
            artifacts.complete(payload)
            emit(payload, args.output)
            return 1
        record_commands(artifacts, build_commands)
        command_env["COSH_SHELL"] = provider_binary_preflight["resolved_path"]
    try:
        result = run_command(
            command,
            REPO_ROOT / "src" / "cosh-ng",
            env=command_env,
        )
    except KeyboardInterrupt as error:
        return finish_acceptance_interrupt(error)
    record_commands(artifacts, [result])
    runner_payload = None
    for line in reversed(result["stdout"].splitlines()):
        try:
            candidate = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(candidate, dict):
            runner_payload = candidate
            break
    if runner_payload is None:
        payload = envelope(
            False,
            code="test-failure",
            message=result["stderr"].strip()
            or "canonical E2E runner returned no result",
            run_dir=artifacts.run_dir,
        )
        artifacts.complete(payload)
        emit(payload, args.output)
        return 1

    if runner_payload.get("execution") == "real-provider":
        auth_preflight = (
            environment_manifest.get("auth_preflight", {})
            if environment_manifest is not None
            else {}
        )
        try:
            if environment_manifest is None:
                raise ValueError("trusted environment preflight is unavailable")
            production_argv = runner_payload.get("production_argv", [])
            if provider_binary_preflight is None:
                raise ValueError(
                    "isolated production binary build evidence is unavailable"
                )
            provider_evidence = trusted_provider_evidence(
                auth_preflight,
                provider_binary_preflight,
                production_argv,
                runner_payload.get("provider_lifecycle", {}),
            )
        except (EcsError, ValueError) as error:
            runner_payload["ok"] = False
            runner_payload.setdefault("failures", []).append(
                f"real-provider requires a trusted environment preflight: {error}"
            )
        else:
            runner_payload["provider_evidence"] = provider_evidence
            runner_payload["execution_evidence"] = "real-provider"
            write_provider_evidence_index(
                artifacts.run_dir,
                provider_evidence,
            )

    visual_rows: list[dict[str, Any]] = []
    write_json(
        artifacts.run_dir / "acceptance-points.json",
        runner_payload.get("points", []),
    )
    if runner_payload.get("ok"):
        try:
            visual_rows = render_point_screenshots(
                artifacts.run_dir,
                args.id,
                runner_payload.get("points", []),
            )
        except EvidenceError as error:
            runner_payload["ok"] = False
            runner_payload.setdefault("failures", []).append(str(error))
    if runner_payload.get("execution_evidence") == "real-provider":
        artifacts.manifest["capabilities"].append("real-provider")

    data = {
        "case": {
            **runner_payload["case"],
            "logical_path": logical_case_path,
            "source": args.case_source,
        },
        "execution": runner_payload["execution"],
        "execution_evidence": runner_payload["execution_evidence"],
        "gate": args.gate,
        "exit_status": runner_payload["exit_status"],
        "points": visual_rows,
        "failures": runner_payload["failures"],
        "quarantine_deleted": runner_payload.get("quarantine_deleted", False),
        "provider_evidence": runner_payload.get("provider_evidence", {}),
        "provider_lifecycle": runner_payload.get("provider_lifecycle", {}),
    }
    artifacts.manifest["cleanup"]["status"] = "not-applicable"
    write_json(artifacts.run_dir / "cleanup.json", artifacts.manifest["cleanup"])
    if runner_payload.get("ok") and runner_payload.get("quarantine_deleted"):
        payload = envelope(True, data=data, run_dir=artifacts.run_dir)
    else:
        payload = envelope(
            False,
            code="test-failure",
            message="; ".join(runner_payload.get("failures", []))
            or "acceptance failed",
            run_dir=artifacts.run_dir,
        )
        payload["data"] = data
    artifacts.complete(payload)
    emit(payload, args.output)
    return 0 if payload["ok"] else 1


def run_evidence_verify(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        errors = verify_run(run_dir)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        errors = [str(error)]
    if errors:
        payload = envelope(
            False,
            code="evidence-incomplete",
            message="; ".join(errors),
        )
        emit(payload, args.output)
        return 1
    payload = envelope(True, data={"run_dir": str(run_dir), "verified": True})
    emit(payload, args.output)
    return 0


def run_evidence_render(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        manifest = json.loads((run_dir / "run.json").read_text())
        points = json.loads((run_dir / "acceptance-points.json").read_text())
        if "acceptance" not in manifest.get("capabilities", []):
            raise EvidenceError("run does not declare acceptance capability")
        if not isinstance(points, list):
            raise EvidenceError("acceptance-points.json must contain an array")
        result_path = run_dir / "result.json"
        result = json.loads(result_path.read_text())
        case_id = result.get("data", {}).get("case", {}).get("id")
        if not case_id:
            raise EvidenceError("acceptance result has no case id")
        rows = render_point_screenshots(run_dir, case_id, points)
        result["data"]["points"] = rows
        write_json(result_path, result)
        refresh_checksums(run_dir)
    except (OSError, ValueError, json.JSONDecodeError, EvidenceError) as error:
        payload = envelope(
            False,
            code="evidence-incomplete",
            message=str(error),
        )
        emit(payload, args.output)
        return 1
    payload = envelope(
        True,
        data={"run_dir": str(run_dir), "screenshots": rows},
    )
    emit(payload, args.output)
    return 0


def run_evidence_attach_screen(args: argparse.Namespace) -> int:
    run_dir = Path(args.run_dir).expanduser().resolve()
    try:
        row = attach_independent_screen(
            run_dir,
            args.point,
            Path(args.file).expanduser().resolve(),
        )
        manifest = read_run_manifest(run_dir)
        manifest["artifacts"] = sorted(
            str(path.relative_to(run_dir))
            for path in run_dir.rglob("*")
            if path.is_file() and path.name not in {"checksums.sha256", "run.json"}
        )
        write_json(run_dir / "run.json", manifest)
        refresh_checksums(run_dir)
    except (OSError, EvidenceError) as error:
        emit(
            envelope(False, code="evidence-incomplete", message=str(error)),
            args.output,
        )
        return 1
    emit(envelope(True, data={"screen": row}), args.output)
    return 0


def _run_issuefix(args: argparse.Namespace, action) -> int:
    try:
        data = action()
    except IssueFixError as error:
        emit(envelope(False, code=error.code, message=str(error)), args.output)
        return 1
    payload = envelope(True, data=data)
    emit(payload, args.output)
    if args.output != "json":
        print(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


def run_issue_audit(args: argparse.Namespace) -> int:
    return _run_issuefix(
        args,
        lambda: issue_audit(args.repo, args.num, target_repo_root(args.target_root)),
    )


def run_ws_up(args: argparse.Namespace) -> int:
    return _run_issuefix(
        args,
        lambda: ws_up(
            target_repo_root(args.target_root),
            args.issue,
            args.slug,
            args.base,
            refresh=args.refresh,
        ),
    )


def run_ws_status(args: argparse.Namespace) -> int:
    return _run_issuefix(
        args,
        lambda: ws_status(target_repo_root(args.target_root), args.slug),
    )


def run_ws_down(args: argparse.Namespace) -> int:
    return _run_issuefix(
        args,
        lambda: ws_down(
            target_repo_root(args.target_root), args.slug, apply=args.apply
        ),
    )


def run_pr_preflight(args: argparse.Namespace) -> int:
    try:
        result = pr_preflight(
            target_repo_root(args.target_root),
            base=args.base,
            test_command=args.test_command,
            max_subject=args.max_subject,
            cargo_root=args.cargo_root,
            gates=tuple(args.gate or ()),
        )
    except IssueFixError as error:
        emit(envelope(False, code=error.code, message=str(error)), args.output)
        return 1
    emit(envelope(True, data=result), args.output)
    if args.output != "json":
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["ok"] else 1


def run_pr_assets_push(args: argparse.Namespace) -> int:
    return _run_issuefix(
        args,
        lambda: pr_assets_push(
            directory=Path(args.dir).expanduser().resolve(),
            num=args.num,
            fork=args.fork,
            expected_commit=args.expected_commit,
        ),
    )


def run_pr_watch(args: argparse.Namespace) -> int:
    if args.until_review_activity and not args.cursor_file:
        emit(
            envelope(
                False,
                code="cursor-required",
                message="--until-review-activity requires --cursor-file",
            ),
            args.output,
        )
        return 1
    return _run_issuefix(
        args,
        lambda: pr_watch(
            args.repo,
            args.num,
            until_checks_complete=args.until_checks_complete,
            until_review_activity=args.until_review_activity,
            timeout_seconds=args.timeout,
            interval_seconds=args.interval,
            max_polls=args.max_polls,
            classify_failures=args.classify_failures,
            cursor_file=(
                Path(args.cursor_file).expanduser().resolve()
                if args.cursor_file
                else None
            ),
        ),
    )


def run_close_out(args: argparse.Namespace) -> int:
    try:
        result = close_out(
            target_repo_root(args.target_root),
            pr=args.pr,
            repo=args.repo,
            issue=args.issue,
            slug=args.slug,
            extra_artifact_roots=tuple(
                Path(root) for root in (args.artifacts_root or [])
            ),
        )
    except IssueFixError as error:
        emit(envelope(False, code=error.code, message=str(error)), args.output)
        return 1
    emit(envelope(True, data=result), args.output)
    if args.output != "json":
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] == "cleaned" else 1


def emit(payload: dict[str, Any], output: str) -> None:
    if output == "json":
        print(json.dumps(payload, sort_keys=True))
        return
    if payload["ok"]:
        # Command-style results (env exec and friends) must surface their
        # captured output in human mode; a bare "ok" hides the very thing
        # the caller ran the command for.
        data = payload.get("data") or {}
        if isinstance(data, dict) and (
            "stdout" in data or "stderr" in data or "exit_code" in data
        ):
            stdout = data.get("stdout") or ""
            stderr = data.get("stderr") or ""
            if stdout:
                print(stdout, end="" if stdout.endswith("\n") else "\n")
            if stderr:
                print(stderr, end="" if stderr.endswith("\n") else "\n", file=sys.stderr)
            exit_code = data.get("exit_code")
            print("ok" if exit_code in (0, None) else f"ok (exit_code={exit_code})")
        else:
            print("ok")
    else:
        print(f"error: {payload['error']['message']}", file=sys.stderr)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cosh-lab")
    parser.add_argument("--version", action="version", version=__version__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    doctor = subparsers.add_parser("doctor")
    doctor.add_argument("--profile")
    doctor.add_argument("--output", choices=("human", "json"), default="human")
    doctor.add_argument("--artifact-root", default=".cosh-lab/runs")
    doctor.set_defaults(handler=run_doctor)

    environment = subparsers.add_parser("env")
    environment_subparsers = environment.add_subparsers(
        dest="env_command", required=True
    )
    environment_up = environment_subparsers.add_parser("up")
    environment_up.add_argument("--backend", required=True)
    environment_up.add_argument("--profile", required=True)
    environment_up.add_argument("--dry-run", action="store_true")
    environment_up.add_argument("--apply", action="store_true")
    environment_up.add_argument("--output", choices=("human", "json"), default="human")
    environment_up.add_argument("--artifact-root", default=".cosh-lab/runs")
    environment_up.set_defaults(handler=run_env_up)

    environment_exec = environment_subparsers.add_parser("exec")
    environment_exec.add_argument("--run", required=True)
    environment_exec.add_argument(
        "--transport",
        choices=NON_INTERACTIVE_TRANSPORTS,
        default="auto",
    )
    environment_exec.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    environment_exec.add_argument("--artifact-root", default=".cosh-lab/runs")
    environment_exec.add_argument("command", nargs=argparse.REMAINDER)
    environment_exec.set_defaults(handler=run_env_exec)

    for name, handler, arguments in (
        ("upload", run_env_upload, (("local",), ("remote",))),
        ("download", run_env_download, (("remote",), ("local",))),
        ("hash", run_env_hash, (("remote",),)),
    ):
        transfer = environment_subparsers.add_parser(name)
        transfer.add_argument("--run", required=True)
        transfer.add_argument(
            "--transport",
            choices=NON_INTERACTIVE_TRANSPORTS,
            default="auto",
        )
        transfer.add_argument(
            "--output",
            choices=("human", "json"),
            default="human",
        )
        transfer.add_argument("--artifact-root", default=".cosh-lab/runs")
        for argument in arguments:
            transfer.add_argument(*argument)
        if name == "download":
            transfer.add_argument("--directory", action="store_true")
        transfer.set_defaults(handler=handler)

    environment_shell = environment_subparsers.add_parser("shell")
    environment_shell.add_argument("--run", required=True)
    environment_shell.add_argument(
        "--transport",
        choices=INTERACTIVE_TRANSPORTS,
        default="auto",
    )
    environment_shell.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    environment_shell.add_argument("--artifact-root", default=".cosh-lab/runs")
    environment_shell.set_defaults(handler=run_env_shell)

    environment_transport = environment_subparsers.add_parser("transport")
    environment_transport_subparsers = environment_transport.add_subparsers(
        dest="transport_command",
        required=True,
    )
    environment_transport_check = environment_transport_subparsers.add_parser(
        "check"
    )
    environment_transport_check.add_argument("--run", required=True)
    environment_transport_check.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    environment_transport_check.add_argument(
        "--artifact-root", default=".cosh-lab/runs"
    )
    environment_transport_check.set_defaults(handler=run_env_transport_check)

    environment_transport_refresh = environment_transport_subparsers.add_parser(
        "refresh"
    )
    environment_transport_refresh.add_argument("--run", required=True)
    environment_transport_refresh.add_argument(
        "--route", choices=("proxyjump-public", "direct-public"), required=True
    )
    environment_transport_refresh.add_argument("--identity-file")
    environment_transport_refresh.add_argument("--known-hosts-file")
    environment_transport_refresh.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    environment_transport_refresh.add_argument(
        "--artifact-root", default=".cosh-lab/runs"
    )
    environment_transport_refresh.set_defaults(handler=run_env_transport_refresh)

    for name, handler in (
        ("inspect", run_env_inspect),
        ("collect", run_env_collect),
    ):
        diagnostic = environment_subparsers.add_parser(name)
        diagnostic.add_argument("--run", required=True)
        diagnostic.add_argument(
            "--transport",
            choices=NON_INTERACTIVE_TRANSPORTS,
            default="auto",
        )
        diagnostic.add_argument(
            "--output", choices=("human", "json"), default="human"
        )
        diagnostic.add_argument("--artifact-root", default=".cosh-lab/runs")
        if name == "collect":
            diagnostic.add_argument(
                "--preset",
                choices=("failure", "network", "toolchain", "system"),
                required=True,
            )
        diagnostic.set_defaults(handler=handler)

    environment_status = environment_subparsers.add_parser("status")
    environment_status.add_argument("--run", required=True)
    environment_status.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    environment_status.add_argument("--artifact-root", default=".cosh-lab/runs")
    environment_status.set_defaults(handler=run_env_status)

    environment_auth = environment_subparsers.add_parser("auth")
    environment_auth_subparsers = environment_auth.add_subparsers(
        dest="auth_command",
        required=True,
    )
    environment_auth_check = environment_auth_subparsers.add_parser("check")
    environment_auth_check.add_argument("--run", required=True)
    environment_auth_check.add_argument(
        "--output",
        choices=("human", "json"),
        default="human",
    )
    environment_auth_check.add_argument("--artifact-root", default=".cosh-lab/runs")
    environment_auth_check.set_defaults(handler=run_env_auth_check)

    environment_down = environment_subparsers.add_parser("down")
    environment_down.add_argument("--run", required=True)
    environment_down.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    environment_down.add_argument("--artifact-root", default=".cosh-lab/runs")
    environment_down.set_defaults(handler=run_env_down)

    test = subparsers.add_parser("test")
    test_subparsers = test.add_subparsers(dest="test_command", required=True)
    test_plan = test_subparsers.add_parser("plan")
    test_plan.add_argument("--base", default="HEAD")
    test_plan.add_argument("--profile")
    test_plan.add_argument("--output", choices=("human", "json"), default="human")
    test_plan.add_argument("--artifact-root", default=".cosh-lab/runs")
    test_plan.set_defaults(handler=run_test_plan)

    test_run = test_subparsers.add_parser("run")
    test_run.add_argument("--on", required=True)
    test_run.add_argument(
        "--scope",
        choices=(
            "unit",
            "logic",
            "protocol",
            "raw-cli",
            "shell-host",
            "crate",
            "workspace",
        ),
        required=True,
    )
    test_run.add_argument("--filter")
    test_run.add_argument("--jobs", type=int)
    test_run.add_argument("--workdir", help="Working directory in the test environment")
    test_run.add_argument("--cargo", help="Cargo executable in the test environment")
    test_run.add_argument("--output", choices=("human", "json"), default="human")
    test_run.add_argument("--artifact-root", default=".cosh-lab/runs")
    test_run.set_defaults(handler=run_test)

    runs = subparsers.add_parser("runs")
    runs_subparsers = runs.add_subparsers(dest="runs_command", required=True)
    runs_list = runs_subparsers.add_parser("list")
    runs_list.add_argument("--output", choices=("human", "json"), default="human")
    runs_list.add_argument("--artifact-root", default=".cosh-lab/runs")
    runs_list.set_defaults(handler=run_runs_list)
    runs_resume = runs_subparsers.add_parser("resume")
    runs_resume.add_argument("run")
    runs_resume.add_argument("--output", choices=("human", "json"), default="human")
    runs_resume.add_argument("--artifact-root", default=".cosh-lab/runs")
    runs_resume.set_defaults(handler=run_runs_resume)
    runs_gc = runs_subparsers.add_parser("gc")
    runs_gc.add_argument("--older-than-hours", type=float, required=True)
    runs_gc.add_argument("--apply", action="store_true")
    runs_gc.add_argument("--output", choices=("human", "json"), default="human")
    runs_gc.add_argument("--artifact-root", default=".cosh-lab/runs")
    runs_gc.set_defaults(handler=run_runs_gc)

    profiles = subparsers.add_parser("profiles")
    profiles_subparsers = profiles.add_subparsers(
        dest="profiles_command",
        required=True,
    )
    profiles_list = profiles_subparsers.add_parser("list")
    profiles_list.add_argument("--directory", default=str(TOOL_ROOT / "profiles"))
    profiles_list.add_argument("--output", choices=("human", "json"), default="human")
    profiles_list.set_defaults(handler=run_profiles_list)
    profiles_validate = profiles_subparsers.add_parser("validate")
    profiles_validate.add_argument("profile")
    profiles_validate.add_argument(
        "--output",
        choices=("human", "json"),
        default="human",
    )
    profiles_validate.set_defaults(handler=run_profiles_validate)

    gate = subparsers.add_parser("gate")
    gate_subparsers = gate.add_subparsers(dest="gate_command", required=True)
    gate_evaluate = gate_subparsers.add_parser("evaluate")
    gate_evaluate.add_argument("run_dir", nargs="+")
    gate_evaluate.add_argument(
        "--require",
        action="append",
        choices=("test", "test-plan", "acceptance", "env-up"),
        default=[],
    )
    gate_evaluate.add_argument(
        "--require-scope",
        action="append",
        choices=("unit", "logic", "protocol", "raw-cli", "shell-host", "crate", "workspace"),
        default=[],
    )
    gate_evaluate.add_argument(
        "--require-backend",
        action="append",
        choices=("container", "vm", "ecs"),
        default=[],
    )
    gate_evaluate.add_argument("--require-arch", action="append", default=[])
    gate_evaluate.add_argument("--require-real-provider", action="store_true")
    gate_evaluate.add_argument("--profile")
    gate_evaluate.add_argument("--output", choices=("human", "json"), default="human")
    gate_evaluate.set_defaults(handler=run_gate_evaluate)

    accept = subparsers.add_parser("accept")
    accept_subparsers = accept.add_subparsers(dest="accept_command", required=True)
    accept_list = accept_subparsers.add_parser("list")
    accept_list.add_argument("--output", choices=("human", "json"), default="human")
    accept_list.set_defaults(handler=run_accept_list)
    accept_describe = accept_subparsers.add_parser("describe")
    accept_describe.add_argument("--id", required=True)
    accept_describe.add_argument(
        "--output",
        choices=("human", "json"),
        default="human",
    )
    accept_describe.set_defaults(handler=run_accept_describe)
    accept_run = accept_subparsers.add_parser("run")
    accept_run.add_argument("--on", required=True)
    accept_run.add_argument(
        "--transport",
        choices=INTERACTIVE_TRANSPORTS,
        default="auto",
    )
    accept_run.add_argument("--case", required=True)
    accept_run.add_argument(
        "--case-source",
        choices=("canonical", "fixture"),
        default="canonical",
    )
    accept_run.add_argument("--id", required=True)
    accept_run.add_argument(
        "--gate",
        choices=("development", "feature-acceptance"),
        default="development",
    )
    accept_run.add_argument("--output", choices=("human", "json"), default="human")
    accept_run.add_argument("--artifact-root", default=".cosh-lab/runs")
    accept_run.set_defaults(handler=run_accept)

    evidence = subparsers.add_parser("evidence")
    evidence_subparsers = evidence.add_subparsers(
        dest="evidence_command",
        required=True,
    )
    evidence_verify = evidence_subparsers.add_parser("verify")
    evidence_verify.add_argument("run_dir")
    evidence_verify.add_argument(
        "--output",
        choices=("human", "json"),
        default="human",
    )
    evidence_verify.set_defaults(handler=run_evidence_verify)
    evidence_render = evidence_subparsers.add_parser("render")
    evidence_render.add_argument("run_dir")
    evidence_render.add_argument(
        "--output",
        choices=("human", "json"),
        default="human",
    )
    evidence_render.set_defaults(handler=run_evidence_render)
    evidence_attach = evidence_subparsers.add_parser("attach-screen")
    evidence_attach.add_argument("run_dir")
    evidence_attach.add_argument("--point", required=True)
    evidence_attach.add_argument("--file", required=True)
    evidence_attach.add_argument(
        "--output",
        choices=("human", "json"),
        default="human",
    )
    evidence_attach.set_defaults(handler=run_evidence_attach_screen)

    issue = subparsers.add_parser("issue")
    issue_subparsers = issue.add_subparsers(dest="issue_command", required=True)
    issue_audit_parser = issue_subparsers.add_parser("audit")
    issue_audit_parser.add_argument("--repo", required=True)
    issue_audit_parser.add_argument("--num", type=int, required=True)
    issue_audit_parser.add_argument("--target-root")
    issue_audit_parser.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    issue_audit_parser.set_defaults(handler=run_issue_audit)

    workspace = subparsers.add_parser("ws")
    workspace_subparsers = workspace.add_subparsers(dest="ws_command", required=True)
    workspace_up = workspace_subparsers.add_parser("up")
    workspace_up.add_argument("--issue", type=int, required=True)
    workspace_up.add_argument("--slug", required=True)
    workspace_up.add_argument("--base", default="origin/main")
    workspace_up.add_argument(
        "--refresh",
        action="store_true",
        help=(
            "fast-forward an existing clean worktree (same branch, no own "
            "commits) to the latest base instead of failing worktree-exists"
        ),
    )
    workspace_up.add_argument("--target-root")
    workspace_up.add_argument("--output", choices=("human", "json"), default="human")
    workspace_up.set_defaults(handler=run_ws_up)
    workspace_status = workspace_subparsers.add_parser("status")
    workspace_status.add_argument("--slug")
    workspace_status.add_argument("--target-root")
    workspace_status.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    workspace_status.set_defaults(handler=run_ws_status)
    workspace_down = workspace_subparsers.add_parser("down")
    workspace_down.add_argument("--slug", required=True)
    workspace_down.add_argument("--apply", action="store_true")
    workspace_down.add_argument("--target-root")
    workspace_down.add_argument("--output", choices=("human", "json"), default="human")
    workspace_down.set_defaults(handler=run_ws_down)

    pull_request = subparsers.add_parser("pr")
    pull_request_subparsers = pull_request.add_subparsers(
        dest="pr_command", required=True
    )
    pull_request_preflight = pull_request_subparsers.add_parser("preflight")
    pull_request_preflight.add_argument("--base", default="origin/main")
    pull_request_preflight.add_argument("--test-command")
    pull_request_preflight.add_argument("--max-subject", type=int, default=50)
    pull_request_preflight.add_argument("--cargo-root", default=".")
    pull_request_preflight.add_argument(
        "--gate",
        action="append",
        dest="gate",
        help="deterministic repo CI gate command run from the cargo root; repeatable",
    )
    pull_request_preflight.add_argument("--target-root")
    pull_request_preflight.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    pull_request_preflight.set_defaults(handler=run_pr_preflight)
    pull_request_assets = pull_request_subparsers.add_parser("assets")
    pull_request_assets_subparsers = pull_request_assets.add_subparsers(
        dest="pr_assets_command", required=True
    )
    pull_request_assets_push = pull_request_assets_subparsers.add_parser("push")
    pull_request_assets_push.add_argument("--dir", required=True)
    pull_request_assets_push.add_argument("--num", type=int, required=True)
    pull_request_assets_push.add_argument("--fork", required=True)
    pull_request_assets_push.add_argument("--expected-commit")
    pull_request_assets_push.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    pull_request_assets_push.set_defaults(handler=run_pr_assets_push)
    pull_request_watch = pull_request_subparsers.add_parser("watch")
    pull_request_watch.add_argument("--repo", required=True)
    pull_request_watch.add_argument("--num", type=int, required=True)
    pull_request_watch.add_argument(
        "--until-checks-complete",
        action="store_true",
        help="block polling until no check is pending (or --timeout expires)",
    )
    pull_request_watch.add_argument(
        "--until-review-activity",
        action="store_true",
        help=(
            "block polling until review-visible activity changes (new "
            "comments, state/mergeability/decision change) or the PR is "
            "merged/closed; CI check progress alone does not trigger"
        ),
    )
    pull_request_watch.add_argument("--timeout", type=int, default=1800)
    pull_request_watch.add_argument("--interval", type=int, default=60)
    pull_request_watch.add_argument(
        "--max-polls",
        type=int,
        default=0,
        help=(
            "return after N polls even if still pending (segmented polling "
            "for callers with outer tool timeouts); 0 = only --timeout applies"
        ),
    )
    pull_request_watch.add_argument(
        "--classify-failures",
        action="store_true",
        help=(
            "for each FAILURE check, pull the failed job log and extract "
            "failed test names, panic lines, and timeout markers as facts"
        ),
    )
    pull_request_watch.add_argument("--cursor-file")
    pull_request_watch.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    pull_request_watch.set_defaults(handler=run_pr_watch)

    close_out_parser = subparsers.add_parser("close-out")
    close_out_parser.add_argument("--pr", type=int, required=True)
    close_out_parser.add_argument("--repo", required=True)
    close_out_parser.add_argument("--issue", type=int)
    close_out_parser.add_argument("--slug")
    close_out_parser.add_argument(
        "--artifacts-root", action="append", dest="artifacts_root"
    )
    close_out_parser.add_argument("--target-root")
    close_out_parser.add_argument(
        "--output", choices=("human", "json"), default="human"
    )
    close_out_parser.set_defaults(handler=run_close_out)

    runtime_check = subparsers.add_parser("_runtime-check", help=argparse.SUPPRESS)
    runtime_check.add_argument("--version", required=True)
    runtime_check.set_defaults(handler=run_runtime_check)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.handler(args))
    except KeyboardInterrupt:
        emit(
            envelope(
                False,
                code="user-cancelled",
                message="operation interrupted; inspect the run manifest before cleanup",
            ),
            getattr(args, "output", "human"),
        )
        return 1
