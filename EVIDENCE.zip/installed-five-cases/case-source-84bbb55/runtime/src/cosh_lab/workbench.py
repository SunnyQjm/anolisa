from __future__ import annotations

import json
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import time
from typing import Any

from cosh_lab.transport import TransportError


MIN_WORKBENCH_VERSION = (1, 0, 1)
WORKBENCH_ERROR_KINDS = {
    2: "argument",
    3: "session",
    4: "auth",
    5: "network",
    6: "daemon",
    7: "session-busy",
}


def redact_workbench_text(value: str) -> str:
    value = re.sub(
        r'(?i)(\\"(?:ak|sts|authorization|password|passwd|token|secret|api[_-]?key|private[_-]?key|command[_-]?content|oss[_-]?access[_-]?key[_-]?id|alibaba[_-]?cloud[_-]?access[_-]?key[_-]?(?:id|secret)|alibaba[_-]?cloud[_-]?security[_-]?token|access[_-]?key[_-]?(?:id|secret)|security[_-]?token|signature|x[_-]?oss[_-]?signature|x[_-]?oss[_-]?security[_-]?token)\\"\s*:\s*\\").*',
        r"\1[REDACTED]",
        value,
    )
    value = re.sub(
        r'(?i)("(?:ak|sts|authorization|password|passwd|token|secret|api[_-]?key|private[_-]?key|command[_-]?content|oss[_-]?access[_-]?key[_-]?id|alibaba[_-]?cloud[_-]?access[_-]?key[_-]?(?:id|secret)|alibaba[_-]?cloud[_-]?security[_-]?token|access[_-]?key[_-]?id|access[_-]?key[_-]?secret|security[_-]?token|signature|x[_-]?oss[_-]?signature|x[_-]?oss[_-]?security[_-]?token)"\s*:\s*")((?:\\.|[^"\\])*)(")',
        r"\1[REDACTED]\3",
        value,
    )
    return re.sub(
        r"(?i)(\b(?:ak|sts|oss[_-]?access[_-]?key[_-]?id|alibaba[_-]?cloud[_-]?access[_-]?key[_-]?(?:id|secret)|alibaba[_-]?cloud[_-]?security[_-]?token|access[_-]?key[_-]?id|access[_-]?key[_-]?secret|security[_-]?token|signature|x[_-]?oss[_-]?signature|x[_-]?oss[_-]?security[_-]?token|password|passwd|token|secret|api[_-]?key|private[_-]?key|command[_-]?content)\b\s*[=:]\s*)([^&\s,;]+)",
        r"\1[REDACTED]",
        value,
    )


class WorkbenchError(TransportError):
    pass


def workbench_profile_name(backend: dict[str, Any]) -> str:
    if not isinstance(backend, dict):
        raise WorkbenchError("workbench transport requires an ECS backend")
    transport = backend.get("transport", {})
    if not isinstance(transport, dict):
        raise WorkbenchError("ecs transport must be a table")
    value = transport.get("workbench_profile")
    if not isinstance(value, str) or not value:
        raise WorkbenchError("ecs transport requires a non-empty workbench_profile")
    return value


def workbench_instance_id(manifest: dict[str, Any]) -> str:
    resources = manifest.get("resources", [])
    if not isinstance(resources, list):
        raise WorkbenchError("workbench transport requires exactly one ECS instance")
    values = [
        item.get("id")
        for item in resources
        if isinstance(item, dict) and item.get("kind") == "ecs"
    ]
    if len(values) != 1 or not isinstance(values[0], str) or not values[0]:
        raise WorkbenchError("workbench transport requires exactly one ECS instance")
    return values[0]


def workbench_target(manifest: dict[str, Any]) -> tuple[str, str, str]:
    if not isinstance(manifest, dict):
        raise WorkbenchError("workbench transport requires an ECS manifest")
    backend = manifest.get("backend")
    if not isinstance(backend, dict):
        raise WorkbenchError("workbench transport requires an ECS backend")
    region = backend.get("region")
    if not isinstance(region, str) or not region:
        raise WorkbenchError("workbench transport requires a non-empty ECS region")
    return (
        workbench_instance_id(manifest),
        region,
        workbench_profile_name(backend),
    )


def workbench_version_capability() -> dict[str, Any]:
    path = shutil.which("workbench")
    if path is None:
        return {"ok": False, "path": None, "version": None}
    completed = subprocess.run(
        [path, "version"],
        stdin=subprocess.DEVNULL,
        text=True,
        capture_output=True,
        check=False,
    )
    output = f"{completed.stdout}\n{completed.stderr}"
    match = re.search(r"\bv(\d+)\.(\d+)\.(\d+)\b", output)
    version = tuple(map(int, match.groups())) if match else None
    return {
        "ok": completed.returncode == 0
        and version is not None
        and version >= MIN_WORKBENCH_VERSION,
        "path": path,
        "version": ".".join(map(str, version)) if version else None,
    }


def _parse_json_payload(completed: subprocess.CompletedProcess[str]) -> dict[str, Any] | None:
    ansi = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
    for stream in (completed.stdout, completed.stderr):
        cleaned = ansi.sub("", stream or "")
        try:
            payload = json.loads(cleaned)
        except json.JSONDecodeError:
            pass
        else:
            if isinstance(payload, dict):
                return payload
        for line in reversed(cleaned.splitlines()):
            start = line.find("{")
            if start < 0:
                continue
            try:
                payload = json.loads(line[start:])
            except json.JSONDecodeError:
                continue
            if isinstance(payload, dict):
                return payload
    return None


def _run(
    argv: list[str],
    *,
    require_exit_code: bool = False,
    allow_text_success: bool = False,
) -> dict[str, Any]:
    started = time.monotonic()
    try:
        completed = subprocess.run(
            argv,
            stdin=subprocess.DEVNULL,
            text=True,
            capture_output=True,
            check=False,
        )
    except KeyboardInterrupt as error:
        error.commands = [
            {
                "argv": argv,
                "exit_code": 130,
                "stdout": "",
                "stderr": "Workbench operation interrupted",
                "duration_seconds": round(time.monotonic() - started, 6),
                "terminal_state_known": False,
                "failure_kind": "interrupted",
                "transport": "workbench",
            }
        ]
        error.cleanup_safe = False
        raise
    except OSError as error:
        return {
            "argv": argv,
            "exit_code": 127,
            "cli_exit_code": 127,
            "duration_seconds": round(time.monotonic() - started, 6),
            "stdout": "",
            "stderr": str(error),
            "session_id": None,
            "request_id": None,
            "terminal_state_known": True,
            "failure_kind": "binary",
            "transport": "workbench",
        }
    parsed_payload = _parse_json_payload(completed)
    text_success = (
        parsed_payload is None
        and allow_text_success
        and completed.returncode == 0
    )
    invalid_json = parsed_payload is None and not text_success
    payload = parsed_payload or {}
    invalid_field = None
    if not invalid_json:
        invalid_field = next(
            (
                field
                for field in (
                    "stdout",
                    "output",
                    "stderr",
                    "message",
                    "session_id",
                    "request_id",
                )
                if payload.get(field) is not None
                and not isinstance(payload[field], str)
            ),
            None,
        )
    payload_exit_code = payload.get("exit_code")
    payload_error_code = payload.get("code")
    remote_exit_valid = isinstance(payload_exit_code, int) and not isinstance(
        payload_exit_code, bool
    )
    error_code_valid = (
        isinstance(payload_error_code, int)
        and not isinstance(payload_error_code, bool)
        and payload_error_code > 0
    )
    payload_stderr = payload.get("stderr")
    payload_message = payload.get("message")
    stderr = (
        payload_stderr
        if isinstance(payload_stderr, str) and payload_stderr
        else payload_message
        if isinstance(payload_message, str) and payload_message
        else completed.stderr
    )
    if text_success:
        stderr = ""
    terminal_state_known = False
    failure_kind = None
    if invalid_json:
        exit_code = completed.returncode or 1
        failure_kind = "protocol"
        output_bytes = len((completed.stdout or "").encode())
        stderr = f"invalid Workbench JSON output ({output_bytes} bytes)"
        if completed.stderr.strip():
            stderr += f": {completed.stderr.strip()}"
    elif invalid_field is not None:
        if remote_exit_valid and completed.returncode == payload_exit_code:
            exit_code = payload_exit_code
            terminal_state_known = True
        elif (
            error_code_valid
            and payload_exit_code is None
            and completed.returncode == payload_error_code
        ):
            exit_code = payload_error_code
            terminal_state_known = True
        else:
            exit_code = completed.returncode or 1
        failure_kind = "protocol"
        schema_error = f"invalid Workbench response field: {invalid_field}"
        stderr = f"{schema_error}: {stderr}" if stderr else schema_error
    elif payload_error_code is not None:
        if (
            not error_code_valid
            or payload_exit_code is not None
            or completed.returncode != payload_error_code
        ):
            exit_code = completed.returncode or 1
            failure_kind = "protocol"
            stderr = f"invalid Workbench error response: {stderr}" if stderr else "invalid Workbench error response"
        else:
            exit_code = payload_error_code
            terminal_state_known = True
            failure_kind = WORKBENCH_ERROR_KINDS.get(exit_code, "transport")
    elif payload_exit_code is not None:
        if not remote_exit_valid or completed.returncode != payload_exit_code:
            exit_code = completed.returncode or 1
            failure_kind = "protocol"
            stderr = f"invalid Workbench exit_code response: {stderr}" if stderr else "invalid Workbench exit_code response"
        else:
            exit_code = payload_exit_code
            terminal_state_known = True
            if exit_code != 0:
                failure_kind = "remote-command" if require_exit_code else "transport"
    elif require_exit_code:
        exit_code = completed.returncode or 1
        failure_kind = "protocol"
        stderr = "missing Workbench exit_code"
    elif completed.returncode != 0:
        exit_code = completed.returncode
        failure_kind = WORKBENCH_ERROR_KINDS.get(exit_code, "transport")
    else:
        exit_code = 0
        terminal_state_known = True
    if failure_kind == "protocol" and exit_code == 0:
        exit_code = 1
        terminal_state_known = False
    stdout = payload.get("stdout")
    if stdout is None:
        stdout = payload.get("output")
    if not isinstance(stdout, str):
        stdout = ""
    session_id = payload.get("session_id")
    request_id = payload.get("request_id")
    stdout = redact_workbench_text(stdout)
    stderr = redact_workbench_text(stderr)
    return {
        "argv": argv,
        "exit_code": exit_code,
        "cli_exit_code": completed.returncode,
        "duration_seconds": round(time.monotonic() - started, 6),
        "stdout": stdout,
        "stderr": stderr,
        "session_id": session_id if isinstance(session_id, str) else None,
        "request_id": request_id if isinstance(request_id, str) else None,
        "terminal_state_known": terminal_state_known,
        "failure_kind": failure_kind,
        "transport": "workbench",
    }


def workbench_profile_capability(profile_name: str) -> dict[str, Any]:
    result = _run(
        [
            "workbench",
            "config",
            "get",
            "--profile",
            profile_name,
            "--output",
            "json",
        ]
    )
    return {
        "ok": result["exit_code"] == 0,
        "profile": profile_name,
        "kind": result["failure_kind"],
        "exit_code": result["exit_code"],
        "message": result["stderr"].strip(),
    }


def workbench_exec(
    manifest: dict[str, Any],
    command: list[str],
    *,
    timeout_seconds: int = 1800,
) -> dict[str, Any]:
    instance_id, region, profile_name = workbench_target(manifest)
    return _run(
        [
            "workbench",
            "exec",
            "--instance-id",
            instance_id,
            "--region",
            region,
            "--profile",
            profile_name,
            "--command",
            shlex.join(command),
            "--timeout",
            str(timeout_seconds),
            "--output",
            "json",
        ],
        require_exit_code=True,
    )


def workbench_upload_file(
    manifest: dict[str, Any], local_path: Path, remote_path: str
) -> dict[str, Any]:
    instance_id, region, profile_name = workbench_target(manifest)
    return _run(
        [
            "workbench",
            "upload",
            str(local_path),
            remote_path,
            "--instance-id",
            instance_id,
            "--region",
            region,
            "--profile",
            profile_name,
            "--force",
            "--output",
            "json",
        ],
        allow_text_success=True,
    )


def workbench_download_file(
    manifest: dict[str, Any], remote_path: str, local_path: Path
) -> dict[str, Any]:
    instance_id, region, profile_name = workbench_target(manifest)
    return _run(
        [
            "workbench",
            "download",
            remote_path,
            str(local_path),
            "--instance-id",
            instance_id,
            "--region",
            region,
            "--profile",
            profile_name,
            "--force",
            "--output",
            "json",
        ],
        allow_text_success=True,
    )
