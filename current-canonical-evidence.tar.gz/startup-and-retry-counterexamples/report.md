focused GREEN；完整候选门禁仍由 Root 完成。

首个有效 RED 为实际 1 test/exit101，run `20261013T201214Z-6352ce70`：首次 flush 失败退役后重试，notice/card 出现在 CAN/scrollout 前。最小修复在 helper 入口保存是否存在 session；需要几何管理且入口无 session 时先建立空白 viewport。有 session 的路径仍只执行原 session scrollout。

最终 GREEN 为实际 1 passed/0 failed/0 ignored、exit0，run `20261013T201435Z-cf945001`。同一 case 包含普通 present/强制 repaint、同 run 第二 pending/Denied、风险/action kind 变化、activation 移除/disabled、故障前 reset、故障后 39 列 retry/CAN、resize 和 Legacy 正控。它是 closed-TTY/viewport 组件模型，不是实际 UI worker、Core/Bash 或 PTY 业务验收。

使用 owned env `20261013T184512Z-5a9038a5`（container/native，profile codex-ui-final-owned-20261014，arm64，Rust 1.97.1）；完整原生命令、源 SHA 和标准 CLI run 路径见 report.json、red.json、green.json。首次 RED 未覆盖。

源码/env/cargo 槽已归还 Root；全部 exec session 已退出。借用环境留给 Root 最终 driver，本轮不承担 env down。未执行 workspace/full/canonical scope，未生成截图或 aggregate Go。
