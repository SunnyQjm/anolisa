# Installed canonical 独立视觉验收

Go：两个真实 scripted PTY case 的 8 点全部通过。原始 cast SHA、source event/time、实际 resize geometry、最后 PTS≤验收点、PNG/WebM SHA 均已核对；逐点裁剪视频帧与 PNG 最大 RGB 差为 2。

已实际打开 8 张原始 PNG：CJK 长行可读；逻辑历史保留完整左右 sentinel；当前审批卡唯一且底框完整；Deny 焦点可见；47×20 回退卡与过期提示完整；结算后 UI_BASH_READY 可见。视频帧与 PNG 有逐像素绑定。

两个精确副车均为 production=true、ui_test_environment={}；真实安装的 Shell/Core/worker SHA 与 RPM payload 相同，审批一次 effect、两次请求且 HostResult 存在，Bash 基线/termios 恢复且无进程残留。fault 为三个不同 worker，首代同一 PID/start 完成 Allow→Deny→Allow 后才退出。

manifest.repo.commit 与 provenance.source_head 的 null 原样保留。外部来源链为 base 2b4af68af60880790092011b96d204b33adb0c0b + staged tree ec6349fd690403b2e4003e846e3f8234daf1f6d0、Source0 全 1297 文件 hash、实际 RPM/installed 三 ELF 和 variant 哈希。没有伪造 Git。

模型仅 loopback HTTP fixture，非真实 provider；本结论不代替双架构 RPM、正式 provider、默认登录或发布验收。

两个 bash-returned PNG 为原用例显式 printf UI_BASH_READY; exit 后的终态，底部显示 exit 与空白 caret；不把它们当作新输入前空闲 PS1 证明。原 PS1 颜色、cwd、光标和 visible caret 在新输入前恢复的强证据来自 installed prompt-refault 原始测试断言及其副车。
