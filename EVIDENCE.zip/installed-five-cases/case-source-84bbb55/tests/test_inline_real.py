import copy
import hashlib
import unittest

from fixtures.inline_contract import PREFIX, REQUIRED
from fixtures.inline_real_contract import verify_real_join


class InlineRealTests(unittest.TestCase):
    def inputs(self):
        nonce='0123456789abcdef0123456789abcdef'
        payload=dict.fromkeys(REQUIRED,'a'*64)
        provider={'binary_origin':'installed-rpm','mock_enabled':False,'upstream_response_observed':True,'semantic_checkpoint_observed':True,'prompt_recovered':True,'provider_started_observed':True,'rpm_sha256':'b'*64,'installed_manifest_sha256':'c'*64,'payload_sha256':payload,'binary_sha256':'a'*64,'request_nonce_sha256':hashlib.sha256(nonce.encode()).hexdigest(),'request_count':2}
        cli={'ok':True,'data':{'case':{'id':'INL-PROD-REAL-001','sha256':'d'*64},'exit_status':0,'execution':'real-provider','failures':[],'points':[{'id':name} for name in ['provider-response','real-followup','shell-recovered']],'provider_evidence':provider}}
        observer={'evidence_class':'installed-inline-real-provider-observer','delivery_mode':'inline-first','completed':True,'error':None,'rpm_sha256':'b'*64,'candidate_sha256':'c'*64,'hosts':[{'pid':11,'start':1,'exe':PREFIX+'cosh-shell','sha256':'a'*64}],'cores':[{'pid':12,'start':2,'ppid':11,'exe':PREFIX+'cosh-core','sha256':'a'*64}],'workers':[],'effects':{'/owned/effect-'+nonce+'.txt':['INL_EFFECT']},'fresh_effect':['INL_REAL_FRESH'],'ps1_before_hex':'616263','ps1_after_hex':'616263','ps1_expected_hex':'616263'}
        return cli,observer

    def test_strict_real_provider_and_nonce_effect_join(self):
        a,b=self.inputs();verify_real_join(a,b,'d'*64)

    def test_mock_wrong_nonce_duplicate_effect_and_worker_are_not_real_proof(self):
        for field,value in [('mock_enabled',True),('upstream_response_observed',False),('request_nonce_sha256','0'*64),('request_count',1),('installed_manifest_sha256','0'*64)]:
            a,b=self.inputs();a['data']['provider_evidence'][field]=value
            with self.assertRaises(ValueError,msg=field):verify_real_join(a,b,'d'*64)
        for field,value in [('workers',[{'pid':99}]),('effects',{'/owned/effect-'+'0'*32+'.txt':['INL_EFFECT']*2}),('completed',False),('fresh_effect',[]),('ps1_after_hex','6162'),('cores',[])]:
            a,b=self.inputs();b[field]=value
            with self.assertRaises(ValueError,msg=field):verify_real_join(a,b,'d'*64)

    def test_echo_only_or_different_case_cannot_inherit_followup(self):
        a,b=self.inputs();a['data']['points']=[{'id':'provider-response'},{'id':'shell-recovered'}]
        with self.assertRaises(ValueError):verify_real_join(a,b,'d'*64)
        a,b=self.inputs()
        with self.assertRaises(ValueError):verify_real_join(a,b,'e'*64)
        a['ok']=False
        with self.assertRaises(ValueError):verify_real_join(a,b,'d'*64)

    def test_process_digest_and_parent_must_join_installed_payload(self):
        for field,value in [('ppid',8),('sha256','0'*64),('start',0)]:
            a,b=self.inputs();b['cores'][0][field]=value
            with self.assertRaises(ValueError):verify_real_join(a,b,'d'*64)
