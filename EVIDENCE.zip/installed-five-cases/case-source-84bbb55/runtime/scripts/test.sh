#!/bin/sh
# cosh-lab test runner: parallel for the subprocess-heavy bulk, serial for
# signal/PTY timing-sensitive suites.
#
# Findings behind this split (2026-07-25):
# - Full serial run: ~150s. Full `-n auto`: ~50s, but
#   test_acceptance.py::test_runner_terminates_and_reaps_pty_child_on_signal
#   flaked 1/3 parallel rounds under load (3/3 green standalone), so the
#   acceptance suite stays serial.
# - Interpreter contract follows bin/cosh-lab: python3.12 > python3.11.
#   pytest/pytest-xdist come from an ephemeral uv environment.
set -eu

repo_root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$repo_root"

run_pytest() {
    # The canonical runtime tree must stay cache-free (embedded-snapshot
    # contract), so never write bytecode or .pytest_cache here.
    PYTHONDONTWRITEBYTECODE=1 uv run --python 3.12 --with pytest --with pytest-xdist -- \
        pytest -p no:cacheprovider "$@"
}

run_pytest tests --ignore tests/test_acceptance.py -q -n auto "$@"
run_pytest tests/test_acceptance.py -q "$@"
